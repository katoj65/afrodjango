/**
 * this function runs when the page refresh.
 */

window.addEventListener('load',function(){
discussion_scroll();
clock();    
});



function chat_hide(){
$('.chat').hide(0);
}

/**
 * classroom timetable
 */
classroom=0;
function classroom_timetable(){
if(classroom==0){
$('.classroom').show();    
classroom=1;
}else{
$('.classroom').hide();
classroom=0;    
}
}









/**
 * sidebar settings for the chat pannel
 */

function classroom_sidebars(){
$('.more_lessons').css('overflow','auto');
}

function hide_classroom_sidebars(){
$('.more_lessons').css('overflow','hidden');
}

/**
 * discusion functionality.
 */
function discussion_scroll(){
var height=$('.scrollable_discussion_panel').height();
var divSize=$('.div_discuss').height();
$('.scrollable_discussion_panel').animate({scrollTop:100},0);
}




function assignment_dialog(name){
$("#assignment_title").html(name);    
}











var int=self.setInterval("clock()",10);
function clock() {
var d=new Date();
//time
var hours=d.getHours();
var m=new Date();
var minutes = m.getMinutes();
var seconds = m.getSeconds();
//date
var y = m.toDateString();
var bg = document.getElementById("time");
bg.innerHTML=hours+":"+minutes+":"+seconds+" | "+y;
}
	



