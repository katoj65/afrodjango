<script type="text/javascript">
<!--
	
$(function(){
alert();
});    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
-->
</script>