<?php
function user_session_check(){
if(!isset($_SESSION['ID'])){
redirect(base_url());
exit();
}
}


























?>