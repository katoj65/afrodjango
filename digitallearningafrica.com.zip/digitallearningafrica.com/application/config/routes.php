<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'app';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/




$route['default_controller'] = 'App';
$route['library']='App/library';
$route['login']='App/login';
$route['register']='App/register';
$route['complete/registration']='App/complete_registration';
$route['logout']='App/logout';
$route['courses']='App/list_all_courses';
$route['course/:num/add/content']='App/load_course';
$route['add/course']='App/index';
$route['add/notification']='App/index';
$route['lesson/:num']='App/course_lesson';

$route['course/:num']="App/course_load";
$route['course/category/:num']="App/course_load";

$route['student']='App/student_account';
$route['student/enroll/:num']='App/student_enrollment';
$route['student/reference']='App/student_account';
$route['student/tutorial']='App/student_account';
$route['student/reference']='App/student_account';
$route['student/faq']='App/student_account';
$route['student/discussion']='App/student_account';
$route['student/reference']='App/student_account';
$route['student/assignments']='App/student_account';
$route['student/course/log/:num']='App/create_course_reading_log';
$route['student/illustration/:num']='App/student_account';
$route['student/tutorials']='App/student_account';

$route['student/consultants']='App/student_account';
$route['student/consultants/:num']='App/student_account';
$route['student/overview/:num']='App/student_account';
$route['student/bootcamp']='App/student_account';


$route['student/calendar']='App/student_account';
$route['student/examples']='App/student_account';
$route['student/events']='App/student_account';
$route['student/event/:num']='App/student_account';
$route['search/content']='App/search_functionality';
$route['student/groups']='App/student_account';
$route['student/tutorial/:num']='App/tutorials_page';
$route['student/book/store']='App/student_book_store';
$route['student/course/content/:num']='App/student_course_content';
$route['student/virtual/classroom']='App/student_virtual_classroom';
$route['student/virtual/classroom/:num']='App/student_virtual_classroom';
$route['student/course/presentation/:num']='App/student_course_presentation';
$route['student/course/presentation/:num/illustrations']='App/student_course_presentation';
$route['student/course/presentation/:num/virtual-classroom']='App/student_course_presentation';
$route['student/course/presentation/:num/assignments']='App/student_course_presentation';
$route['student/course/presentation/:num/examples']='App/student_course_presentation';
$route['student/course/presentation/:num/reference']='App/student_course_presentation';
$route['student/course/presentation/:num/tutorials']='App/student_course_presentation';
$route['student/course/presentation/:num/assignments']='App/student_course_presentation';
$route['student/course/presentation/:num/list']='App/student_course_presentation';
$route['student/course/presentation/:num/consultations']='App/student_course_presentation';


$route['course/:num/enrollment']='App/course_enrollment';
$route['course/:num/cancel']='App/cancel_course_enroll';



/**
 * trainer URLS
 */
$route['trainer']='App/trainer_account';
$route['trainer/course/:num']='App/trainer_course';
$route['trainer/course/content/:num']='App/trainer_course_content';
$route['trainer/course/content/:num/add']='App/trainer_course_content';
$route['trainer/events']='App/trainer_events';
$route['trainer/course/application']='App/trainer_account';
$route['trainer/course/content/:num/add/presentation']='App/trainer_course_content';
$route['trainer/course/content/:num/add/file']='App/trainer_course_content';
















/**
 * $route['lesson/:num/:num/discussion']='App/course_lesson';
 * $route['lesson/:num/:num/assignment']='App/lesson_assignment';
 * $route['lesson/:num/:num/assignment/add']='App/lesson_assignment';
 * $route['lesson/:num/:num/assignment/attempt/:num']='App/lesson_assignment';
 * $route['lesson/:num/:num/assignment/attempt/:num/true']='App/lesson_assignment';
 * $route['lesson/:num/:num/ask']='App/course_lesson';
 * $route['lesson/:num/:num/class']='App/course_lesson';
 * $route['course/lesson/:num/next/:num']='App/next_course_lesson';
 * $route['course/lesson/:num/previous/:num']='App/previous_course_lesson';
 * $route['lesson/:num/:num/add/content']='App/course_lesson';
 * $route['lesson/:num/:num/add/tutorial']="App/course_lesson";
 * $route['lesson/:num/:num/add/reference']="App/course_lesson";
 * $route['lesson/:num/:num/communication']='App/course_lesson';
 * $route['lesson/:num/:num/add/assignment']='App/course_lesson';
 * $route['enrolled']='App/user_course_lesson_log';
 * $route['enrolled/:num/:num']='App/user_course_lesson_log';
 * $route['courses/all']='App/all_courses';
 * $route['lesson/:num/:num/add/assignment']='App/course_lesson';
 * $route['lesson/:num/:num/delete/:num']='App/delete_lesson_content';
 * $route['lesson/:num/:num/edit/:num']='App/course_lesson';
 * $route['lesson/:num/:num/illustration/:num']='App/course_lesson';
 */











$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;








