<?php
class Events_model extends CI_Model{

    
/**
 * future event fuctionality.
 */
function get_future_events(){
$day=date('Y-m-d');
$time=date('h:i:s');
$query=$this->db
->where('day>',$day)
->order_by('day','ASC')
->order_by('time','ASC')
->get('events');
return $query;
}    
    
    
/**
 * upcoming event fuctionality.
 */
function get_upcoming_events(){
$day=date('Y-m-d');
$time=date('h:i:s');
$query=$this->db
-> where('day',$day)
->where('time','<'.$time)
->order_by('day','ASC')
->order_by('time','ASC')
->get('events');
return $query;
}     
    
    
/**
 * ongoing event fuctionality.
 */
function get_ongoing_events(){
$day=date('Y-m-d');
$time=date('h:i:s');
$query=$this->db
->where('day','='.$day)
->where('time','>='.$time)
->order_by('day','ASC')
->order_by('time','ASC')
->get('events');
return $query;
}     
       
    
    
    
    
/**
* get all upcoming events.
*/    
function get_all_upcoming_events(){
$day=date('Y-m-d');
$query=$this->db
->where('day>=',$day)
->order_by('day','ASC')
->order_by('time','ASC')
->get('events');
return $query; 
}   
    
    
    
    
    
    














































}	
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
?>


