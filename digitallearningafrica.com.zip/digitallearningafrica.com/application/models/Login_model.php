<?php
class Login_model extends CI_Model{
    
    
function login($username,$password){
if(isset($username) and isset($password)){
$query=$this->db->where('email',$username)->where('password',$password)->limit(1)->get('register');    
return $query;
}
}    
    
    
    
function register($data){
if(isset($data)){
$this->db->insert('register',$data);
}
}    
    
    
    
function check($username){
if(isset($username)){
$query=$this->db->where('email',$username)->get('register');   
return $query->num_rows();
}   
}    



    
    
/**
 *get user information 
*/    
function get_user_information($email){
if(isset($email)){
$query=$this->db->where('email',$email)->limit(1)->get('register');    
return $query;    
}
} 
 
 
/**
  * get user profile.
  */ 
function get_user_profile($id){
if(isset($id)){
$query=$this->db->where('registrationID',$id)->limit(1)->get('user_profile');
return $query;    
}
} 




 
    
function insert_about($data){
if(isset($data)){
$this->db->insert('user_profile',$data);
}
}    
    
    
    
function user_info(){
if(isset($this->session->ID)){
$query=$this->db->where('ID',$this->session->ID)->limit(1)->get('register');
return $query;    
}
}    
    
    
    
function academic_level(){
$query=$this->db->get('academic_levels');    
return $query;    
}    

    
function country(){
$query=$this->db->get('country');    
return $query;    
}    

       
function course_category(){
$query=$this->db->get('course_category');    
return $query;    
}    
       
    
    
    
    
function get_course_category($id){
if(isset($id)){
$query=$this->db->select('user_profile.registrationID,user_profile.interests,user_profile.education,course_category.ID,course_category.name,course_category.description,course_category.file')
->from('user_profile')
->join('course_category','user_profile.interests=course_category.ID')
->where('user_profile.registrationID',$id)
->limit(1)
->get();
return $query;
}    
}    
    
    
    
/**
 * user details by email.
 */
function user_detailsByEmail($email){
if(isset($email)){
$query=$this->db->where('email',$email)
->limit(1)
->get('register');
return $query;
}
}     


    

/**
 *get registered user information. 
*/    
function logged_in_user($userID){
if(isset($userID)){
$query=$this->db->select('*')->from('register')
->join('user_profile','register.ID=user_profile.registrationID')
->where('register.ID',$userID)->limit(1)->get();
return $query;
}else{
return false;
}
}    
    
    
    





































    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}


?>