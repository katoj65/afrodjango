<?php

class Assignment_model extends CI_Model{


function insert_lesson_assignment($data){
if(isset($data)){
$this->db->insert('assignments',$data);
}
}    
    
    
    
function get_lesson_assignments($id){
if(isset($id)){
$query=$this->db->where('contentID',$id)
->where('tag','lesson')
->order_by('date','ASC')
->get('assignments');    
return $query;    
    
}
}    
    
    
function attempted_assignment($tag){
if(isset($tag)){
$query=$this->db->select('assignments.title,assignments.description,student_assignment.date')
->from('student_assignment')
->join('assignments','student_assignment.assignmentID=assignments.ID')
->where('student_assignment.tag',$tag)
->where('student_assignment.studentID',$this->session->ID)
->where('student_assignment.lessonID',$this->uri->segment(2))
->get();
return $query;
}
}    
    
    
    
    
    
function insert_selected_assignment($data){
if(isset($data)){
$this->db->insert('student_assignment',$data);
}    
}    
    
    
   


/**
* get the course assignment according to the course ID. 
*/    
function get_course_assignments($courseID){
if(isset($courseID)){
$query=$this->db->select('assignments.title,assignments.description,course.name,assignments.ID')
->from('assignments')
->join('course','assignments.contentID=course.ID')
->where('assignments.courseID',$courseID)
->get();
return $query; 

}else{
return false;
}
}    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}


?>