<?php
class Virtual_class_room_model extends CI_Model{
 
 
    
function class_room_notification($courseID){
if(isset($courseID)){
$query=$this->db->where('day>=',date('Y-m-d'))
->where('courseID',$courseID)
->get('virtual_class_room');    
return $query;
}else{
return false;
}
}   
    
    
    
    
    
    
    
    
    
    
    
/**
* get the upcoming lesson
*/
    
function get_lesson($courseID){
if(isset($courseID)){
$query=$this->db->where('day>=',date('Y-m-d'))
->limit(1)
->get('virtual_class_room');    
return $query;
}else{
return false;
}
}   
    
    
    
/**
*get other lessons 
*/    
function get_other_lesson($courseID,$itemID){
if(isset($courseID) and isset($itemID)){
$query=$this->db->where('day>=',date('Y-m-d'))
->where('ID!=',$itemID)
->get('virtual_class_room');    
return $query;
}else{
return false;
}
}     
    


    
/**
* get the lesson session by ID 
*/    
function get_sessionByID($id){
if(isset($id)){
$query=$this->db->select('*')
->from('virtual_class_room')
->join('course_category','virtual_class_room.courseID=course_category.ID')
->where('virtual_class_room.ID',$id)
->get();
return $query;
}else{
return false;
}    
}














    
    
    
    
    
    
    
    
    
    
}	
    
    
    
    
    
    
    
    
    
    
    
    
    
?>