<?php

class Discussion_model extends CI_Model{

function insert_discussion($data){
if(isset($data)){
$this->db->insert('course_discussion',$data);
}
}    
    
    

function get_lesson_discussion($lessonID){
if(isset($lessonID)){
$query=$this->db->select('course_discussion.ID,course_discussion.content,register.fname,register.lname,course_discussion.date')->from('course_discussion')->join('register','course_discussion.userID=register.ID')
->where('course_discussion.contentID',$lessonID)
->order_by('course_discussion.date','DESC')->get();
return $query;
}
}    
    
    
    
function get_discussion_comments($id){
if(isset($id)){
$query=$this->db->select('course_discussion_comment.comment,register.fname,register.lname,course_discussion_comment.date')
->from('course_discussion_comment')
->join('register','course_discussion_comment.author=register.ID')
->where('course_discussion_comment.discussionID',$id)
->get();
return $query;



}else{
return false;
}
}    






















    
    
    
    
    
    
}


?>