<?php
class Lesson_model extends CI_Model{
    
function get_course_lesson($courseID){
if(isset($courseID)){
$query=$this->db->where('courseID',$courseID)->order_by('date','ASC')->get('course_lessons');
return $query;    
}
}    
    
    
    
    
    
    
    
/**
*Lesson for the ccourse. 
*/    

function get_lessons($id){
if(isset($id)){
$qurry=$this->db->where('courseID',$id)->order_by('ID','ASC')->get('course_lessons');
return $qurry;
}
}    
    
    
    
    
    
    
function insert_lesson($data){
if(isset($data)){
$this->db->insert('course_lessons',$data);
}
}    
    
    
    
function load_course_lesson($id){
if(isset($id)){
$query=$this->db->where('ID',$id)->limit(1)->get('course_lessons');
return $query;
}
}    




function other_lessons($courseID){
if(isset($courseID)){
$query=$this->db->where('courseID',$courseID)->order_by('date','ASC')->get('course_lessons');
return $query;
}
}


function next_course_lesson(){
$query=$this->db->where('ID>',$this->uri->segment(3))->where('courseID',$this->uri->segment(5))->limit(1)->get('course_lessons');
if($query->num_rows()==1){
foreach($query->result() as $row);
return $row;
}
}


function previous_course_lesson(){
$query=$this->db->where('ID<',$this->uri->segment(3))->where('courseID',$this->uri->segment(5))->limit(1)->get('course_lessons');
if($query->num_rows()==1){
foreach($query->result() as $row);
return $row;
}
}






function check_next_course_lesson($lessonID,$courseID){
if(isset($lessonID) and isset($courseID)){
$query=$this->db->where('ID>',$lessonID)->where('courseID',$courseID)->get('course_lessons');    
return $query->num_rows();
}
}
    

function check_previous_course_lesson($lessonID,$courseID){
if(isset($lessonID) and isset($courseID)){
$query=$this->db->where('ID<',$lessonID)->where('courseID',$courseID)->get('course_lessons');    
return $query->num_rows();
}
}

 
function count_course_lessons($courseID){
if(isset($courseID)){
$query=$this->db->where('courseID',$courseID)->get('course_lessons');
return $query->num_rows();    
}
} 
 
 

 




function lesson_reading_log($data){
if(isset($data)){
$query=array('courseID'=>$data->courseID,'course_lessonID'=>$data->ID,'userID'=>$this->session->ID);
$this->db->insert('course_reading_log',$query);
}
}
 
 
 
 
 

function insert_lesson_content($content){
if(isset($content)){
$this->db->insert('lesson_content',$content);
}
}
 
 
 function get_lesson_content($id){
 if(isset($id)){
 $query=$this->db->where('lessonID',$id)->get('lesson_content');
 return $query;
 }
 }
 
 
 
 function get_lesson_contentByID($id){
 if(isset($id)){
 $query=$this->db->where('ID',$id)->get('lesson_content');
 return $query;
 }
 }
 
 function insert_reference($content){
 if(isset($content)){
 $this->db->insert('reference_material',$content);   
 }
 }
 
 
 function delete_lesson_content($lessonID){
 if(isset($lessonID)){
 $this->db->where('ID',$lessonID)->where('author',$this->session->ID)->delete('lesson_content'); 
 }   
 }
       
    

function first_lesson($courseID){
if(isset($courseID)){
$query=$this->db->where('courseID',$courseID)->order_by('date','ASC')->limit(1)->get('course_lessons');
return $query;    
}
}




function FAQ_lesson($data){
if(isset($data)){
$this->db->insert('faq',$data);
}
}







function get_new_lesson_content(){
$query=$this->db->where('author',$this->session->ID)

->order_by('date','DESC')
->limit(1)
->get('course_lessons');
return $query;

}
 
    
function get_refrence($lessonID){
if(isset($lessonID)){
$query=$this->db->where('itemID',$lessonID)->get('reference_material');    
return $query;    
}        
}    




function get_lessonsByTagID($tagID){
if(isset($tagID)){
$query=$this->db->where('courseID',$tagID)->get('course_lessons');    
return $query;        
}    
}




/**
 * Get reading log.
 */

function get_reading_log(){
$query=$this->db->select('course.name,course_lessons.title,course_lessons.ID,course_lessons.courseID')
->from('course_reading_log')
->join('course_lessons','course_reading_log.course_lessonID=course_lessons.ID')
->join('course','course_lessons.courseID=course.ID')
->where('course_reading_log.userID',$this->session->ID)
->order_by('course_reading_log.date','DESC')
->limit(1)
->get();
return $query;
}







function get_couse_lessonByID($id){
if(isset($id)){
$query=$this->db->select('course.ID,course_lessons.title,course_lessons.description,course.name')
->from('course_lessons')
->join('course','course_lessons.courseID=course.ID')
->where('course_lessons.ID',$id)
->limit(1)
->get();
return $query;
}else{
return false;
}
}



/**
 * get all lesson content.
 */

function get_all_lesson_content($lessonID){
if(isset($lessonID)){
$query=$this->db->where('lessonID',$lessonID)->get('lesson_content'); 
return $query;   
}else{
return false;    
}
}







/**
 * presentation function for the students
 */
function get_student_presentation($id){
if(isset($id)){
$query=$this->db
->select('course_lessons.ID,course.name,course_lessons.title,course_lessons.description')
->from('course_lessons')
->join('course','course_lessons.courseID=course.ID')
->where('course_lessons.ID',$id)
->limit(1)
->get();
return $query;
}else{
return false;
}
}






























    
    
}



?>