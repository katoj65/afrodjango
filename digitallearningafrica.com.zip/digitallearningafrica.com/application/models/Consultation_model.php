<?php

class Consultation_model extends CI_Model{

function get_consultants($courseID){
if(isset($courseID)){
$query=$this->db->select()
->from()
->join()
->where()
->get();

return $query;
    
}else{
return false;
}    
}    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}


















?>