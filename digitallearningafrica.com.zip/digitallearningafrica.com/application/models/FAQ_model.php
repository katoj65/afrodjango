<?php
	
class FAQ_model extends CI_Model{
    
function insert_faq($data){
$this->db->insert('faq',$data);    
}    
    
    
function get_course_questions($id){
if(isset($id)){
$query=$this->db->select('register.fname,register.lname,faq.question,faq.date')
->from('faq')->join('register','faq.author=register.ID')
->where('faq.contentID',$id)->order_by('faq.date','DESC')->get(); 
return $query;   
}else{
return false;
}
}    
    
    
    
    
    
    
    
    
    
    
    
    
}    
    





























    
?>