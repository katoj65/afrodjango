<?php

class Partners_model extends CI_Model{

function list_partners(){
$query=$this->db->get('partners');
return $query;    
}    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}





















?>