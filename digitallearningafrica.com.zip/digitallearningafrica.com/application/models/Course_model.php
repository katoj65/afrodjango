<?php
class Course_model extends CI_Model{
    
function insert_course($data){
if(isset($data)){
$this->db->insert('course',$data);
}
}    
    
    



/**
 * course application
 */
function set_course_application($data){
if(isset($data)){
$this->db->insert('course_application',$data);
}
}





function get_course_aplication_status($id){
if(isset($id)){
$query=$this->db->where('courseID',$id)
->where('userID',$this->session->ID)
->get('course_application');
return $query;
}else{
return false;
}
}


/**
 * get approved course applications.
 */
function get_approved_applications(){
$query=$this->db->where('userID',$this->session->ID)
->where('status','confirmed')
->get('course_application');    
return $query;
}





    
    
    
function get_courses(){
$query=$this->db->order_by('date','DESC')->limit(9)->get('course');
return $query;
}    
    
  
  
function all_courses(){
$query=$this->db->order_by('date','DESC')->get('course');
return $query;
}    
    
  
  
    
    
function get_courseByname($name){
if(isset($name)){   
$query=$this->db->where('name',$name)->where('author',$this->session->ID)->order_by('date','DESC')->limit(1)->get('course');    
return $query;
}
}    
    
    
function load_course($id){
if(isset($id)){
$query=$this->db->where('ID',$id)->limit(1)->get('course');
return $query;
}
} 
 
 
function other_course(){
$query=$this->db->where('ID!=',$this->uri->segment(2))->get('course');
return $query;
} 
 
 
 
/**
* get course category by ID.
*/ 
function get_course_categoryByID($id){
if(isset($id)){
$query=$this->db->where('ID',$id)->limit(1)->get('course_category');
return $query;    
}else{
return false;
}    
} 
 
 
 
/**
  * enrollment.
  */ 
function enroll(){    
$query=$this->db->where('itemID',$this->uri->segment(2))->where('userID',$this->session->ID)->where('tag','course')->limit(1)->get('enrollment');
if($query->num_rows()==0){
$data=array('itemID'=>$this->uri->segment(2),'userID'=>$this->session->ID,'tag'=>'course');
$this->db->insert('enrollment',$data);
redirect(base_url('index.php/course/'.$this->uri->segment(2).'/'.$this->uri->segment(3)));
}else{
redirect(base_url('index.php/course/'.$this->uri->segment(2).'/'.$this->uri->segment(3)));
}
} 
 
 
 
 
 
 
 
/**
 * enrollment for the course.
*/ 

function course_enrollment($id){
if(isset($id)){
$query=$this->db->where('itemID',$id)
->where('userID',$this->session->ID)
->where('tag','course')
->where('status!=','cancelled')
->limit(1)
->get('enrollment');

return $query;

}else{
return false;
}
} 
 
 
 
 
 

    
/**
 *Check enrollment. 
*/    
function check_enrollment(){
$query=$this->db->where('itemID',$this->uri->segment(2))
->where('userID',$this->session->ID)
->where('tag','course')
->where('status!=','cancelled')
->limit(1)->get('enrollment');
return $query;
}    
    
 
 
/**
  * Insert into enrollment table.
  */ 
 
function insert_enrollment($data){
$this->db->insert('enrollment',$data);
} 
 
/**
* enrollment details.
*/ 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
    
    
function cancel_enroll(){
$this->db->set('status','cancelled')->where('itemID',$this->uri->segment(2))->where('userID',$this->session->ID)->where('tag','course')->update('enrollment');
$this->session->set_flashdata('enrollment_cancel','<div class="title">You have cancelled your enrollment for the course</div>');
redirect(base_url('index.php/course/'.$this->uri->segment(2).'/enrollment'));

}









function course_enrollment_info($id){
if(isset($id)){
$query=$this->db->where('itemID',$id)->where('userID',$this->session->ID)->where('tag','course')->where('status!=','cancelled')->limit(1)->get('enrollment');
return $query;
}
}


function enrolled_courses(){
$this->db->select('*')->from('enrollment')->join('course','enrollment.itemID=course.ID')->where('enrollment.userID',$this->session->ID);
$query=$this->db->get();
return $query;
} 
 






/**
 * creating the reading log
 */
function insert_reading_log($data){
if(isset($data)){
$this->db->insert('course_reading_log',$data);    
}else{
return false;
}
}

/**
 * get reading log
 */
function course_reading_log(){
$query=$this->db->where('userID',$this->session->ID)->order_by('date','DESC')->limit(1)->get('course_reading_log');
return $query;
}




/**
 * course log details
 */













function course_categories($id){
if(isset($id)){
$query=$this->db->where('course_categoryID',$id)
->limit(8)
->order_by('date','DESC')
->get('course');
return $query;    
}
}




function get_recent_added_lesson($array){
if(isset($array)){
$query=$this->db->where('name',$array['title'])
->where('image',$array['file'])
->where('description',$array['description'])
->where('author',$this->session->ID)
->order_by('date','DESC')
->limit(1)
->get('course');
return $query;    
}
}




function count_courses($tag){
if(isset($tag)){
$count=$this->db->where('course_categoryID',$tag)->get('course');
return $count->num_rows();
}    
}




function study_category(){
$query=$this->db->get('course_category');
return $query;    
}









/**
 * newly added course content
 */
function get_new_course(){
$query=$this->db->where('author',$this->session->ID)
->where('course_categoryID ',$_SESSION['course_content'][0])
->where('name',$_SESSION['course_content'][1])
->where('description',$_SESSION['course_content'][2])
->order_by('date','DESC')
->limit(1)
->get('course');
return $query;

}






function course_no_lesson($categoryID){
if(isset($categoryID)){
$query=$this->db->select('*')->from('course')->join('course_lessons','course.ID=course_lessons.courseID')
->join('course_category','course.course_categoryID=course_category.ID')->where('course_category.ID',$categoryID)
->where('course_lessons.author',$this->session->ID)->where('course.author',$this->session->ID)
->get();
return $query;
}
}












function user_course_details($id){
if(isset($id)){
$query=$this->db->where('ID',$id)
->limit(1)
->get('course_category');
return $query;    
}
}





/**
 *course enrollment check. 
 */
function course_enrollment_check($course){
if(isset($course)){
$query=$this->db->where('itemID',$course)
->where('tag','course')
->where('userID',$this->session->ID)
->order_by('date','DESC')
->limit(1)
->get('enrollment'); 
return $query->num_rows(); 
}else{
return false;
}    
}



/**
 * first lesson
 */

function get_first_lesson($id){
if(isset($id)){
$query=$this->db->where('course_categoryID',$id)->order_by('date','ASC')->limit(1)->get('course');
return $query;

}else{
return false;
}    
}


/**
 * Get lesson byID.
 */
function get_lessonByID($id){
if(isset($id)){
$query=$this->db->where('ID',$id)->limit(1)->get('course');
return $query;

}else{
return false;
}    
}






function get_trainer_course_load($id,$courseID){
if(isset($id) and isset($courseID)){
$query=$this->db->where('ID',$id)
->where('course_categoryID',$courseID)
->limit(1)
->get('course');
return $query;

}else{
return false;
}    
}








/**
 * get all courses.
 */
function get_course_list($id){
if(isset($id)){
$query=$this->db->where('course_categoryID',$id)->order_by('date','ASC')->get('course');    
return $query;
}else{
return false;
}
}




/**
 * category.
 */
function get_course_n_category(){
$query=$this->db->select('*')->from('course')->get();
return $query;    
}




function return_course_category($id){
if(isset($id)){
$query=$this->db->where('ID',$id)->limit(1)->get('course_category');
if($query->num_rows()==1){
foreach($query->result() as $row);
return $row;
}    
}else{
return false;
}
}








    
}


?>