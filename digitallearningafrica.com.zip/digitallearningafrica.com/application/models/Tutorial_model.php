<?php

class Tutorial_model extends CI_Model{
    
    
function insert_tutorial($content){
if(isset($content)){
$this->db->insert('course_tutorial',$content);
}
}    
    





/**
*Tutorials for the course. 
*/    
function get_course_tutorials($id){
if(isset($id)){
$query=$this->db->select('course_tutorial.title,course_category.name,course_tutorial.ID')
->from('course_tutorial')
->join('course_category','course_tutorial.courseID=course_category.ID')
->where('course_tutorial.courseID',$id)->get();
return $query;    
}else{
return false;
}
}    
    
    
    
    
/**
*Load tutorial content 
*/    
    
function load_tutorial_content($id){
if(isset($id)){
$query=$this->db->select('course_tutorial.title,course_category.name,course_tutorial.ID,course_category.description,course_category.file,course_category.date,course_tutorial.description')
->from('course_tutorial')
->join('course_category','course_tutorial.courseID=course_category.ID')
->where('course_tutorial.ID',$id)
->limit(1)
->get();
return $query; 
}else{
return false;
}
}    
    
    
    
    
    
    
    
    
    
}



?>