<?php



class Section_model extends CI_Model{


function section($tag){
if(isset($tag)){
$query=$this->db->where('tag',$tag)->get('section');    
if($query->num_rows()==1){
foreach($query->result() as $row);
return $row;
}else{
return false;    
}
}else{
return FALSE;
}
}    
    
    
    
    
    
function section_row($tag){
if(isset($tag)){
$query=$this->db->where('tag',$tag)->get('section');    
return $query;
}      
}    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}





































?>