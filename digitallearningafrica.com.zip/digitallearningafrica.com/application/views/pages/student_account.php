<div class="container">
<div class="row pad-top-botm">

<div class="col-lg-3 col-md-3">


<div>
<?php
echo($calendar);
?>
<hr />
</div>




</div>




<div class="col-lg-9 col-md-9">



<h3 style="font-size: 15px;">
<span style="padding: 10px;background: #565AB1;color:white;border:solid thin #2B3C69;font-weight:normal;" class="border_radius">
<?php
echo $count_course.' '.$course_load->name.' tutorials available';
?>
</span>


<?php

if($enroll==0){
echo('<span style="">
<a href="'.base_url('index.php/student/enroll/'.$course_load->ID).'" style="background:#FF4800;padding:10px;font-size:15px;color:white;font-weight:normal;" class="border_radius">
Enroll for course</a></span>');    
}elseif($enroll==1){

if($enrollment_info->num_rows()==1){
foreach($enrollment_info->result() as $enroll_row);
}

echo('<span style="">
<a href="" style="background:green;padding:10px;font-size:15px;color:white;font-weight:normal;" class="border_radius">Enrolled on '.nice_date($enroll_row->date,'D, d-M-Y').'</a></span>');
unset($enroll_row);
}	

?>
</h3>

</div>




















<div class="row">
<div class="col-lg-6 col-md-6" style="margin-top: -10px;">







<div class="panel-body">
<ul class="plan">




<?php
if($topics->num_rows()>0){
foreach($topics->result() as $content){
echo('<li style="text-align:left;border:none;">');
echo('<h5 style="color:#2B3C69;font-size:18px;"><i class="fa fa-bars"></i> '.ucfirst($content->name).'</h5>');
//echo('<p style="font-size:15px;">'.ucfirst(ellipsize($content->description,140)).'</p>');


//echo('<span><a class="preview btn btn-success " title="Image Title Here" href="assets/img/portfolio/3.jpg" style="padding:5px;">100 topics</a></span>');
echo('</li>');
    
}
unset($content);
    
}else{
echo('No content');
}
?>




</ul>
</div>




</div>





<div class="col-lg-2 col-md-2" style="margin-top: 50px;">
<h3 style="font-family: fantasy;color:#2B3C69;">Overview</h3>



<div class="border_radius" style="padding: 25px;margin-top: 20px;border:solid thin silver">
<ul style="margin:0;padding: 0;">
<li><a href="" style="font-size:15px;"> Consultants</a></li>
<li><a href="" style="font-size:15px;"> Bootcamp</a></li>
<li><a href="" style="font-size:15px;">V.classroom</a></li>
<li><a href="" style="font-size:15px;">Certification</a></li>

</ul>

</div>

</div>









</div>



















</div>
</div>
