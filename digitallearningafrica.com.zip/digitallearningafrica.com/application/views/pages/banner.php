    <!-- bannerSection -->
    <div class="bannerSection" style="">
		<div class="slider-inner">
			<div id="da-slider" class="da-slider">
				
                <div class="da-slide">
					
                    <h2><i>Clean</i> <br> <i>Responsive </i> <br> <i>HTML5 & CSS3</i></h2>
					<p><i>Professional look</i> <br> <i>Compitable in different device</i> <br> <i>Mordern technology in use</i></p>
					<div class="da-img"><img src="<?php
	echo base_url();
?>assets/custom/img/Responsive-Website-Design-Devices.png" alt="" /></div>
				</div>
				
                
				<div class="da-slide">
					<h2><i>Clean</i> <br> <i>Responsive </i> <br> <i>HTML5 & CSS3</i></h2>
					<p><i>Professional look</i> <br> <i>Compitable in different device</i> <br> <i>Mordern technology in use</i></p>
					<div class="da-img"><img src="<?php
	echo base_url();
?>assets/custom/img/bootstrap-mobile-template.png" alt="" /></div>
				</div>
				
				
				
				<div class="da-slide">
					<h2><i>Find Our Events</i> <br> <i>Entertainment</i></h2>
					<p><i>Awesome business logic</i> <br> <i>3 business success history</i></p>
					<div class="da-img">
							<iframe src="http://player.vimeo.com/video/41029575" width="100%" height="320" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen class="col-md-offset-4 col-md-6"></iframe>
					</div>
				</div>
				
                
                <nav class="da-arrows">
					<span class="da-arrows-prev"></span>
					<span class="da-arrows-next"></span>		
				</nav>
			</div><!--/da-slider-->
		</div><!--/slider-->
		<!--=== End Slider ===-->


	</div>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    