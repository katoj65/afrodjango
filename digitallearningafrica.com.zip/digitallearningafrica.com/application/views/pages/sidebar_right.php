


<a href="<?php
echo base_url('index.php/student/discussion');	
?>" style="margin-right: 10px;font-size:15px;">Discussions</a>
<a href="<?php
echo  base_url('index.php/student/consultants');
?>" style="margin-right: 10px;font-size:15px;">Consultants</a>
<a href="<?php
echo base_url('index.php/student/groups');
?>"style="margin-right: 10px;font-size:15px;">Groups</a>
<a href="<?php
	echo base_url('index.php/student/virtual/classroom');
?>" style="margin-right: 10px;">V.Classroom</a>


<hr />




<div class="panel-group pad-top-botm" id="accordion" style="margin-top: 0;padding-top: 0;margin-bottom: 0;padding-bottom: 0;">
<div class="">
<div class="panel-heading">
<h4 class="panel-title panel-title-adjust">
<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" class="collapsed">
<i class="fa fa-plus"></i>Study Calendar</a>




<span style="padding-left: 20px;">
<?php
if($latest_event->num_rows()>0){
foreach($latest_event->result() as $event);
echo '<span style="color:#ED4933;">'.nice_date($event->day,'D, d - M - Y, H:i').'</span>';

}	
?>
</span>



</h4>
</div>
<div id="collapseOne" class="panel-collapse collapse" style="height: 0px;">
<div class="panel-body"> 
<div style="padding-top: 20px;">
<?php
echo $calendar;
?>
</div>
</div>

</div>

</div>
</div>






<hr />
<div>
<h3>Tutorials<span>
<span style="background:#ED4933;padding:5px;color:white;font-size: 13px;" class="border_radius"><?php
echo $topics->num_rows();
?></span></span>


<span><a href="<?php
echo base_url('index.php/student/bootcamp');
?>" style="color:white;font-size:15px;margin-left:25px;color:#ED4933;">Bootcamp</a></span>

</h3>






<div style="border: solid thin #EBEDEF;padding: 20px;margin-top: 30px;" class="border_radius">

<?php
if($topics->num_rows()>0){
$title=array();
$title[0]=false;
$desc=array();
$desc[0]=false;
$id=array();
$id[0]=false;

foreach($topics->result() as $content){
$title[]=$content->name;
$desc[]=$content->description;
$id[]=$content->ID;
}

echo('<div style="margin-top:20px;">');
echo('<ul style="margin:0;padding:0;">');
for($x=1;$x<=$topics->num_rows();$x++){
echo('<li style="list-style:none;margin-bottom:10px;">');
echo '<a href="'.base_url('index.php/student/course/log/'.$id[$x]).'" style="font-size:18px;">
<span style="padding:5px;background:#565AB1;color:white;font-size:18px;border:solid thin #34296F;" class="border_radius">Topic'.$x.'</span>
<i class="fa fa-bars" style="margin-right:5px;"></i>'.ucfirst(ellipsize($title[$x],20)).'
</a><br/>
<span style="color:black;">'.ucfirst(ellipsize($desc[$x],100)).'</span>
';

echo('</li>');
    
}
echo('</ul>');
echo('</div>');

unset($content);
}else{
echo('No content');
}
?>


<hr />

<?php
//echo $calendar;
?>
</div>

</div>







<script type="text/javascript">
<!--
function calendar_section(){
$('#calendar_section').toggle();
}	
-->
</script>




