<?php
if($course->num_rows()==1){
foreach($course->result() as $row);    
}else{
redirect(base_url());
}	
?>





<div style="background:black;color: white;text-align: center;padding: 10px;">
<h3>Enroll to start coding with <?php
echo $my_course->name;
?></h3>
</div>
<div style="background: aliceblue;padding: 20px;">
<div class="container">


<div class="row">

<div class="col-lg-8">
<p style="font-size: 25px;">
<?php
echo ucfirst($my_course->name);	
?>
</p>

<p>
<?php
echo ucfirst(ellipsize($my_course->description,300));	
?>

</p>





</div>

<div class="col-lg-4">

<?php
if($course->num_rows()==1){
foreach($course->result() as $course_content);       
}


if($course_content->author==$user->ID){
 echo('<span class="btn btn btn-brand">COURSE CONSULTANT</span>');      
}else{

if($enrollment->num_rows()==1){
     
echo('<a class="btn btn btn-brand" href="'.base_url('index.php/course/'.$this->uri->segment(2).'/cancel').'">Cancel enrollment</a>');   
    
}elseif($enrollment->num_rows()==0){
     
echo('<a class="btn btn btn-brand" href="'.base_url('index.php/course/'.$this->uri->segment(2).'/enroll').'">Enroll Now</a>');   
     
}	
}


?>

</div>










</div>

</div>



</div>







<div class="serviceBlock">
<div class="container">
<div class="row" style="padding: 20px;margin-top: -50px;">
<div class="col-lg-13">








<div class="row" style="min-height: 500px;">
<div class="col-lg-8">


						<div class="clearfix" style="margin: 0;padding-top: 0;">
							
							<div class="desc">
								
							<h4 style="margin: 0;padding-bottom:10px;padding-top: 0;color: #FF4800;text-align: center;"><?php
	echo ucfirst($row->name);
?> </h4></a>
								<p style="font-size: 16px; color: black;"><?php
	echo ucfirst($row->description);
?></p>
<div style="float: right;"><span>


 
</span></div>
</div>
</div>



<div style="padding: 20px;text-align: center;font-size: 20px;margin-bottom: 30px;">

<span class="gradient" style="color: #FF4800;padding:10px;padding-left: 10px;padding-right: 10px;">Lessons for the course</span>

</div>




<?php
	
if($lessons->num_rows()>0){
foreach($lessons->result() as $content){
    
echo('<div class="col-md-6">
						<div class="clearfix">
							<i class="fa fa-html5"></i> 
							<div class="desc">
								
							<a href="'.base_url('index.php/course/'.$content->ID).'">	
                            <h4 style="height:20px;overflow:hidden;">'.ucfirst(character_limiter($content->title,100)).'</h4></a>
								<p>'.ucfirst(character_limiter($content->description,100)).'</p>
							</div>
						</div>
					</div>');	   
       







    
}      
unset($content);    
}else{
echo('<div>No lessons for this course</div>');
}    
    
?>




</div>
<div class="col-lg-3" style="">

<?php
echo ('<h3><img src="'.base_url($my_course->file).'" style="width:50px;height:50px;" class="img-circle">'.ucfirst($my_course->name).'</h3>');
$this->load->view('templates/search_bar');
	
?>
<hr />







<ul>

<li><a href="">Ask a question</a></li>
<li><a href="">Course assignments</a></li>
<li><a href="">Discussion groups</a></li>
<li><a href="">Home work</a></li>
<li><a href="">Find a tutor/ mentor</a></li>
<li><a href="">Add to catalog</a></li>
<li><a href="">Chat with students</a></li>
</ul>

<hr />
<h4 class="menus" style="margin: 20px;color:#FF4800;">Other courses</h4>
<?php
if($other->num_rows()>0){
echo('<ul>');
foreach($other->result() as $c_other){
echo('<li><a href="'.base_url('index.php/course/'.$c_other->ID).'">'.ucfirst(character_limiter($c_other->name,20)).'</a></li>');    
}    
unset($c_other);    
echo('</ul>');
}else{
echo('<div>No content</div>');
}	
    
    
    
?>



</div>













</div>


<div>
</div>






</div>
</div>
</div>
</div>