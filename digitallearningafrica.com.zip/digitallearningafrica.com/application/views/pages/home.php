<section id="home-service" style="margin-top:20px;">
<div class="container">
<div class="row " style="text-align: center;">

  <section id="service-info">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-12 col-md-12">
                    <h3 class="clr-main"><strong>
                    COURSES FOR 

<?php
echo strtoupper($my_course->name);
?> 
 DEVELOPMENT

</strong></h3>
<p style="font-size: 16px;">  
<?php
echo ucfirst($my_course->description);
?>                 
</p>
<hr /> 
 
<div style="text-align: left;">
<ul class="menus">
<li><a href="" style="font-size: 16px;" >Ask question</a></li>
<li><a href="" style="font-size: 16px;" >Talk to consultants</a></li>
<?php

if($user->role=='course'){
if($my_course->ID==$my_course->interests)
echo('<li><a href="'.base_url('index.php/add/course').'" style="font-size: 16px;">Add course</></li>');
echo('<li><a href="'.base_url('index.php/add/notification').'" style="font-size: 16px;">Add note</a></li>');
echo('<li><a href="'.base_url('index.php/add/notification').'" style="font-size: 16px;">30 Teacher</a></li>');
echo('<li><a href="'.base_url('index.php/add/notification').'" style="font-size: 16px;">20 Mentors</a></li>');
echo('<li><a href="'.base_url('index.php/add/notification').'" style="font-size: 16px;">100 Course consultants</a></li>');
echo('<li><a href="'.base_url('index.php/add/notification').'" style="font-size: 16px;">200 Trainees</a></li>');

    
    
}	

?>


</ul>
</div>
 
 
 
 
 
 
 
 
 
 
                    
<br />
<br />
</div>
</div>
</div>
</div>














<div class="row" style="margin-top: -60px;">
<div class="col-lg-9">
<div>

<?php
if($this->uri->segment(1)=='add'){
if($user->role=='course'){
if($my_course->ID==$my_course->interests){    
if($this->uri->segment(2)=='course'){
$this->load->view('forms/add_course');

}
}


}else{
redirect(base_url());
}    
    
    
    
    
}




	
?>










</div>





<?php
if($user_courses->num_rows()>0){
	foreach($user_courses->result() as $row){
	  
                
echo('<div class="col-lg-6 col-md-6">
<div class="media">
<div class="pull-left">
<i class=" fa fa-folder-open-o fa-4x rotate-icon "></i>
</div>
<div class="media-body">
<a href="'.base_url('index.php/course/'.$row->ID).'">
<h3 class="media-heading" 
style="font-size:15px;color:#FF6A00;"><strong>'.ucfirst(character_limiter($row->name,32)).'</strong></h3></a>
<p style="padding:5px;border-bottom:solid 5px #E0E0E0;font-size:15px;height:140px;overflow:hidden;">
'.ucfirst(character_limiter($row->description,200)).'
</p>
</div>
</div>
</div>');


}
}else{
echo('<div>No content</div>');
}

?>



</div>






<div class="col-lg-3">
<div>
<h3 style="font-size: 20px;font-weight: bolder;color: #FF6A00;">
<?php
echo ('<img src="'.base_url($my_course->file).'" style="width:50px;height:50px;margin-right:20px;"/>');
echo strtoupper($my_course->name);
?>
</h3>
</div>
<hr />
<div>
<?php
echo $calendar;
?>
</div>
<hr />



<div style="text-align: center;" class="button1">
<a href="#" style="color:white;font-size: 17px;">Talk to course consultants</a>
</div>



<div style="margin-top: 50px;">
<a href="<?php
	echo base_url('index.php/courses/all');
?>" style="color:#78909C;"><h3 style="font-size: 40px;text-align: center;">
<?php

echo('<span style="padding:10px;background:#34296F;color:white;" class="border_radius">'.$count_courses.'</span>');

echo('<p style="font-size:25px;padding:20px;">');
if($count_courses>1){
echo('Courses available');
}else{
echo('Couse available');
}
echo('</p>');

?>
</h3></a>
</div>





</div>
</div>
</div>
</section>
</section>










<div id="just-middle-row" style="background: #E0E0E0;min-height: 200px;color:gray;">
<div class="container">
<div class="row pad-top-botm">

<div class="col-lg-12 col-md-12">
<h5>
<?php

echo $note;

?>
</h5>


</div>




</div>
</div>
</div>


