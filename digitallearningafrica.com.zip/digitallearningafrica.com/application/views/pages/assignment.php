<?php
if($course->num_rows()==1){
foreach($course->result() as $row);
}else{
redirect(base_url());
}	
?>







<?php
if($attempted->num_rows()==1){
foreach($attempted->result() as $attempt);
}	            



?>




<div style="background:black;text-align: center;padding: 10px;color: white;">
<h3>
<?php
if($page=='lesson_assignment'){
echo ucfirst($this->uri->segment(1));
}
	
?>

assignment</h3>
</div>



<div style="background:aliceblue;padding-bottom: 10px;">
<div class="container">
<div class="row" style="padding: 10px;">
<div class="col-lg-9" style="margin: 0;">

<p style="font-size: 25px;">
Assignment for  
<?php
echo ucfirst($my_course->name); 
?>
</p>

<div style="font-size: 17px;">
<strong>Lesson:</strong>

<?php

echo '<a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3)).'">'.ucfirst($row->name).'</a>';	

?>

</div>


</div>


<div class="col-lg-3">
<div style="font-size: 17px;padding-top: 10px;">

<span class="borders">
<?php

if($assignments->num_rows()>1){
$lang='assignments';    
}else{
$lang='assignment';
}

echo $assignments->num_rows().' '.ucfirst($lang);
	
?>

</span>

<div id="time" style="padding: 10px;font-size: 15px;">
</div>


</div>
</div>

</div>
</div>
</div>




<div class="serviceBlock">
<div class="container">
<div class="row" style="min-height: 500px;">
<div class="col-lg-9">

<?php

if($this->uri->segment(1)=='lesson'){
if($this->uri->segment(5)=='add'){
$this->load->view('forms/assignment_form');
}elseif($this->uri->segment(5)=='attempt'){
$this->load->view('dialog/dialog_assignment_attempt');
}
}

	
?>


<div>


<?php
if($attempted->num_rows()==1){
echo('<div style="text-align: center;"><span style="font-size: 25px;">My assignment</span></div>');


echo('<div style="margin:10px;padding:10px;margin-bottom:10px;" class="round">');
echo('<p><h4 style="padding:10px;color:#FF4800;margin:0;" class="gradient">'.ucfirst($attempt->title).'</h4></p>');
echo('<p style="font-size:15px;color:black;">'.ucfirst($attempt->description).'</p>');

echo('<div style="">
<span style="color:#FF4800;">'.nice_date($attempt->date,'D d -  M -  Y | h:i A').'</span>
<a href="#" class="btn btn-success" style="float:right;margin-right:30px;margin-top:-5px;">Submit assignment</a></div>');
echo('</div>');





echo('<div style="text-align: center;padding:10px;margin-bottom:-3px;">
<span style="font-size: 17px;padding:10px;border:solid 1px #EBEDEF;border-bottom:none;background:#F7F7F7;" class="border_radius">Other assignments</span></div>');

}else{
echo('<div style="text-align: center;"><span class="" style="font-size: 25px;">Choose any one assignment below</span></div>');
}	
?>










<table border="0" cellpadding="5" cellspacing="5">
<?php

if($assignments->num_rows()>0){
    
$array=array();
$array[0]=''; 
$array1=array();
$array1[0]='';   
$id=array();
$id[0]='';        
$head[0]='';


foreach($assignments->result() as $assign){
$array[]=ucfirst($assign->title);
$array1[]='<p>'.ucfirst($assign->description).'</p>'; 
$id[]=$assign->ID;
$head[]=$assign->title;   
}    



if($attempted->num_rows()==1){
    
for($x=1;$x<=$assignments->num_rows();$x++){
echo('<tr class="line_big" style="border-top:solid thin #EBEDEF;">
<td style="font-size:15px;color:black;">('.$x.')</td>
<td><h4 style="color:#FF4800;font-size:15px;">'.$array[$x]).'</h4></td><tr>';
echo('<tr style=""><td></td><td style="color:gray;font-size:15px;">'.ucfirst($array1[$x]).'
</td><tr>');

}    


}else{  

for($x=1;$x<=$assignments->num_rows();$x++){
echo('<tr style="background:#F7F7F7;border-top:solid thin #EEEEEE;border-bottom:none;"><td style="font-size:20px;">('.$x.')</td><td><a href="#"><h4>'.$array[$x]).'</h4></a></td><tr>';
echo('<tr style="border-top:solid thin #EEEEEE;"><td></td><td style="color:gray;">'.ucfirst($array1[$x]).'
<div style="padding-right:20px;"><a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4).'/attempt/'.$id[$x]).'" style="float:right;">Attempt</a></div>
</td><tr>');

}
}





if($this->uri->segment(5)=='attempt'){
$xy=ucfirst(ellipsize($head[$this->uri->segment(6)],80));
echo('<script type="text/javascript">
<!-- 
assignment_dialog("'.$xy.'"); 
-->
</script>');
}









reset($assignments);
}else{
echo('<div>No content</div>');    
}
	
?>






</table>

</div>

</div>




<div class="col-lg-3">

<div style="font-size: 20px;">
<img src="<?php
echo base_url($my_course->file);	
?>" width="50" height="50" />
<?php



echo ucfirst($my_course->name);	
?>

</div>




<?php

$this->load->view('templates/search_bar');	
    
?>

<hr />

<div>
<?php
if($row->author==$this->session->ID){
echo('<ul>');
echo('<li><a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/assignment/add').'">Add assignment</a></li>');


echo('</ul>');
}	
    
    
    
    
?>

</div>
<hr />









<div style="border: solid thin silver;background: aliceblue;" class="shadow_bottom1">



<?php
echo $calendar;	
?>
</div>


</div>



</div>
</div>
</div>
