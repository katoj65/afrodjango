  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>EVENTS</h3>
                        <p><?php
	echo ucfirst($description);
?> </p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                
                
<div class="col-lg-3 col-md-3">
<div>
<h3 style="text-align: center;font-family: fantasy;">Calendar</h3>
<?php
echo $calendar;
?>
</div>          
 </div>
                
                
                
                
                
                
                
                
                
 <div class="col-lg-9 col-md-9">
 <blockquote style="min-height: 300px;">
 <h3 style="margin-top: -20px;">Events</h3>                       
                    <?php
	for($x=1;$x<=5;$x++){
echo('<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
<small>Consectetur adipiscing elit</small>');	   
	}
                        
                        
                        
                        
                        ?>
                    
                    
                    
                    
                        
                    
                    
                    
                    
                    </blockquote>

                </div>
            </div>

        </div>

    </div>
    <!--./ Media Section End -->