
<?php
if($lesson->num_rows()==1){
foreach($lesson->result() as $row);        
}else{
redirect(base_url());
}	
?>

<div style="background:black;text-align: center;padding: 10px;color: white;">
<h3><?php
echo ucfirst($heading);	
?></h3>
</div>



<div style="background: aliceblue;padding-bottom: 30px;" class="">
<div class="container">
<div class="row">
<div class="col-lg-13" style="text-align: center;">



<div style="padding-top:20px;text-align: left;">

<a href="<?php
	echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/ask');
?>"><span class="borders" style="margin-left: 10px;font-size: 14px;">Ask question</span></a>



<a href="<?php
	echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/discussion');
?>"><span class="borders" style="margin-left: 10px;font-size: 14px;">Discussion</span></a>


<span class="borders" style="margin-left: 10px;font-size: 14px;">Talk to consultant
</span>


<a href="<?php echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/class');?>">
<span class="borders" style="margin-left: 10px;font-size: 14px;">
Class room
</span></a>


<a href="<?php echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/tutorials');?>">
<span class="borders" style="margin-left: 10px;font-size: 14px;">
Lesson tutorials
</span></a>




<a href="<?php
echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/assignment');?>">
<span class="borders" style="margin-left: 10px;font-size: 14px;">
Assignments
</span>
</a>

</div>



</div>

</div>
</div>
</div>















































<div class="serviceBlock">
<div class="container">


<div class="row" style="padding: 20px;">

<div class="col-lg-13">



<div class="row" style="min-height: 500px;">
<div class="col-lg-8" style="padding-top: 0;margin-top: 0;margin-top:-80px;">





<div style="margin-top: 20px;">









<?php
echo $this->session->flashdata('delete_lesson_content');
echo $this->session->flashdata('faq_success');
	
?>














<?php
if($row->author==$user->ID){
/**
  * course consultant menu.
  */ 
if($this->uri->segment(4)=='add'){ 
if($this->uri->segment(5)=='content'){
$this->load->view('forms/add_lesson_content');	
}elseif($this->uri->segment(5)=='tutorial'){
$this->load->view('forms/add_tutorial');
}elseif($this->uri->segment(5)=='reference'){
$this->load->view('forms/add_reference_material');
}elseif($this->uri->segment(5)){
$this->load->view('forms/course_lesson_assignments');
}
}









}else{

}



/**
 * course enrollmet menu,
 */
if($this->uri->segment(4)=='ask'){
$this->load->view('forms/lesson_question');
}elseif($this->uri->segment(4)=='discussion'){
$this->load->view('dialog/dialog_lesson_discussion');
}elseif($this->uri->segment(4)=='class'){
$this->load->view('dialog/dialog_class');       
}elseif($this->uri->segment(4)=='tutorials'){
}elseif($this->uri->segment(4)=='consult'){
}










?>
</div>


















<div class="col-md-13">

<div style="padding:15px;">
						
                   
                        <div class="clearfix">
						
							
                            
                           <div class="desc">
								
							
<p style="font-size: 16px;color:black;">
<p><a href="<?php
	echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3));
?>" style="font-size: 18px;font-weight: bold;"><span>
               <?php
	echo ucfirst($row->title);
?></span></a>      </p>

<p style="font-size: 17px;color:black;">
<?php
echo ucfirst($row->description);
?>
</p>


</p>




<p style="text-align: center;padding:10px;">

<?php


if($next_course_check<=0){
if($course_count>1){
echo('<a href="'.base_url('index.php/course/lesson/'.$row->ID.'/previous/'.$row->courseID).'" class="gradient">PREVIOUS LESSON</a>');    
}
}elseif($next_course_check>0){
if($course_count>1){
echo('<a href="'.base_url('index.php/course/lesson/'.$row->ID.'/next/'.$row->courseID).'" class="gradient">NEXT LESSON</a>
');
}
}	


?>

</p> 




<div style="margin-top: 10px;padding:10px;margin-bottom: 1px;">							

<?php
echo('<p>');
if($row->file!=""){
echo '<img src="'.base_url($row->file).'" style="width:100%;max-height:450px;border:solid 5px silver;padding:10px;background:#FDFBB8;border-top:none;border-bottom:none;" class="round"/>';    
}	

echo('</p>');
?>
</div>                            
                           


<?php
	
if($lesson_content->num_rows()>0){
    
echo('<div style="margin-top:-10px;padding:10px;padding-top:0;">');

foreach($lesson_content->result() as $lesson_content){
    
//echo('<div class="down" style="height:50px;margin-top:-23px;"></div>');    
    
    
echo('<div style="color:#554F4F;font-size:16px;margin-bottom:10px;">');    
echo('<div class="col-md-13">
						<div class="clearfix">
							
							<div class="round" style="padding:10px;border:solid 5px silver;border-top:none;border-bottom:none;background:#FDFCBC;">
								
							
                            <h4 style="color:#FF4800;padding:5px;background:white;margin-top:10px;" class="round">
                            <img src="'.base_url($my_course->file).'" 
                            style="width:30px;height:30px;margin-right:5px;">'.ucfirst($lesson_content->title).'</h4>
								<p style="color:black;">'.ucfirst($lesson_content->description).'</p>');

                                

/**
 * Lesson content file check.
 */
$file=$lesson_content->file or FALSE;
if($file!=""){
$link='<a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/illustration/'.$lesson_content->ID).'" style="margin-right:10px;">Illustration</a>';
}else{
$link='';
}



if($user->ID==$row->author){
echo('<div style="margin-top:10px;">
<a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/delete/'.$lesson_content->ID).'" style="padding:5px;margin:0;padding-left:10px;padding-right:10px;">Delete</a></div>

<a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/edit/'.$lesson_content->ID).'" style="padding:5px;margin:0;padding-left:10px;padding-right:10px;">Edit</a>'.$link.'
</div>');    
}else{


                                
echo('<div style="float:right;">
<a href="" class="menus" style="float:right;padding:3px;margin:0;">Ask question</a></div>
<a href="" class="menus" style="float:right;padding:3px;margin:0;">Discussion</a>
'.$link.'</div>');
}						
                        
/**
* load dialog box.
*/                        
if($this->uri->segment(4)=='edit'){
if($this->uri->segment(5)==$lesson_content->ID){    
$data['content']=array($lesson_content->title,$lesson_content->description,$lesson_content->file);
$this->load->view('dialog/dialog_edit_lesson_content',$data);
}    
}elseif($this->uri->segment(4)=='illustration'){
if($this->uri->segment(5)==$lesson_content->ID){
$data['content']=array($lesson_content->title,$lesson_content->file);
$this->load->view('dialog/dialog_lesson_topic_illustration',$data);
}
} 
 
 
 
 
 
                        
                        
echo('</div></div>');    
echo('</div>');    
}    
unset($lesson_content);    
    
echo('</div>');
}else{
echo('No addition content for the course');
}
        
?>


<div style="padding: 30px; text-align: center;">
<a href="" class="menus">Tutorials</a>
<a href="" class="menus">Reference material</a>
<a href="" class="menus">Assignments</a>
</div>










                            
</div>




</div>
</div>
                    


</div>

</div>
<div class="col-lg-3">


<?php
echo ('<h3 style="margin-top:-50px;">
<img src="'.base_url($my_course->file).'" style="width:50px;height:50px;" class="img-circle">'.ucfirst($my_course->name).'</h3>');
$this->load->view('templates/search_bar');
	
?>









<?php
if($user->ID==$row->author){
echo('<h4 class="btn btn-brand" style="margin: 20px;"><a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/communication').'" style="color:white;">Talk to learners</a></h4>');
    
}else{
echo('<h4 class="btn btn-brand" style="margin: 20px;">Talk to course consultant</h4>');
}
	
?>
 
<ul>
<?php
if($user->ID==$row->author){
echo('<li><a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/add/content').'">Add lesson content</a></li>');
echo('<li><a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/add/tutorial').'">Add lesson tutorial</a></li>');
echo('<li><a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/add/assignment').'">Add lesson assignment</a></li>');
echo('<li><a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/add/reference').'">Add reference material</a></li>');
}else{
    
echo('<li><a href="">Ask a question</a></li>');
echo('<li><a href="">Excercises</a></li>');
echo('<li><a href="">Tutorials</a></li>');
echo('<li><a href="">Assignments</a></li>');
echo('<li><a href="">Join a discussion group</a></li>');   
     
}	
?>

</ul>

<p class="clearfix"></p>

<?php
if($other_lessons->num_rows()>0){
echo('<h5 style="text-align:center;">STUDY LESSONS </h5><hr/>');
echo('<ul style="padding:0;margin:0;">');
foreach($other_lessons->result() as $content){
echo('<li style="list-style-type: none;padding:0;">
<a href="'.base_url('index.php/lesson/'.$content->ID.'/'.$this->uri->segment(3)).'" style="color:#524C4C;font-size:15px;" >
<p class="gradient" style="margin:0px;">

'.ucfirst(character_limiter($content->title,25)).'</p></a></li>');    
}    
unset($content);    
echo('</ul>');

}
?>





<hr />







<div class="shadow_bottom1" style="color: black;border:solid 1px silver;background: aliceblue;">
<?php
	
echo $calendar;    
    
    
?>   

</div> 
<hr />

<div class="btn btn-brand" style="font-size: 15px;">
<a href="">
<strong style="color: white;"><?php
	echo $enrolled_course->num_rows();
?> Courses enrolled for</strong></div>

</a>

</div>


</div>


<div>
</div>






</div>
</div>
</div>
</div>