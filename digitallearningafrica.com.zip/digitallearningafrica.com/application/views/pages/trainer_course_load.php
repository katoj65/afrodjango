<?php



if($topic_load->num_rows()==1){
foreach($topic_load->result() as $row);
}else{
redirect(base_url());
}
?> 
 
 
 
 
 
 
 
  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>
                        COURSE CONTENT
<span style="font-size: 13px;padding-left:10px;">                        
<?php
if($application->num_rows()==1){
foreach($application->result() as $app);
$status=$app->status;
if($status=='request'){
echo('<span style="padding:4px;background:green;color:white;padding-left:10px;padding-right:10px;" 
class="border_radius">'.ucfirst($app->status).'</span>');
    
}elseif($status=='confirmed'){
echo('<span style="padding:4px;background:#2B3C69;color:white;padding-left:10px;padding-right:10px;" 
class="border_radius">'.ucfirst($app->status).'</span>');

}elseif($status=='declined'){
echo('<a href="'.base_url('index.php/trainer/course/re_appy/'.$app->ID).'"><span style="padding:4px;background:#ED4933;color:white;padding-left:10px;padding-right:10px;" 
class="border_radius">'.ucfirst($app->status).' application</span></a>');    
}

unset($pp);    
}elseif($application->num_rows()==0){
    
}	

?>
</span>                        
                        </h3>
                        <p><?php
                        
	echo ucfirst($description);
?> </p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                
                
<div class="col-lg-3 col-md-3">
<div>
<h3 style="margin: 0;padding: 0;margin-bottom: 20px;font-family: fantasy;text-align: center;">Calendar</h3>
<?php
echo $calendar;
?>

</div>          
<hr />




 </div>
                
                
                
                
                
                
                
                
                
 <div class="col-lg-6 col-md-6">
 <blockquote style="min-height: 300px;">
 <h3 style="margin-top: -20px;"><?php
echo ucfirst($row->name);
?></h3>                       
    
<p><?php
echo ucfirst($row->description);
?></p>

<hr />

<small style="font-size:19px;"><?php
echo $lessons->num_rows().' Topics available for the course';
?></small>	   

                        
<div>

<?php
if($lessons->num_rows()>0){
$this->load->model('Lesson_model');
$class=new Lesson_model;


foreach($lessons->result() as $content){
    
echo('<p><a href="'.base_url('index.php/trainer/course/content/'.$content->ID).'">
<h3 style="font-size:18px;">'.ucfirst($content->title).'</h3>
</a>
<div style="font-size:15px;line-height:20px;color:gray;">'.ucfirst(ellipsize($content->description,300)).'</div>
<small style="margin-top:10px;">');

if($class->get_lesson_content($content->ID)->num_rows()>1){
echo($class->get_lesson_content($content->ID)->num_rows().' Lesson topics available');    
}else{
echo($class->get_lesson_content($content->ID)->num_rows().' Lesson topic available');
}



echo('</small><hr/><p>');        
    
    
}    
unset($content);
}
?>



</div>                        
                        
                        

                    
</blockquote>
</div>







<div class="col-lg-3 col-md-3">

<?php
$this->load->view('pages/trainer_sidebar');
?>

</div>



















</div>

</div>

</div>
<!--./ Media Section End -->