<div>
<div style="text-align: center;"><h5><span class="shadow_bottom" style="font-size: 18px;">Communication to course learners</span></h5></div>
<div style="height: 500px;margin-top:30px;padding:0;" class="shadow_bottom">

<div style="padding: 10px;padding-bottom: 0;">

<a href="" class="menus">Notification</a>
<a href="" class="menus">Questions</a>
<a href="" class="menus">Discussions</a>
<a href="" class="menus">Messages</a>
 <a href="<?php
echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3));	
?>" style="padding: 5px;">Close</a>
<p></p>
</div>
<hr />




</div>
</div>
<hr />

