<style type="text/css">
<!--
#student_menu1 ul li{
float: left;
margin-right: 10px;
list-style: none;
}

#student_menu1 ul li a{
font-size: 13px;
padding: 5px;

}


.round,#student_menu1 ul li a{
border-top-right-radius: 40px;
-moz-border-radius-topright: 40px;
-webkit-border-top-right-radius:40px;
/*border radius left*/  
border-top-left-radius: 40px;
-moz-border-radius-topleft: 40px;
-webkit-border-top-left-radius: 40px;      

/*border radius right*/ 
border-bottom-right-radius: 40px;
-moz-border-radius-bottomright: 40px;
-webkit-border-bottom-right-radius: 40px;
/*border radius left*/  
border-bottom-left-radius: 40px;
-moz-border-radius-bottomleft: 40px;
-webkit-border-bottom-left-radius: 40px;    
}






	
-->
</style>


<?php
if($user->num_rows()==1){
foreach($user->result() as $user_row);
}
?>



<div id="student_menu1" style="padding-bottom: 30px;">
<ul>
<li><a href="<?php
	echo base_url('index.php/trainer/course/content/'.$this->uri->segment(4).'/add/presentation');
?>">Add presentation</a></li>


<li><a href="<?php
echo base_url('index.php/trainer/course/content/'.$this->uri->segment(4).'/add/file');
?>">Upload file</a></li>


<li><a href="<?php
	echo(base_url('index.php/'.$user_row->role.'/reference'));
?>"> Reference material</a></li>


<li><a href="<?php
	echo(base_url('index.php/'.$user_row->role.'/virtual/classroom'));
?>">Virtual classroom</a></li>



<li><a href="<?php
	echo(base_url('index.php/'.$user_row->role.'/assignments'));
?>"> Assessments</a></li>
<li><a href="<?php
	echo(base_url('index.php/'.$user_row->role.'/schedule'));
?>"> Examples</a></li>


<li><a href="<?php
	echo(base_url('index.php/trainer/course/content/'.$this->uri->segment(4)));
?>" style="padding: 5px;background: #ED4933;color:white;" class="border_radius"> Exit</a></li>

</ul>
</div>
<hr />










