<div class="container">
<div  class="row" style="padding: 20px;">
<div class="col-lg-9">
<?php	
if($course->num_rows()==1){
echo $this->session->flashdata('course_success');
foreach($course->result() as $row);
echo('<div style="padding:15px;">');

echo('<h4>'.ucfirst($row->name).'</h4>');
echo(ucfirst($row->description));
echo '<p style="padding-top:20px;"><strong>Duration in days</strong>:<span style="padding:10px;">'.$row->duration_days.'</span></p>';
echo('</div>');    
}    
    
?>

<hr />





<?php
if($row->author==$this->session->ID){
echo $this->session->flashdata('lesson_success');
$this->load->view('forms/add_course_content');
echo('<hr/>');
}	
    
    
    
    
    
    
    
?>










</div>
<div class="col-lg-3">
<?php
if(isset($row->image)){
    
echo('<div style="height:200px;background-image:url('.base_url($row->image).');background-size:cover;background-repeat:no-repeat;padding:10px;border:solid 10px #E9E9E9;" class="border_radius"></div>');    
echo('<hr/>');
}	
?>




</div>
</div>
</div>