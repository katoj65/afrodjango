
<div style="background: black;padding: 10px;text-align: center;color: white;">

<h3>Create account</h3>
</div>


	<div class="container">
		<div class="row">
			<div class="col-md-4"> 
            
           
            
            
            
            
            
     </div>       
     <div class="col-lg-4">
     
     <?php
	echo $this->session->flashdata('pass_error');
    echo $this->session->flashdata('user_exisit');
?>
     
     
     <?php $this->load->view('forms/register'); ?>
     
     
     
     
     </div>       
            
            
            
            
            
       <div class="col-lg-4" >
     
     
     
     
     
     
     </div>       
            
            
            
            
            
            
            
            
            
            
            
            
            
            
 </div>           
 </div>           
 </div>           