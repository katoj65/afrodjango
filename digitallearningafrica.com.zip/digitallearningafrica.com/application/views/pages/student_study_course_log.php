<?php
if($course_first->num_rows()==1){
foreach($course_first->result() as $result);  
$data['result']=$result; 

if($this->uri->segment(2)=='overview'){
$this->load->view('dialog/student_tutorial_overview',$data);
}
 
}else{
redirect(base_url());
}	
?>











<div class="container">
<div class="row pad-top-botm">



<div class="col-lg-4 col-md-4">

<?php
$this->load->view('pages/sidebar_right',$data);
?>

</div>










<div class="col-lg-8 col-md-8">
<blockquote style="border-left-width: 1px;">
<div class="row">
<div class="col-lg-6 col-md-6">
<h4>
<span style="padding: 10px;background:#ED4933;color:white;font-weight:normal;font-size:15px;" class="border_radius">
<?php
echo $count_course.' '.$course_load->name.' tutorials';
?>
</span>
</div>



<div class="col-lg-6 col-md-6">
<?php
$this->load->view('templates/search_bar');
?>

</div>



</div>






</h4>






<h3 style="font-weight: bold;margin-top: 30px;margin-bottom:20px;color:#2B3C69;">
<?php
echo ucfirst($result->name);
?>
</h3>






<div>
<p style="font-size: 18px;margin-top: 10px;">
<?php
echo ucfirst($result->description);
?>
</p>



<hr />



<small style="color:#ED4933;font-size:20px;">


<?php
echo $lessons->num_rows();
?> Presentations for the tutorial 



<a href="<?php
echo base_url('index.php/student/overview/'.$result->ID);
?>"><span class="preview btn btn-success">Overview</span></a> </small>


</div>                






<div style="margin-top: 10px;padding: 30px;padding-top: 10px;" class="border_radius">
<?php
if($lessons->num_rows()>0){
foreach($lessons->result() as $content){
$data['content']=$content;
echo('<div style="padding:10px;margin-bottom:10px;">');

echo('<h5 style="font-size:17px;">
<img src="'.base_url('icons/topic.png').'" style="width:30px;height:30px;"/>
<span style="padding:10px;background:#F7F7F7;color:#2E86C1;font-size:18px;" class="round">'.ucfirst($content->title).'</span></h5>');    
echo('<p style="font-size:15px;margin-top:30px;">'.ucfirst(ellipsize($content->description,300)).'</p>');    


echo('<div style="text-align:center;">
<a href="'.base_url('index.php/student/course/presentation/'.$content->ID).'">
<span style="padding:5px;background:#F7F7F7;padding-left:10px;padding-right:10px;border-right:solid thin silver;border-left:solid thin silver;color:#ED4933;" class="round">Presentation</span></a></div>');

echo('<div>');
//$this->load->view('pages/sub_topics',$data);
echo('</div>');

echo('</div>');
}    
}else{
echo('<div style="color:gray;">No content</div>');
}	
?>
</div>
</blockquote>

</div>






















</div>
   
    