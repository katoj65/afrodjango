<?php
if($new->num_rows()==1){
foreach($new->result() as $row);    
}else{
redirect(base_url());
}	   
?>

<section id="home-service" style="margin-top:0px;">
<div class="container">
<div class="row " style="text-align: center;">

  <section id="service-info">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-12 col-md-12">
                    <h3 class="clr-main"><?php
	echo('<img src="'.base_url($my_course->file).'" class="icon"/>');
?><strong>
                    

<?php
echo ucfirst($row->title);
?> 
 

</strong></h3>
<p style="font-size: 15px;text-align: left;">  
<?php
echo ucfirst($row->description);
?>                 
</p>
<hr /> 
<div  style="text-align: left;">
<ul class="menus">
<li><a href="" style="font-size: 15px;">Add content</a></li>
<li><a href="" style="font-size: 15px;">Add tutorial</a></li>
<li><a href="" style="font-size: 15px;">Add assignment</a></li>
<li><a href="" style="font-size: 15px;">Add reference material</a></li>
<li><a href="" style="font-size: 15px;">Schedule classroom live</a></li>
<li><a href="" style="font-size: 15px;">Discussions</a></li>


</ul>


</div> 
 

</div>
</div>
</div>
</div>


<div class="row" style="margin-top:-40px;">
<div class="col-lg-9">



<div style="margin-top: 1px;">


<?php

if($row->author==$this->session->ID and ($user->role=='course' or $user->role=='teacher')){
$this->load->view('forms/add_lesson_content');
}
?>

</div>






<div>


</div>





<?php
/**
 * if($lessons->num_rows()>0){
 * foreach($lessons->result() as $content){
 * 	                  
 * echo('<div class="col-lg-12 col-md-12">
 * <div class="media">
 * <div class="pull-left">
 * <i class=" fa fa-folder-open-o fa-4x rotate-icon " style="color:green;"></i>
 * </div>
 * <div class="media-body">
 * <a href="'.base_url('index.php/course/'.$content->ID).'/'.strtolower($my_course->name).'">
 * <h3 class="media-heading" 
 * style="font-size:15px;color:#FF6A00;"><strong>'.ucfirst(character_limiter($content->title,200)).'</strong></h3></a>
 * <p style="padding:5px;border-bottom:solid 5px #E0E0E0;font-size:15px;height:140px;overflow:hidden;">
 * '.ucfirst(character_limiter($content->description,500)).'
 * </p>
 * </div>
 * </div>
 * </div>');


 * }
 * }else{
 * echo('<div>No content</div>');
 * }
 */
?>



</div>






<div class="col-lg-3">
<div>


<?php
if($row->file!=""){
echo('<img src="'.base_url($row->file).'" style="width:100%;padding:10px;border:solid thin silver;" class="border_radius"/>');	
}
?>





<h3 style="font-size: 20px;font-weight: bolder;color: #FF6A00;">
<?php
echo ('<img src="'.base_url($my_course->file).'" style="width:50px;height:50px;margin-right:20px;"/>');
echo strtoupper($my_course->name);
?>
</h3>
</div>
<hr />
<div>
<?php
echo $calendar;
?>
</div>
<hr />



<div style="text-align: center;" class="button1">
<a href="#" style="color:white;font-size: 17px;">Talk to course consultants</a>
</div>



<div style="margin-top: 50px;">
<a href="<?php
	echo base_url('index.php/courses/all');
?>" style="color:#78909C;"><h3 style="font-size: 40px;text-align: center;">
<?php

echo('<span style="padding:10px;background:#34296F;color:white;" class="border_radius">'.$count_courses.'</span>');

echo('<p style="font-size:25px;padding:20px;">');
if($count_courses>1){
echo('Courses available');
}else{
echo('Couse available');
}
echo('</p>');

?>
</h3></a>
</div>





</div>
</div>
</div>
</section>
</section>










<div id="just-middle-row" style="background: #E0E0E0;min-height: 200px;color:gray;">
<div class="container">
<div class="row pad-top-botm">

<div class="col-lg-12 col-md-12">
<h5>
<?php

echo $note;

?>
</h5>


</div>




</div>
</div>
</div>


