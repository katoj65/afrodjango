<?php
if($lesson->num_rows()==1){
foreach($lesson->result() as $row);    
}else{
redirect(base_url('index.php'));    
}	
    
?>

<section id="home-service" style="margin-top:0px;">
<div class="container">
<div class="row " style="text-align: center;">

  <section id="service-info">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-12 col-md-12">
                    <h3 class="clr-main">
                    
              
<strong>
 <?php
echo ucfirst($row->title);
?>                   

</strong>

</h3>
<p style="font-size: 16px;text-align: left;">  
<?php
echo ucfirst($row->description);
?>         
</p>
<hr />

<div style="text-align: left;">
<ul class="menus" style="float: left;">
<?php
if($user->role=='course' or $user->role=='teacher'){
if($row->author==$this->session->ID){
echo('
<li><a href="'.base_url('index.php/lesson/'.$row->ID.'/ask/question').'" style="font-size: 16px;">Ask question</a></li>
<li><a href="'.base_url('index.php/lesson/'.$row->ID.'/add/content').'" style="font-size: 16px;">Add content</a></li>
<li><a href="" style="font-size: 16px;" >Add tutorial</a></li>
<li><a href="" style="font-size: 16px;" >Add exercises</a></li>
<li><a href="" style="font-size: 16px;" >Assignments</a></li>
<li><a href="" style="font-size: 16px;" >Discussions</a></li>');    
}    
}else{
    
echo('<li><a href="" style="font-size: 16px;">Ask question</a></li>
<li><a href="" style="font-size: 16px;" >Exercises</a></li>
<li><a href="" style="font-size: 16px;" >Tutorials</a></li>
<li><a href="" style="font-size: 16px;" >Assignments</a></li>
<li><a href="" style="font-size: 16px;" >Discussions</a></li>');    
    
}	
?>


<?php

echo('<li><a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/classroom').'" class="btn btn-success" style="padding-left:10px;padding-right:10px;">Class room Live</a></li>');    

echo('<li><a href="" class="btn btn-danger" style="padding-left:10px;padding-right:10px;">Next lesson</a></li>');  
 
      
?>

</ul>
</div>






                    
<br />
<br />
</div>
</div>
</div>
</div>




<div class="container" style="margin-top: -60px;">
<div class="row">
<div class="col-lg-8" style="padding-right: 30px;">


<div>

<?php
if(($user->role=='teacher') or ($user->role=='course')){
if($row->author==$this->session->ID){
if($this->uri->segment(3)=='add'){
if($this->uri->segment(4)=='content'){
$this->load->view('forms/add_lesson_content');   
echo('<hr/>');    
}


    
    
}elseif($this->uri->segment(3)=='ask'){
if($this->uri->segment(4)=='question'){
$this->load->view('forms/lesson_question');
}    
}elseif($this->uri->segment(3)=='classroom'){

$this->load->view('dialog/dialog_class');

}elseif($this->uri->segment(3)=='reference'){
$this->load->view('forms/add_reference_material');   
}    





}    
}	
?>

</div>


<div>
<?php
echo $this->session->flashdata('faq_success');	
?>
</div>







<div style="border:solid thin #D6DBDF;">


<?php
if($lesson_content->num_rows()>0){
foreach($lesson_content->result() as $content){
echo('<div style="background:white;padding:10px;">'); 
echo('<h5 style="color:#34296F;padding-left:10px;font-size:20px;padding-right:10px;"><img src="'.base_url($my_course->file).'" style="width:30px;height:30px;margin-right:10px;">'.ucfirst($content->title).'</h5>'); 
echo('<div style="font-size:15px;padding:10px;">'.ucfirst($content->description).'</div>');
echo('<hr/></div>');    


}    

unset($content);   
}else{
$this->load->view('forms/add_lesson_content');
}	
    
    
    
    
?>



</div>

                    
                    












</div>
<div class="col-lg-3">




<div>
<?php
if($row->file!=""){
echo('<img src="'.base_url($row->file).'" style="width:100%;padding:10px;border:solid thin silver;" class="border_radius"/>');	
}
?>

</div>









<hr />




<div>
<?php
echo $calendar;
?>
</div>
<hr />

<div style="text-align: center;" class="button1">
<a href="#" style="color:white;font-size: 17px;">Talk to course consultants</a>
</div>

<hr />


<div style="text-align: center;">
<a href=""><h4><?php
echo $count_courses;	
?> Other courses</h4></a>

</div>











</div>









</div>
</div>












</section>
</div>
</section>
