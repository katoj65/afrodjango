<?php
if($course_first->num_rows()==1){
foreach($course_first->result() as $result);    
}else{
redirect(base_url());
}	
?>

  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>TUTORIALS</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                

                 
<div class="col-lg-3 col-md-3" style="padding: 10px;">

<h3 style="text-align: center;margin-bottom: 20px;"> 
<span style="font-family: fantasy;">TOPICS</span></h3>


<div style="margin-top: 10px;">
<ul>
<?php
if($topics->num_rows()>0){
foreach($topics->result() as $topic){
echo('<li style="list-style:none;">
<div><a href="#" style="font-size:14px;">'.ucfirst(ellipsize($topic->name,25)).'</a></div></li>');
    
}    
}

?>

</ul>  
<hr />    
</div>

         
 </div>
 
 
 
 
 
 
 
 
                               
                
 <div class="col-lg-9 col-md-9">
 <blockquote style="min-height: 300px;">
 <h3 style="margin-top: -20px;">Hands on practical sessions</h3>                       
 <?php
if($couse_tutorials->num_rows()>0){
     
foreach($couse_tutorials->result() as $result){
echo('<div style="margin-bottom:15px;"><p><a href="'.base_url('index.php/student/tutorial/'.$result->ID).'" style="color:black;">
'.ucfirst($result->title).'</a></p>
<small>'.ucfirst($result->name).' 
<span style="padding:5px;background:#2B3C69;color:white;" class="border_radius">Video tutorial</span></small></div>');	   
	}
unset($result);    
 }else{
 echo('No content');
 }
                        
                        
                        
                        
                        ?>
                    
                    
                    
                    
                        
                    
                    
                    
                    
                    </blockquote>

                </div>
            </div>

        </div>

    </div>
    <!--./ Media Section End -->