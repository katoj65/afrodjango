



<?php

if($course_first->num_rows()==1){
foreach($course_first->result() as $result);    
/**
 * Dialog boxes.
 */

if($page=='student'){




}




}else{
redirect(base_url());
}	

?>


<div id="request-quote" style="background: #F7F7F7;color: black;">
<div class="container">
<div class="row">
                
                
<div class="col-lg-9">
<h3 style="font-weight:bold;font-size:17px;margin-right: 70px;">
<span style="padding: 10px;background: white;border:solid 2px #D6DBDF;" class="round">
<a href="<?php
echo base_url('index.php/student');	
?>" style="color: black;">
<?php
echo ucfirst($result->name);
?>
</a>
</span>






<?php

if($enroll==0){
echo('<span style="float: right;">
<a href="'.base_url('index.php/student/enroll/'.$course_load->ID).'" style="background:#FF4800;padding:10px;font-size:15px;color:white;font-weight:normal;" class="border_radius">
Enroll for course</a></span>');    
}elseif($enroll==1){

if($enrollment_info->num_rows()==1){
foreach($enrollment_info->result() as $enroll_row);
}

echo('<span style="float: right;">
<a href="#" style="background:#AEB6BF;padding:10px;font-size:14px;color:white;font-weight:normal;" class="border_radius" onclick="topic_menu();">Enrolled for '.($topics->num_rows()).' Topics</a></span>');



unset($enroll_row);

}	


?>

</h3>




<div style="margin-top: 50px;">
<p style="font-size: 15px;text-align: center;">
<div class="row">
<?php
echo form_open();
?>


<div class="col-lg-2">
<div style="height: 100px;background: #AEB6BF;border:solid thin gray;"></div>
</div>






<div class="col-lg-10" style="padding-right: 100px;">
<div style="color: red;"><?php
echo validation_errors();	
?></div>
<div style="color: green;"><strong>
<?php
echo $this->session->flashdata('message');
?></strong></div>
<div style="padding: 10px;background: #D6DBDF;" class="border_radius">
<textarea style="height: 100px;border:solid 5px silver;margin-top:0;padding: 15px;width:100%;" 
class="" placeholder="Write your question" name="question"></textarea>
</div>

<div style="margin-top: 20px;">
<span style="font-size: 15px;padding-bottom: 10px;">
<input type="submit" value="Submit question" style="font-size:15px;padding: 7px;
background:#FF6A00;color:white;border:solid thin white;" class="border_radius" />





<span style="margin-left: 20px;">
<a href="" style="margin-right: 15px;">Recent questions</a>
<a href="" style="margin-right: 15px;">Top questions</a>
<a href="" style="margin-right: 15px;">Talk to consultants</a>
</span>





</span>

</div>
</div>
</form>
</div>
</p>
</div>









<div class="border_radius" style="padding: 20px;min-height: 500px;">

<h4 style="text-align: center;margin-top:30px;">
<strong class="round" style="border:solid 2px #E5E8E8;padding:10px;margin-top: -10px;">Frequently asked questions</strong>
</h4>



<div style="margin-top: 20px;">




<?php
	
if($faq->num_rows()>0){
echo('<table style="margin-right:60px;">');
echo('<tr><th>
<span style="padding:10px;background:white;border:solid 2px #E5E8E8;" class="round">
Questions</span></th><th style="text-align:center;">
<span style="padding:10px;background:white;border:solid 2px #E5E8E8;" class="round">Answer / solution</span></th></tr>');
foreach($faq->result() as $row){
echo('<tr>');    
echo('<td style="padding:20px;">');
echo('<div style="font-size:16px;"><strong style="margin-right:10px;color:#34296F;font-size:18px;">'.ucfirst($row->fname).' '.ucfirst($row->lname).' <span style="font-size:13px;">asked on '.nice_date($row->date,'D, d-M-Y').'</span></strong> '.ucfirst($row->question).'</div>');
echo('<div style="margin-top:5px;"></div>');
echo('</td>');    
echo('<td style="width:50%;background:white;border:solid 3px #E5E8E8;padding:5px;" valign="top">mmlmlml');



echo('</td>');   
    
    
    
    
    
    
echo('</tr>');    
}    
echo('</table>');
unset($row);    
    
}else{
echo('<div>Ask question</div>');
}    
    
    
    
    
    
    
    
    
    
    
?>








</div>












</div>





















</div>

<div class="col-lg-3">



<form role="form" style="margin-top: 10px;">
<div class="input-group">
<input type="text" class="form-control" autocomplete="off" placeholder="Search...."/>
<span class="input-group-btn">
<button class="btn btn-primary" type="submit">Search</button>
</span>
</div>
</form>







<div style="margin-top: 50px;">
<h4 style="margin-bottom: 20px;">
Academic calendar</h4>

<?php
echo $calendar;
?>

</div>





<div style="margin-top: 20px;">
<a href="'.base_url('index.php/').'" style="background:#FF4800;padding:10px;font-size:15px;color:white;" class="round">Talk to course consultant</a>
</div>



</div>





















</div>
</div>
</div>
</div>
