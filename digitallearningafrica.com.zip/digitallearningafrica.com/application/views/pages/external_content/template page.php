<?php
if($course_first->num_rows()==1){
foreach($course_first->result() as $result);    
}else{
redirect(base_url());
}	
?>











<div class="container">
<div class="row pad-top-botm">
<div class="col-lg-7 col-md-7">
<h4>

<span style="padding: 10px;background: #565AB1;color:white;border:solid thin #2B3C69;font-weight:normal;" class="border_radius">

</span>
</h4>






<h2 style="font-weight: bold;margin-top: 50px;">
heading of the content
</h2>




<div style="margin-bottom: 10px;">
<p style="font-size: 15px;margin-top: 10px;">
content description
</p>
</div>                





<hr style="border-top:solid 1px #D6DBDF;" />







<div style="margin-top: 20px;background: white;padding: 30px;border:solid 1px #D6DBDF;" class="border_radius" class="border_radius">





main content













</div>



























</div>
























<div class="col-lg-5 col-md-5">


<form role="form" style="margin-top: 10px;">
<div class="input-group">
<input type="text" class="form-control" autocomplete="off" placeholder="Search...."/>
<span class="input-group-btn">
<button class="btn btn-primary" type="submit">Search</button>
</span>
</div>
</form>








<ul>
<li style="padding: 5px;list-style:none;"><h3>Topics</h3></li>

<li style="list-style:none;margin-bottom: 25px;">
<a href="<?php echo base_url('index.php/student/consultants');?>" style="margin: 5px;background:#ED4933;padding: 5px;color:white;" class="border_radius">Consultants</a>

<a href="<?php echo base_url('index.php/student/discussion');?>" style="margin: 5px;background:#2B3C69;padding: 5px;color:white;" class="border_radius">Discussion</a>

<a href="<?php echo base_url('index.php/student/tutorials');?>" style="margin: 5px;background:#2B3C69;padding: 5px;color:white;" class="border_radius">Tutorials</a>

</li>


<li>sidebar 1</li>
<li>sidebar 2</li>
<li>sidebar 3</li>


<li style="padding: 20px;margin-bottom: 5px;list-style:none;">
<div style="margin: 30px;margin-top:0;margin-left: 10px;">
<h4>Study calendar</h4>
<?php
echo $calendar;
?>
</div>
</li>






</ul>





</div>
</div>
</div>
   
    