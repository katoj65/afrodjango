<?php
if($course_first->num_rows()==1){
foreach($course_first->result() as $result);    
}else{
redirect(base_url());
}	
?>

<!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>EVENTS</h3>
                        <p><?php
	echo ucfirst($description);
?></p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                
                
<div class="col-lg-3 col-md-3">
<h3 style="font-family: fantasy;text-align: center;">Calendar</h3>


<div>
<?php
echo $calendar;
?>
</div>          
<hr /> 
</div>
                
                
                
                
                
                
                
                
                
 <div class="col-lg-8 col-md-8">
 <blockquote style="min-height: 300px;">
<?php

if($get_events->num_rows()>0){
$title=array();
$title[0]=false;
$content=array();
$content[0]=false;
$date=array();
$date[0]=false;
$id=array();
$id[0]=false;

foreach($get_events->result() as $event){
$title[]=ucfirst($event->event);
$content[]=ucfirst($event->description);
$date[]=$event->day.$event->time;
$id[]=$event->ID;
}    
   
   


for($x=1;$x<=$get_events->num_rows();$x++){
    
if($x==1){
$day=nice_date($date[$x],'ymd');
if($day==date('ymd')){

echo('<div style="margin-bottom:30px;">
<a href="'.base_url('index.php/student/event/'.$id[$x]).'"><h3 style="margin:0;padding:0;">'.ucfirst($title[$x]).'</h3></a>'); 
echo('<p style="margin-top:15px;">'.ucfirst($content[$x]).'</p>');
echo('<small><span style="padding:5px;background:#ED4933;color:white;" class="border_radius">
Happening Today, '.nice_date($date[$x],'H:i').'</span></small>');
echo('<hr/></div>');
echo('<h3 style="margin-bottom:20px;">Upcoming events</h3>');    


}else{
echo('<div style="margin-bottom:30px;">
<a href="'.base_url('index.php/student/event/'.$id[$x]).'"><h3 style="margin:0;padding:0;">'.ucfirst($title[$x]).'</h3></a>'); 
echo('<p style="margin-top:15px;">'.ucfirst(ellipsize($content[$x],300)).'</p>');
echo('<small>'.nice_date($date[$x],'D, d-M-Y, H:i').'
<span style="padding-left:10px;">
<span style="padding:5px;background:#ED4933;color:white;" class="border_radius">Coming up soon</span>
</span>
</small>');
echo('<hr/></div>');
echo('<h3 style="margin-bottom:20px;">Upcoming events</h3>');
}





}else{
echo('<div style="margin-bottom:30px;font-size:15px;">
<h3 style="margin:0;padding:0;font-size:18px;"><a href="'.base_url('index.php/student/event/'.$id[$x]).'">'.ucfirst($title[$x]).'</a></h3>'); 
echo('<p style="margin-top:15px;color:gray;padding:0;margin:0;">'.ucfirst(ellipsize($content[$x],180)).'</p>');
echo('<small style="font-size:15px;">'.nice_date($date[$x],'D, d-M-Y, H:i').'</small>');
echo('</div>');
}        

}    







    
unset($event);    
    
}else{
echo('No events');
}











	
?>














                    
                    
                    
                    
                    
                    
                    

                    
                    
                        
                    
                    
                    
                    
                    </blockquote>

                </div>
            </div>

        </div>

    </div>
    <!--./ Media Section End -->









   
    