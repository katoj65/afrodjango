 
 
  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>Discussion on <?php
	echo strtolower($heading);
?>
</h3>
<p><?php
ucfirst($description);
?></p>
<br />
<br />
</div>
</div>
                
                
                
                
                
                
<div class="col-lg-3 col-md-3" style="">

 <h3 style="margin-top: -20px;text-align: center;">
 <span style="font-family: fantasy;">TOPICS</span></h3>

<div style="margin-top: 30px;">
<ul>
<?php
if($topics->num_rows()>0){
foreach($topics->result() as $topic){
echo('<li><div><a href="#" style="font-size:17px;">'.ucfirst(ellipsize($topic->name,20)).'</a></div></li>');
    
}    
}

?>

</ul>  
<hr />    
</div>

<h3 style="text-align: center;margin-bottom: 30px;"> <span style="font-family: fantasy;">CONSULTANTS</span></h3>



<?php
for($x=1;$x<=4;$x++){
echo('<div style="height:100px;margin:10px;background:#EBEDEF;" class="border_radius"></div>');
}
?>






</div>
                
                
                
                
                
                
                
                
                
<div class="col-lg-7 col-md-7" style="padding-right:100px;">
<blockquote style="min-height: 300px;">                      





<h4><span style="padding: 10px;background: white;border-bottom:solid 2px silver;" class="round">Start a discussion below</span></h4>

<div>
<?php
echo $this->session->flashdata('submitted');
?>
</div>


<?php
echo form_open();
?>
<div style="color: red;font-size: 13px;padding-top: 10px;"><?php
echo validation_errors();
?></div>
<table style="width: 100%;margin-bottom: 30px;margin-top: 30px;" class="shadow1">
<tr style="border: solid 15px white;">
<td>
<textarea style="width:100%;background-color: white;padding: 10px;border:none;" 
placeholder="Write...." name="discuss">
</textarea>  
    
</td>
<td style="width: 50px;background: white;">
<input type="submit" value="Submit" style="float: right;background:white;color:black;
 border:none;font-size:15px;padding:5px;" class="round"/>
</td>
</tr>
</table>
</form>


<h5 style="margin-bottom: 20px;">
<span style="padding: 5px;border-bottom:solid 2px silver;padding-left:10px;padding-right:10px;font-weight:bold;background: white;" class="round">Previous discussions</span></h5>

<?php




if($discussion->num_rows()>0){
$this->load->model('Discussion_model');
$class=new Discussion_model;


foreach($discussion->result() as $content){    
echo('<div style="margin-bottom:10px;">
<p style="font-size:16px;">
'.ucfirst($content->content).'
</p>
<small> '.ucfirst($content->fname).' '.ucfirst($content->lname).'
<span style="margin-left:20px;padding:5px;font-size:13px;padding-left:10px;padding-right:10px;background:white;border:solid thin #D6DBDF;" class="round">'.nice_date($content->date,'d - m - Y').'</span>
<a href="#" style="font-size:13px;margin-left:10px;">Comment</a>

</small></div>');    
    
/**
*Comments for the discussion. 
*/    
$comment=$class->get_discussion_comments($content->ID);

if($comment->num_rows()>0){
echo('<div style="margin-left:20px;padding:10px;font-size:13px;line-height:20px;margin-top:10px;background:white;margin-top:20px;border:solid thin #D6DBDF;" class="border_radius">');


foreach($comment->result()as $row){
echo('<div style="padding:10px;font-size:15px;margin-bottom:10px;" class="border_radius">');
echo('<small style="padding-top:5px;"><strong style="margin-right:10px;">'.ucfirst($content->fname).' '.ucfirst($content->lname).'</strong> Commented
<span style="margin-left:10px;" class="round">'.nice_date($row->date,'d - m - Y').'</span>
</small>'); 
echo('<div style="margin-top:10px;">'.ucfirst($row->comment).'</div>');
   
echo('</div>');
}


echo('</div>');
}else{

}    
    
    
    
    
    
    
    
    
    
echo('<hr style="border:solid thin #D6DBDF;"/>');    





}    
unset($content);    
}else{
echo('Start a discussion!');
}






?>








  

                    
</blockquote>
</div>











<div class="col-lg-2 col-md-2">

<h3 style="text-align: center;"> <span style="font-family: fantasy;font-size: 18px;">PARTICIPANTS</span></h3></h3>


<div>


<?php
echo('<ul style="padding:0;margin:0;margin-top:50px;">');

for($x=1;$x<=6;$x++){
echo('<li style="list-style:none;">');
echo('<a href="#">
<div style="padding:10px;margin-bottom:5px;border:solid thin silver;text-align:center;background:white;" class="round">some content</div></a>');
echo('</li>');    
}

echo('</ul>');
?>





</div>











</div>












</div>
</div>
</div>
    <!--./ Media Section End -->
    
    
    
    