<?php
if($course_first->num_rows()==1){
foreach($course_first->result() as $result);    
}else{
redirect(base_url());
}	
?>

  <!--./ stats div end -->
      <div id="media-sec" style="background: white;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>STUDY GROUPS</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                
                
<div class="col-lg-3 col-md-3" style="padding: 30px;">
<h3 style="font-family: fantasy;">Consultants</h3>


      
</div>
                
                
                
                
                
                
                
                
                
 <div class="col-lg-9 col-md-9">
 <blockquote style="min-height: 300px;">
 <h3 style="margin-top: -20px;">Group activities</h3>                       
                    <?php
	for($x=1;$x<=5;$x++){
echo('<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
<small>Consectetur adipiscing elit</small>');	   
	}
                        
                        
                        
                        
                        ?>
                    
                    
                    
                    
                        
                    
                    
                    
                    
                    </blockquote>

                </div>
            </div>

        </div>

    </div>
    <!--./ Media Section End -->