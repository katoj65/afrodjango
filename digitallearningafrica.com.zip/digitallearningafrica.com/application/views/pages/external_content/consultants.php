<?php
if($course_first->num_rows()==1){
foreach($course_first->result() as $result);    
}else{
redirect(base_url());
}	
?>

  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>Talk to consultants</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                
                
<div class="col-lg-8 col-md-8" style="padding: 30px;">
<h3 style="margin-top: -20px;">Previous consultations</h3> 
  
<?php
for($x=1;$x<=5;$x++){
echo('<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
<small>Consectetur adipiscing elit</small>');	   
}
                        
 ?>  
  
      
 </div>
                
                
                
                
                
                
                
                
                
 <div class="col-lg-4 col-md-4">
 <blockquote style="min-height: 300px;">
 <h3 style="font-family: fantasy;margin: 0;padding: 0;">Course consultants</h3>   
                      
    
                    
                    
                    
</blockquote>
</div>
</div>
</div>
</div>
    <!--./ Media Section End -->