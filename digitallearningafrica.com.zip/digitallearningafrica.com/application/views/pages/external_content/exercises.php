<?php
if($course_first->num_rows()==1){
foreach($course_first->result() as $result);    
}else{
redirect(base_url());
}	
?>





  <!--./ stats div end -->
<div id="media-sec" style="background: #F7F7F7;color: black;">
<div class="container">
<div class="row">
<div class="col-lg-12 col-md-12" >
<div class="text-center">
<h3>ASSESSMENTS</h3>
<p>
<?php
echo ucfirst($description);
?>
</p>
<br />
<br />
</div>
</div>
                
                
<div class="col-lg-3 col-md-3">
<h3 style="font-family: fantasy;margin: 0;padding: 0;margin-bottom: 20px;text-align: center;">Calendar</h3>

<?php
echo $calendar;
?>
         





</div>
                
                
                
                
                
                  
                
<div class="col-lg-9 col-md-9">
<blockquote style="min-height: 300px;">
<h3 style="margin-top: -20px;font-size: 18px;">List of assessments and assignments</h3>                       
<?php
if($assignments->num_rows()>0){


foreach($assignments->result() as $result){
echo('<p><a href="'.base_url('index.php/student/assignment/'.$result->ID).'" style="color:black;">'.ucfirst(ellipsize($result->title,80)).'</a></p>
<small>'.ucfirst($result->name).'</small>');	   
}

unset($result);
}else{
echo('No content');
}
                        
?>
                    
                    
</blockquote>
</div>
</div>
</div>
</div>
<!--./ Media Section End -->