<?php
$this->load->model('Lesson_model');	
$class=new Lesson_model;	
    
       
?>