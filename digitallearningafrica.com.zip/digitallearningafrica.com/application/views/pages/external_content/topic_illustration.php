 <?php
if($course_first->num_rows()==1){
foreach($course_first->result() as $result);    


if($lesson_content->num_rows()==1){
foreach($lesson_content->result() as $content);
}else{
redirect(base_url());
}




}else{
redirect(base_url());
}	
?>

 
 
 
 
 
 
  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>Illustration</h3>
                        <p><?php
	echo ucfirst($description).' '.$result->name;
?></p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                
                
<div class="col-lg-3 col-md-3">
<h3 style="font-family: fantasy;margin: 0;padding: 0;text-align: center;margin-bottom: 10px;">Calendar</h3>
<div>
<?php
echo $calendar;
?>
<hr />
</div>          







</div>
                
                
                
                
                
                
                
                
                
 <div class="col-lg-9 col-md-9">
 <blockquote style="min-height: 300px;">
 <h3 style="margin-top: -20px;"><?php echo ucfirst($content->title);	?></h3>                       
                   
 <p style="font-size: 16px;"><?php
echo ucfirst($content->description);
?></p>

<small>View Illustraion</small>                   
<div style="margin: 50px;">
<?php
if($content->file!=""){
$file=base_url($content->file);

echo('<img src="'.$file.'" style="width:70%;border:solid 40px silver;margin:10px;border-left:none;border-right:none;" class="border_radius">');    
    
    
}
?>

</div>                    
                    
                        
                    
                    
                    
                    
                    </blockquote>

                </div>
            </div>

        </div>

    </div>
    <!--./ Media Section End -->