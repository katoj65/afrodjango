<div style="background:black;text-align: center;padding: 10px;color: white;">
<h3><?php
echo $heading;	
?></h3>
</div>



<div style="background: aliceblue;padding-bottom: 30px;">
<div class="container">
<div class="row">
<div class="col-lg-13" style="">

<div class="col-lg-8">


<p style="padding: 10px;">
<?php
echo '<div style="font-size:25px;"><img src="'.base_url($my_course->file).'" style="width:30px;height:30px;margin-right:10px;">'.ucfirst($my_course->name).'</div>';
echo('<div>'.ucfirst(ellipsize($my_course->description,300)).'</div>');
?>
</p>




</div>




<div class="3" style="padding: 20px;">
<?php
echo ucfirst($attributes);
?>
</div>









</div>

</div>
</div>
</div>
















































<div class="serviceBlock">
<div class="container">
<div class="row" style="padding: 20px;">
<div class="col-lg-13">

<?php
if($course->num_rows()==1){
foreach($course->result() as $row);    
}else{
redirect(base_url());
}	
?>




<div class="row" style="min-height: 500px;margin-top:-40px;">
<div class="col-lg-8" style="margin-top: 0; padding-top: 0;">

	<h3 style="padding:30px;padding-bottom: 30px;color:gray;margin-bottom: 20px;margin-top: -20px;text-align: center;">
    
    <span>
    
    <?php
    

	echo ucfirst($row->name);
?>
</span>

</h3>
                       <div class="clearfix" style="margin: 0;">
							
							<div class="desc">
								
<?php
echo $this->session->flashdata('enrollment_cancel');	
?>                             
                                
                                
                                
                                
						
<p style="color: black;font-size: 18px;">

<?php
echo ucfirst($row->description);
?>

</p>
<div style="float: right;"><span>


 
</span></div>
</div>
</div>















<div style="text-align: center;font-size: 17px;padding-top:40px;" >


<?php
	
if($first_lesson->num_rows()==1){
foreach($first_lesson->result() as $lesson1);
echo('<a href="'.base_url('index.php/lesson/'.$lesson1->ID.'/'.$row->ID).'">
<span class="btn btn-brand" style="font-size:18px;border-bottom:solid 1px silver;">Start Now (');

echo $lessons->num_rows();	
if($lessons->num_rows()>1){
echo(' lessons');
}else{
echo(' lesson');
}

echo(')</span></a>');

}else{
    
    
    
    
}    
    
    
    
    
?>


</div>



<div style="margin-top: 20px;">

<?php
	
if($lessons->num_rows()>0){



foreach($lessons->result() as $content){  
  
//echo('<div style="height:10px;"></div>');    
    
echo('<div class="col-md-13" style="margin-bottom:10px;">
						<div class="clearfix">
							 
							<div class="desc">
								
							<div style="padding:0;">
                            <a href="'.base_url('index.php/lesson/'.$content->ID).'/'.$this->uri->segment(2).'">	
                            <h4 style="height:25px;overflow:hidden;">
                            <img src="'.base_url($my_course->file).'"style="width:30px;height:30px;"/>
                            '.ucfirst(ellipsize($content->title,100)).'</h4></a>
       
							<p style="padding:10px;font-size:15px;border-top:solid thin #DDDDDD;background:#FDFBB7;margin:0;color:black;">
                            '.ucfirst(ellipsize($content->description,300)).'
                            </p>
							</div>
                            
                            </div>
						
                        </div>
					</div>');	   
       



}      
unset($content);    
}else{
echo('<div>No lessons for this course</div>');
}    
    
?>



</div>

</div>
<div class="col-lg-3">

<div style="margin-bottom: 20px;">
<?php
echo ('<h3 style="margin-top:-10px;"><img src="'.base_url($my_course->file).'" style="width:50px;height:50px;" class="img-circle">'.ucfirst($my_course->name).'</h3>');

$this->load->view('templates/search_bar');
	
?>
</div>


<ul>
<li><a href="">Ask a question</a></li>
<li><a href="">Excercises</a></li>
<li><a href="">Tutorials</a></li>
<li><a href="">Assignments</a></li>
<li><a href="">Join a discussion group</a></li>
</ul>

<hr />
<h4 class="btn btn-brand" style="margin-bottom: 20px;font-size: 17px;">Talk to course consultant</h4>

<div class="shadow_bottom1" style="border: solid thin silver;background: aliceblue;">
<?php
	
    
echo $calendar;     
    
?>   

</div> 


<div style="font-size: 16px;margin-top: 20px;" class="btn btn-brand"><strong><?php
echo $enrolled_course->num_rows();	
?> Courses enrolled for</strong></div>





</div>






















</div>


<div>
</div>






</div>
</div>
</div>
</div>