<?php
if($tutorial->num_rows()>0){
foreach($tutorial->result() as $row);    
}
?>
  
  
  
  
  
  
  
  
  
  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>Tutorial</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                
                
<div class="col-lg-3 col-md-3">
<h3 style="font-family: fantasy;padding: 0;margin: 0;text-align: center;">Calendar</h3>
<div style="margin-top: 20px;">
<?php
echo $calendar;
?>
</div>          
 </div>
                
                
                
                
                
                
                
                
                
<div class="col-lg-9 col-md-9">
<blockquote>
<h3 style="margin-top: -20px;"><?php
echo ucfirst($row->title);	
?></h3>                       
                    
 <p>
 <?php
echo ucfirst($row->description);
?>
 </p>                       
                        
<p style="margin-top: 30px;">
<?php
	
$file=$row->file;    
if(isset($file)){
echo('This is the content');    
}    
 
 
    
?>
</p>                        
                        
                    
                    
                    
                    
                    
                        
                    
                    
                    
                    
                    </blockquote>

                </div>
            </div>

        </div>

    </div>
    <!--./ Media Section End -->