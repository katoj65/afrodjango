<div style="padding: 10px;text-align: center;background: black;color: white;">
<h3>Login</h3>
</div>



<div class="container">
<div class="row">
<div class="col-md-4"> 
            
           
            
            
            
            
            
</div>       
<div class="col-lg-4" style="height: 300px;">
<div style="text-align: center;color: red;padding:20px;">
<?php
echo validation_errors();
echo $this->session->flashdata('login_error');
echo $this->session->flashdata('pass_error');
?>
     
</div>
<?php $this->load->view('forms/login'); ?>
</div>       
            
            
            
            
            
<div class="col-lg-4" >
     
     
</div>       
            
            
            
            
            
            
            
            
            
            
            
            
            
            
</div>           
</div>           
</div>           