<?php
if($lesson_load->num_rows()==1){
foreach($lesson_load->result() as $row);
}else{
redirect(base_url());
}


?>  
  
  
  
  
  
  
  
  
  
  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>Course topic content
                        <span style="padding-left: 10px;">
<?php

if($application->num_rows()==1){
foreach($application->result() as $app);
$status=$app->status;
if($status=='confirmed'){
echo('<a href="'.base_url('index.php/trainer/course/content/'.$this->uri->segment(4).'/add').'">
<span style="background:green;color:white;padding:5px;font-size:14px;" class="border_radius">');
echo 'Add lesson content';
echo('</span></a>');
}elseif($status=='request'){
echo('request');    
}






}
	
?>
                        
                        </span>
                        
                        </h3>
                        <p><?php
	echo ucfirst($row->name);
?></p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                
                
<div class="col-lg-3 col-md-3">
<h3 style="font-family: fantasy;text-align: center;">Study calendar</h3>
<div>
<?php
echo $calendar;
?>
</div>

<hr />

<div>



<?php
	
if($lesson_content->num_rows()>0){
$array=array();

foreach($lesson_content->result() as $illustration){
if($illustration->file!=''){
$array[]=$illustration->file;
}
}



$count=count($array);
$last=$count-1;
echo('<a href=""><h3 style="text-align: center;margin-bottom:20px;">('.$count.') Hands on practice</h3></a>');
//echo('<img src="'.base_url($array[$last]).'" style="width:100%;height:200px;border:solid 10px #2B3C69;border-top:none;border-bottom:none;" class="shadow1"/>');
    
unset($illustration);    
echo('<hr/>');
}else{
echo('No content');
}    
    
    

    
?>








</div>

















          
 </div>
                
                
                
                
                
                
                
                
                
 <div class="col-lg-9 col-md-9">
 <blockquote style="min-height: 300px;">
 <h3 style="margin-top: -20px;"><?php
echo ucfirst($row->title);
?></h3>                                      
<p>
<?php
echo ucfirst(ellipsize($row->description,280));
?>

</p>
<hr />





<div>
<?php

if($application->num_rows()==1){
if($status=='confirmed'){
if($this->uri->segment(5)!=''){
$this->load->view('pages/trainer_add_content_menu');    
}
}

}
?>
</div>









<div class="row">
<div class="col-lg-9 col-md-9">

<p><small style="font-size: 25px;">Lessons available for above topic</small></p>


<?php
	
if($lesson_content->num_rows()>0){
foreach($lesson_content->result() as $result){
echo('<h3>'.ucfirst($result->title).'</h3>');    
echo('<p style="font-size:15px;">'.ucfirst($result->description).'</p>');  
echo('<hr/>');  
    
}    
unset($result);       
}else{
echo('No content');
}    
    
?>
<hr />

</div>



<div class="col-lg-3 col-md-3">



<h3>Tutorials</h3>
<ul style="margin: 0;padding: 0;">
<li style="padding: 5px;list-style: none;padding-bottom: 20px;">
<a href="">
<span style="padding: 7px;background:#ED4933;color: white;font-size:15px;" class="border_radius">
Add tutorial</a></span></li>

<li><a href="" style="font-size:15px;">Hands on guide</a></li>
<li><a href="" style="font-size:15px;">Tutorial videos</a></li>

<?php
for($x=1;$x<=6;$x++){
echo('<li><a href="" style="font-size:15px;">Add something new</a></li>');    
}	
?>
</ul>
<hr />





<h3>Assessments</h3>
<ul style="margin: 0;padding: 0;">
<li style="padding: 5px;list-style: none;padding-bottom: 20px;">
<a href="">
<span style="padding: 7px;background:#ED4933;color: white;font-size:15px;" class="border_radius">
Add assignment</a></span></li>


<li><a href="" style="font-size:15px;">Lesson exercise</a></li>
<li><a href="" style="font-size:15px;">Lesson assignment</a></li>

<?php
for($x=1;$x<=6;$x++){
echo('<li><a href="" style="font-size:15px;">Add something new</a></li>');    
}	
?>
</ul>
<hr />

















</div>






</div>























</blockquote>

                </div>
            </div>

        </div>

    </div>
    <!--./ Media Section End -->