<?php
if($course_first->num_rows()==1){
foreach($course_first->result() as $result);    
}else{
redirect(base_url());
}	
?>











<div class="container">
<div class="row pad-top-botm">
<div class="col-lg-7 col-md-7">
<h4>

<span style="padding: 10px;background: #565AB1;color:white;border:solid thin #2B3C69;font-weight:normal;
font-size: 14px;" class="border_radius">
<?php
echo $count_course.' '.$course_load->name.' topics to read';
?>
</span>
</h4>






<h2 style="font-weight: bold;margin-top: 50px;">
<?php
echo ucfirst($result->name);
?>
</h2>




<div style="margin-bottom: 10px;">
<p style="font-size: 15px;margin-top: 10px;">
<?php
echo ucfirst($result->description);
?>
</p>
</div>                





<hr style="border-top:solid 1px #D6DBDF;" />







<div style="margin-top: 20px;background: white;padding: 30px;border:solid 1px #D6DBDF;" class="border_radius" class="border_radius">
<?php
if($lessons->num_rows()>0){
foreach($lessons->result() as $content){
$data['content']=$content;
echo('<div style="padding:10px;margin-bottom:10px;">');

echo('<h5 style="font-weight:bold;font-size:17px;">
<img src="'.base_url('icons/topic.png').'" style="width:30px;height:30px;"/>
<span class="round" style="border:solid 1px #D6DBDF;padding:10px;background:#F7F7F7;">'.ucfirst($content->title).'</span></h5>');    
echo('<p style="font-size:15px;">'.ucfirst($content->description).'</p>');    

echo('<div>');
$this->load->view('pages/sub_topics',$data);
echo('</div>');

echo('</div>');
}    
}else{
echo('<div style="color:gray;">No content</div>');
}	
?>
</div>



























</div>
























<div class="col-lg-5 col-md-5">
<?php
$this->load->view('pages/sidebar_right');
?>
</div>
</div>
   
    