<?php
$this->load->model('Lesson_model');	
$class=new Lesson_model;
$sub_topics=$class->get_lesson_content($content->ID);
?>
<div>
<div>
<a style="font-size: 15px;"><?php echo $sub_topics->num_rows();?> Sub topics for <?php
echo ''.ucfirst($content->title).'';
?></a>
</div>



<?php


if($sub_topics->num_rows()>0){
echo('<ul>');
foreach($sub_topics->result() as $info){
if($info->file!=""){
$file='<span style="float:right;">
<a href="'.base_url('index.php/student/illustration/'.$info->ID).'" 
style="padding:5px;background:#34296F;color:black;color:white;" class="round">
View illustration</a>
</span>';
}else{
$file=false;
}
echo('<li style="border-left:solid 10px #F7F7F7;margin:10px;margin-bottom:30px;">');
echo('<div style="padding:10px;">
<img src="'.base_url('icons/sub.png').'" style="width:30px;height:30px;"/>
<strong style="font-size:17px;padding-left:5px;">'.ucfirst($info->title).'</strong></div>');   
echo('<p style="padding:15px;padding-left:20px;background:#F7F7F7;border-right:solid 10px #D6DBDF;font-size:15px;margin-top:10px;">'.ucfirst($info->description).'
<br/>
'.($file).'</p>');    
echo('</li>');    
}
echo('</ul>');    
unset($info);    
}else{

}



?>










</div>





