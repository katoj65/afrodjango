  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>Courses available</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                
                
<div class="col-lg-3 col-md-3" style="">

 <h3 style="text-align: center;margin-bottom: 30px;">
 <span style="font-family: fantasy;">Category</span></h3>

<div>
<?php
if($course_categories->num_rows()>0){
foreach($course_categories->result() as $cat){
echo('<a href="'.base_url('index.php/student/course/content/'.$cat->ID.'').'">
<div style="margin-bottom:10px;background:white;border:solid thin #D4E6F1;">');    
echo('<img src="'.base_url($cat->file).'" style="width:100%;padding:20px;"/>');    
echo('</div></a>');    
}    
unset($cat);    
}else{
echo('NO content');
}
?>
          
</div>













</div>
                
                
                
                
                
                
                
                
                
 <div class="col-lg-9 col-md-9">
 <blockquote style="min-height: 300px;">
                      
 <?php
if($courses->num_rows()>0){ 
$this->load->model('Course_model');
$class=new Course_model;
foreach($courses->result() as $result){
$category=$class->return_course_category($result->course_categoryID);
echo('<div style="margin-bottom:20px;">
<p>
<a href="" style=""><h3 style="margin:0;padding:0;">'.ucfirst($result->name).'</h3></a>
<br/><span style="font-size:15px;">'.ucfirst(ellipsize($result->description,300)).'</span>
</p><small>'.$category->name.' </small></div>');   
} 
                        
}                        

?>
                    
                    
                    
                    
                        
                    
                    
                    
                    
                    </blockquote>

                </div>
            </div>

        </div>

    </div>
    <!--./ Media Section End -->