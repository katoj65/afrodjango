  
   
<div class="services">
<div class="container">
<div class="row">
<div class="col-md-3">
<img src="assets/custom/img/bootstrap-templates-office3.png" class="image" title="project one">				
<h3><a class="hover-effect" href="<?php
echo base_url('index.php/classes');	
?>">Classes</a></h3>
							<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem.</p>
					 </div>
					<div class="col-md-3">
								<img src="assets/custom/img/bootstrap-templates-office2.png" class="image" title="project one"/>
											
								<h3><a class="hover-effect" href="<?php
echo base_url('index.php/homework');	
?>">Home work</a></h3>
							<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem.</p>
					 </div>
					<div class="col-md-3">
								<img src="assets/custom/img/bootstrap-templates-office1.png" class="image" title="project one"/>
								
								<h3><a class="hover-effect" href="<?php
echo base_url('index.php/discussions');	
?>">Discussions</a></h3>
							<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem.</p>
					 </div>
					<div class="col-md-3">
								<img src="assets/custom/img/bootstrap-templates-office4.png" class="image" title="project one"/>
									
								<h3><a class="hover-effect" href="<?php
echo base_url('index.php/mentors');	
?>">Mentors</a></h3>
							<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem.</p>
					 </div>
				 </div>	
			</div>
		</div>