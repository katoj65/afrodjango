  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>MY STUDY CALENDAR</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                
                
<div class="col-lg-4 col-md-4" style="padding: 30px;">
<div style="background: white;border: solid thin silver;" class="shadow1">
<?php
echo $calendar;
?>
</div>          
 </div>
                
                
                
                
                
                
                
                
                
 <div class="col-lg-8 col-md-8">
 <blockquote style="min-height: 300px;">
 <h3 style="margin-top: -20px;">Upcoming activities</h3>                       
                    <?php
	for($x=1;$x<=5;$x++){
echo('<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
<small>Consectetur adipiscing elit</small>');	   
	}
                        
                        
                        
                        
                        ?>
                    
                    
                    
                    
                        
                    
                    
                    
                    
                    </blockquote>

                </div>
            </div>

        </div>

    </div>
    <!--./ Media Section End -->