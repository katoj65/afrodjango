<?php
echo('<style type="text/css">
<!--
body{overflow:hidden;}
-->
</style>');	

?>







<div class="pageWrapper" style="background: rgba(0, 0, 0, 0.8);">
<div class="dialog" style="width: 30%;margin-left: 35%;margin-right: 35%;border: none;">
<h4 style="padding: 10px;">Heading</h4>
<hr />
<div style="padding: 30px;">

Content.


</div>

</div>
</div>