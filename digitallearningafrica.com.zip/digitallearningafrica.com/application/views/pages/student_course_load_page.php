<?php
if($category->num_rows()==1){
foreach($category->result() as $row);
}else{
redirect(base_url());
}	
?>
  
  
  
    
<!--./ stats div end -->
<div id="media-sec" style="background: #F7F7F7;color: black;">
<div class="container">
<div class="row">
<div class="col-lg-12 col-md-12" >
<div class="text-center">
<h3>Course content</h3>
<p>

<?php

echo ucfirst($description);

?>

</p>
<br />
<br />
</div>
</div>
                
                
                
                
                
                
<div class="col-lg-3 col-md-3">
<div>
<img src="<?php
echo base_url($row->file);
?>" style="width: 100%;padding: 20px;background: white;border:solid thin #D4E6F1;"/>
</div>         


<hr />
<h4 style="font-family: fantasy;text-align: center;">Calendar</h4>
<div style="margin-top: 30px;">
<?php
echo $calendar;
?>
</div>








</div>
                
                
                
                
                        
<div class="col-lg-9 col-md-9">
<blockquote>
<h3 style="margin-top: -20px;">
<?php
echo ucfirst($row->name);
?> 
</h3>                       




                    
<p>
<?php
echo ucfirst($row->description);
?>


<div style="margin-top: 20px;">

<?php
if($check_enrolled_course->num_rows()==1){
echo('<a href="'.base_url('index.php/student').'"><span style="padding:5px;background:#52BE80;color:white;font-size:13px;" class="border_radius">Course Enrolled</span></a>');    
    
}else{

echo('<a href="#" style="font-size:13px;padding:5px;background:#565AB1;color:white;" class="border_radius">Enroll now</a>');    
    
}




echo('<a href="'.base_url('index.php/student/consultants/'.$row->ID).'" style="padding:5px;background:#ED4933;color:white;font-size:13px;margin-left:10px;" class="border_radius">Talk to consultants</a>'); 





?>




</div>


</p>                       
                        
<p style="margin-top: 30px;">
<h3 style="font-size: 18px;margin-bottom: 30px;"><?php
echo $lessons->num_rows();
?> Courses available for <?php
echo $row->name;
?></h3>
<?php
if($lessons->num_rows()>0){
foreach($lessons->result() as $result){
echo('<div style="margin-bottom:20px;"><small style="font-size:18px;">'.ucfirst($result->name).'</small>
<p style="font-size:15px;color:gray;">'.ucfirst(ellipsize($result->description,300)).'</p></div>');    
    
    
}
unset($result);    
}else{
echo('No content');
}
?>

</p>                        
                        
                    
                    
                    
                    
                    
                        
                    
                    
                    
                    
</blockquote>
</div>
</div>
</div>

</div>
    <!--./ Media Section End -->