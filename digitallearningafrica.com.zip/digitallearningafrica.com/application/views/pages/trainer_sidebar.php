<?php
if($user->num_rows()==1){
foreach($user->result() as $user_row);
}
?>















<h3 style="font-family: fantasy;">Trainer Menu</h3>


<ul style="margin: 0;padding: 0;">



<li style="padding: 20px;list-style: none;">
<a href="<?php
echo base_url('index.php/'.($user_row->role).'/course/application');
?>">
<span style="padding: 7px;background:#ED4933;color: white;font-size:15px;" class="border_radius">
Apply for course</a></span></li>

<li><a href="" style="font-size:15px;">Create presentation</a></li>
<li><a href="" style="font-size:15px;">Create new event</a></li>
<li><a href="" style="font-size:15px;">Virtual classroom </a></li>
<li><a href="" style="font-size:15px;">Discussions </a></li>
<li><a href="" style="font-size:15px;">Assignments </a></li>
<li><a href="" style="font-size:15px;">Tutorials </a></li>
<li><a href="" style="font-size:15px;">Reference material </a></li>
<li><a href="" style="font-size:15px;">Examples </a></li>

<li><a href="" style="font-size:15px;">Content admin </a></li>




  
</ul>
