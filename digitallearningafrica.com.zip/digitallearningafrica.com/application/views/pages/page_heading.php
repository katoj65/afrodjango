


<div class="general-subhead">
<h3>
              
<span style="padding: 20px;padding-top:5px;padding-bottom:5px;">       
<?php
echo strtoupper($heading);
?></span></h3>

<div style="font-size: 17px;margin-top: 20px;"><?php
echo $attributes;
?>




<div style="padding: 10px;">

<?php

if($this->session->ID!=""){
if($user->num_rows()==1){
foreach($user->result() as $user_row);
if($user_row->role=='student'){
if($enroll==1){
$this->load->view('templates/student_menu_bar');
}
}elseif($user_row->role='trainer'){

$this->load->view('templates/trainer_menu_bar');
}
}	
}

?>

</div>


</div>
</div>