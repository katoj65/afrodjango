<?php
$this->load->view('templates/category_menu');
?>








<div class="serviceBlock">
<div class="container">










<div class="row" style="margin-top: -30px;">
<div class="col-lg-9">




<?php
if(isset($this->session->ID)){
if($this->uri->segment(1)=='courses'){

if($user->role=='admin'){

if($this->uri->segment(2)=='add'){

if($this->uri->segment(3)=='lesson'){
$this->load->view('forms/add_course_content');    
echo('<hr/>');
} 
 




}else{
$this->load->view('forms/add_course');
echo('<hr/>');
}
}    


echo('<h3 style="text-align:center;"><img src="'.base_url($my_course->file).'" style="width:50px;height:50px;"/>');
echo(ucfirst($my_course->name));
echo('</h3>');


echo ('<div style="font-size:20px;margin-bottom:10px;color:black;">'.ucfirst($my_course->description).'</div>');
echo('<div class=""></div>');


}
}
?>



<div><h5 style="text-align: center;font-size: 18px;color:#FF4800;padding: 10px;">
<span class="gradient" style="padding: 10px;">Courses</span></h5></div>



<div style="margin-top: 50px;">

<?php
	
if($course->num_rows()>0){
foreach($course->result() as $row){    


echo('<div class="col-md-4" style="margin:0;padding:5px;">
						<div class="clearfix">
						
							<div class="gradient" style="padding:0;margin-bottom:10px;background:black;border:solid 2px silver;height-height:200px;overflow:hidden;" id="colored_banner">
								
							<a href="'.base_url('index.php/course/'.$row->ID).'" style="color:white;">	
                            <h4 style="height:30px;overflow:hidden;padding:10px;">'.ucfirst(character_limiter($row->name,30)).'</h4></a>
								<p style="background:#FDFCBC;padding:15px;border-top:solid thin silver;margin:0;height:150px;color:black;">'.ucfirst(character_limiter($row->description,180)).'</p>
							</div>
						</div>
					</div>');	   
    
    
    
}
unset($row);    
}else{
echo('<div>No content</div>');        
}    
    
    
    
     
?> 
</div>
</div>










<div class="col-lg-3">


<?php
if(isset($this->session->ID)){
echo ('<h3 style="margin-top:-10px;"><img src="'.base_url($my_course->file).'" style="width:50px;height:50px;" class="img-circle">'.ucfirst($my_course->name).'</h3>');
}
$this->load->view('templates/search_bar');
	
?>

<hr />


<ul>
<li><a href="#">Course overview</a></li>
<li><a href="#">Classes</a></li>
<li><a href="#">Discussion groups</a></li>
<li><a href="#">Study calendar</a></li>
</ul>









<a href="<?php
echo base_url('index.php/'.strtolower($my_course->name).'/consultants/'.$my_course->ID);
?>"><div class="btn btn-brand" style="width:100%;font-size: 17px;">Talk to consultants</div></a>


<hr />



<div class="shadow_bottom1" style="color: black;background: aliceblue;border:solid thin silver;">
<?php
echo($calendar);
?>


</div>







</div>



















</div>
</div>
</div>