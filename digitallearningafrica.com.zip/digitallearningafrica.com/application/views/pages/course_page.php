<?php
if($course->num_rows()==1){
foreach($course->result() as $row);    
}else{
redirect(base_url('index.php'));    
}	
    
?>

<section id="home-service" style="margin-top:0px;">
<div class="container">
<div class="row " style="text-align: center;">

  <section id="service-info">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-12 col-md-12">
                    <h3 class="clr-main">
                    
 <?php
echo('<img src="'.base_url($my_course->file).'" style="width:30px;height:30px;"/>');
?>                   
<strong>
 <?php
echo ucfirst($row->name);
?>                   

</strong>

</h3>
<p style="font-size: 16px;text-align: left;">  
<?php
echo ucfirst($row->description);
?>         
</p>
<hr />

<div style="text-align: left;">
<ul class="menus">
<li><a href="" style="font-size: 16px;" >Ask question</a></li>
<?php
if($lessons->num_rows()>0){
if($row->author==$this->session->ID){
echo('<li><a href="'.base_url('index.php/course/'.$row->ID.'/add/lesson').'" style="font-size: 16px;" >Add lesson</a></li>');    
}    
}
?>

<li><a href="" style="font-size: 16px;" >Tutorials</a></li>
<li><a href="" style="font-size: 16px;" >Assignments</a></li>
<li><a href="" style="font-size: 16px;" >Discussions</a></li>
<li><a href="" style="font-size: 16px;" >Consultants</a></li>


<?php
if($enrollement->num_rows()==1){
echo('<li><a href="" class="btn btn-success">START NOW</a></li>');    
}else{
echo('<li><a href="'.base_url('index.php/course/'.$this->uri->segment(2).'/'.strtolower($my_course->name).'/enroll').'" class="btn btn-success" style="padding-left:10px;padding-right:10px;">ENROLL NOW</a></li>');    
}	
    
    
    
?>


<li><a style="font-size: 16px;padding-left:10px;padding-right:10px;" class="btn btn-danger"><?php
echo ucfirst($row->duration_days);
?> Days duration </a></li>



</ul>
</div>



                    
<br />
<br />
</div>
</div>
</div>
</div>






<div class="container" style="margin-top: -100px;">
<div class="row">
<div class="col-lg-9" style="padding-right: 30px;">

<div>
<?php
if($row->author==$this->session->ID){
if($lessons->num_rows()==0){
$this->load->view('forms/add_course_content');
echo('<hr/>');    
}else{
if($this->uri->segment(3)=='add'){
if($this->uri->segment(4)=='lesson'){
$this->load->view('forms/add_course_content'); 
    
}
}
}







}
?>
</div>










<h4 style="text-align: center;margin-top: -10px;">
<strong style="font-size: 15px;padding: 10px;"><?php
	echo $lessons->num_rows();
?> Lessons available for this course</strong></h4>



<div style="margin-top: 30px;">



<?php
if($lessons->num_rows()>0){
$title=array();
$content=array();
$id=array();

$content[0]=FALSE;
$title[0]=FALSE;
$id[0]=FALSE;
foreach($lessons->result() as $result){
$content[]=$result->description;
$title[]=$result->title;
$id[]=$result->ID;
}        
unset($result);

for($x=1;$x<=$lessons->num_rows();$x++){

echo('<div class="col-lg-12 col-md-12" style="margin-bottom:10px;">
<div class="media">
<div class="pull-left">
<i class=" fa fa-folder-open-o fa-4x rotate-icon "></i>
</div>
<div class="media-body" style="padding-bottom:0px;">
<a href="'.base_url('index.php/lesson/'.$id[$x].'').'">
<h3 class="media-heading" style="font-size:18px;color:#FF6A00;"><strong>'.ucfirst(character_limiter($title[$x],100)).'</strong></h3></a>
<p style="padding:5px;font-size:15px;padding-bottom:5px;border-bottom:solid 5px white;">
'.ucfirst(character_limiter($content[$x],500)).'
<div>
<ul style="padding:0;color;blue;margin:0;">
<li style="float:left;margin-left:25px;color:#D5DBDB;margin-right:10px;"><a href="#">100 Topics</a></li> 
<li style="float:left;margin-left:25px;color:#D5DBDB;margin-right:10px;"><a href="#">100 Tutorials</a></li>
<li style="float:left;margin-left:25px;color:#D5DBDB;margin-right:10px;"><a href="#">100 Asignments</a></li>
<li style="float:left;margin-left:25px;color:#D5DBDB;margin-right:10px;"><a href="#">Discussions</a></li>
<li style="float:left;margin-left:25px;color:#D5DBDB;margin-right:10px;">
<a href="#" class="btn btn-danger" style="padding:1px;padding-left:10px;padding-right:10px;">Live Classroom</a></li>
</ul>
</div>

</p>
</div>
</div>
</div>');









}
    
    
    
}	
    
    
    
    
        
?>


</div>

                    
                    












</div>
<div class="col-lg-3">


<div>
<?php
if($row->image!=""){
echo('<img src="'.base_url($row->image).'" style="width:100%;max-height:300px;padding:10px;border:solid thin silver;" class="border_radius"/>');
echo('<hr/>');
}
?>

</div>











<div>
<?php
echo $calendar;
?>
</div>
<hr />

<div style="text-align: center;" class="button1">
<a href="#" style="color:white;font-size: 17px;">Talk to course consultants</a>
</div>





</div>









</div>
</div>












</section>
</div>
</section>
