

<div class="serviceBlock">
<div class="container">
<div class="row" style="margin-top: -30px;">












<div class="col-lg-9">




<div style="text-align: center;margin-bottom: 50px;">

<?php


if(isset($this->session->ID)){

echo('<h3><span style="padding-bottom: 10px;padding: 10px;border:none;color:gray;" class="h1">Available course for 
'.(ucfirst($my_course->name)).'</span></h3>');    

}else{

echo('<h3><span style="border:solid 2px silver;padding-bottom: 10px;padding: 10px;" class="border_radius">Available courses</span></h3>');

}	
 


?>


</div>






<div style="margin-top: -10px;">



<?php
	
if($user_courses->num_rows()>0){
foreach($user_courses->result() as $row){
    
    echo('<div class="col-md-4" style="margin:0;padding:5px;">
						<div class="clearfix">
						
							<div class="gradient" style="padding:0;margin-bottom:10px;background:black;height-height:200px;overflow:hidden;border:solid 3px silver;" id="colored_banner">
								
							<a href="'.base_url('index.php/course/'.$row->ID).'" style="color:white;">	
                            <h4 style="height:30px;overflow:hidden;padding:10px;">'.ucfirst(character_limiter($row->name,30)).'</h4></a>
								<p style="background:#FCFAAD;padding:15px;border-top:solid thin silver;margin:0;height:150px;color:black;">'.ucfirst(character_limiter($row->description,180)).'</p>
							</div>
						</div>
					</div>');	   
           
}    
    
unset($row);    
}else{
echo('<div>No content</div>');
}    
    
    
    
    
    
    
    
    
    
    
?>
</div>





</div>





<div class="col-lg-3">
<?php
echo ('<h3><img src="'.base_url($my_course->file).'" style="width:50px;height:50px;" class="img-circle">'.ucfirst($my_course->name).'</h3>');

$this->load->view('templates/search_bar');
	
?>




<div style="margin-top: 20px;">
<a href="#" class="btn btn-brand">Talk to course consultant </a>
</div>

<hr />

<div>
<ul>
<li><a href="#">Course guidelines</a></li>
<li><a href="#">Class room schedule</a></li>
<li><a href="#">Mentors / consultants</a></li>
<li><a href="#">Certifying</a></li>
</ul>

<hr />
</div>

<div class="shadow_bottom1" style="border:solid 1px silver;background: aliceblue;">
<?php
echo $calendar;	
?>
</div>










</div>

</div>
</div>
</div>