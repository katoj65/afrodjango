<div style="color: green;text-align: center;">


<?php
echo $this->session->flashdata('saved_application');
?>

</div>









<!--./ stats div end -->
<div id="media-sec" style="background: #F7F7F7;color: black;">
<div class="container">
<div class="row">
<div class="col-lg-12 col-md-12" >
<div class="text-center">
<h3>Courses for 

<?php
echo $heading;
?>

</h3>




<p>

<?php
echo ucfirst($description);
?>

</p>
<br />
<br />
</div>
</div>
                
                
                
                
                       
<div class="col-lg-3 col-md-3">
<h3 style="font-family: fantasy;text-align: center;">Calendar</h3>
<div>

<?php
echo $calendar;
?>

</div>
<hr />



          
</div>
                
                
                
                
                
                
                
                
                
<div class="col-lg-6 col-md-6">
<blockquote style="min-height: 300px;">                      



<?php

if($topics->num_rows()>0){
$this->load->model('Course_model');    
$class=new Course_model;    
    
    
foreach($topics->result() as $row){    
echo('<p style="margin-top:10px;">
<a href="'.base_url('index.php/trainer/course/'.$row->ID).'">
<h3 style="font-size:20px;">'.ucfirst($row->name).'</h3></a></p>
<p>'.ucfirst(ellipsize($row->description,270)).'</p>');


$app=$class->get_course_aplication_status($row->ID);

/**
 * request status.
 */
if($app->num_rows()==1){
foreach($app->result() as $result);

if($result->status=='request'){
echo('<small>You applied to train for the course 
<span style="padding-left:10px;">
<span style="padding:4px;background:green;color:white;padding-left:10px;padding-right:10px;" 
class="border_radius">'.ucfirst($result->status).'</span></span></small>'); 

}elseif($result->status=='confirmed'){

echo('<small>You applied to train for the course 
<span style="padding-left:10px;">
<span style="padding:4px;background:#2B3C69;color:white;padding-left:10px;padding-right:10px;" 
class="border_radius">'.ucfirst($result->status).'</span></span></small>'); 
    
}elseif($result->status=='declined'){
    
echo('<small>Course admin: 
<span style="padding-left:10px;">
<a href="'.base_url('index.php/trainer/course/re_appy/'.$result->ID).'"><span style="padding:4px;background:#ED4933;color:white;padding-left:10px;padding-right:10px;" 
class="border_radius">'.ucfirst($result->status).' application</span></a></span></small>');    
}



}else{
echo('<small>Apply</small>');    
}    





}    
unset($row);   
}else{
echo('No content');
}	
?>                   
                   
</blockquote>
</div>










<div class="col-lg-3 col-md-3">


<?php
$this->load->view('pages/trainer_sidebar');
?>

</div>












</div>
</div>
</div>
<!--./ Media Section End -->