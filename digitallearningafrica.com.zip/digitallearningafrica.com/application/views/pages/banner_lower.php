<!-- highlightSection -->
<div class="highlightSection">
<div class="container">
<div class="row">
<div class="col-md-2">
<h4 style="margin-top: 10px;font-size:20px;">In partnership with</h4>
</div>



<div class="col-lg-10">

<?php
if($partners->num_rows()>0){
foreach($partners->result() as $partner){
echo('<div style="display:inline-table;width:180px;text-align:center;color:gray;font-size:12px;font-weight:bold;">');

echo('<div style="height:50px;border:solid thin silver;"></div>');
    
echo ucwords($partner->name);    
echo('</div>');    
}    
unset($partner);    
}else{
echo('No content');
}	
    
    
?>
             

</div>



				

</div>
</div>
</div>
</div>