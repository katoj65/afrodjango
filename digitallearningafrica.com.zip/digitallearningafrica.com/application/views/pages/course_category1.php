<div style="background:black;text-align: center;padding: 10px;color: white;">
<h3>Enroll to start coding with:</h3>
</div>



<div style="background: aliceblue;padding-bottom: 30px;font-family: sans-serif;">
<div class="container">
<div class="row">
<div class="col-lg-13">


<?php
	
if($category->num_rows()>0){
foreach($category->result() as $cat){
echo('<a href="'.base_url('index.php/'.strtolower($cat->name).'/'.$cat->ID).'">
<div class="col-lg-4" style="height:175px;" >
<div tyle=" margin:0;padding:0;">
<h3 style="text-align:center;">
<div style="padding:10px;background:white;border:solid 3px #C8E6C9;color:#81C784;font-size:20px;margin-left:20%;margin-right:20%;font-weight:bolder;background-image:url('.base_url($cat->file).');background-size:cover;background-repeat:no-repeat;background-size:50px 100%;" class="pallet">'.ucfirst($cat->name).'</div></h3>
<p style="padding:10px;font-size:14px;margin-top:0;color:black;text-align:left;border:solid 3px #C8E6C9;" class="pallet">'.ucfirst(ellipsize($cat->description,200)).'</p>
</div>
</div></a>');
}    
unset($cat);       
}else{
echo('No content');
}    
    
    
    
?>
</div>

</div>
</div>
</div>



















