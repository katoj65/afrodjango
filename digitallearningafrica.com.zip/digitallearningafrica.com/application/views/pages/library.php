<div style="padding: 10px;background: black;color: white;text-align: center;">
<h3>LIBRARY</h3>
</div>



<div style="padding: 10px;background: aliceblue;">
<div class="container">
<div class="row">

<div class="col-lg-8">
<?php
echo $heading;	
?>

<p>
<?php
echo '<span style="color:#FF4800;"><strong>'.ucfirst($my_course->name).'</strong></span> '.$description;
?>
</p>






</div>
<div  class="col-lg-4">
<?php
echo $attributes;	
?>









</div>







</div>
</div>
</div>









<div class="container">
<div class="row" style="min-height: 500px;">
<div class="col-lg-4">












</div>
















</div>
</div>

























