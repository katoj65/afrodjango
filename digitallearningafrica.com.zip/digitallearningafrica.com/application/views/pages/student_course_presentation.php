<?php
if($lesson_presentation->num_rows()==1){
foreach($lesson_presentation->result() as $row);
$data['row']=$row;
if($this->uri->segment(5)=='illustrations'){

$this->load->view('dialog/illustration_cover',$data);

}elseif($this->uri->segment(5)=='virtual-classroom'){

$this->load->view('dialog/student_course_virtual_classroom',$data);

}elseif($this->uri->segment(5)=='assignments'){

$this->load->view('dialog/student_course_assignments',$data);

}elseif($this->uri->segment(5)=='examples'){
    
$this->load->view('dialog/student_examples',$data);      
    
}elseif($this->uri->segment(5)=='reference'){
    
$this->load->view('dialog/student_reference',$data);      
    
}elseif($this->uri->segment(5)=='list'){
    
$this->load->view('dialog/student_presentation_list',$data);
    
}elseif($this->uri->segment(5)=='tutorials'){

$this->load->view('dialog/student_tutorials',$data);    
    
}elseif($this->uri->segment(5)=='consultations'){
$this->load->view('dialog/student_consultations',$data);    
}


}else{
redirect(base_url());
}
?>  

  
  
  
  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>Presentation</h3>
                        <p> <?php
echo ucfirst($row->name);
?>

</p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
                
                
<div class="col-lg-3 col-md-3">
<div>


<?php
echo $calendar;
?>
</div>          

<hr/>


<div>
<a href="<?php
echo base_url('index.php/student/course/presentation/'.$row->ID.'/illustrations');
?>"><h3 style="text-align: center;">View illustrations</h3></a>
</div>










</div>
                
                
                
                
                
                
                
                
                
 <div class="col-lg-9 col-md-9">
 <blockquote style="min-height: 300px;border:none;">
 <h3 style="margin-top: -20px;color:#2B3C69;font-weight: bold;"><?php
echo ucfirst($row->title);
?></h3>                       
                     
<p style="font-size: medium;">
<?php
echo ucfirst($row->description);
?>

</p>                    
                    
<hr />
<p style="margin-top: 20px;">
<small style="font-size: 20px;">Topics and illustrations</small>
</p>





<div class="row">
<div class="col-lg-9 col-md-9">

<div style="font-size: 15px;padding:20px;border:solid thin #EAEDED ;margin-top:20px;" class="border_radius">
<?php
if(isset($row->ID)){
$this->load->model('Lesson_model');    
$class=new Lesson_model;
$sub_topics=$class->get_lesson_content($row->ID);    
    
if($sub_topics->num_rows()>0){

foreach($sub_topics->result() as $sub){

echo('<h3 style="font-size:18px;">
<span style="padding:5px;background:#F7F7F7;padding-left:10px;padding-right:10px;border-left:solid thin silver;border-right:solid thin silver;" class="round">'.ucfirst($sub->title).'</span></h3>');
echo('<p>'.ucfirst($sub->description).'</p>');    
echo('<hr/>');
}    
unset($sub);    

}else{
echo('No content');
}        
}	
    
     
?>
</div>
</div>



<div class="col-lg-2 col-md-2">

<ul style="margin: 0;padding: 0;">
<li style="text-align: center;list-style: none;padding-bottom: 10px;">
<a href="<?php
echo base_url('index.php/student/course/presentation/'.$row->ID.'/illustrations');
?>" style="padding: 5px;color:white;background: #ED4933;font-size: 14px;" class="border_radius">Illustrations</a>
</li>

<li><a href="<?php
echo base_url('index.php/student/course/presentation/'.$row->ID.'/list');
?>" style="font-size:14px;">Presentations</a></li>
<li><a href="<?php
echo base_url('index.php/student/course/presentation/'.$row->ID.'/assignments');
?>" style="font-size:14px;">Assignments</a></li>
<li><a href="<?php
echo base_url('index.php/student/course/presentation/'.$row->ID.'/tutorials');
?>" style="font-size:14px;">Tutorials</a></li>
<li><a href="<?php
echo base_url('index.php/student/course/presentation/'.$row->ID.'/examples');
?>" style="font-size:14px;">Examples</a></li>
<li><a href="<?php
echo base_url('index.php/student/course/presentation/'.$row->ID.'/reference');
?>" style="font-size:14px;">Reference</a></li>
</ul>

<hr />


<ul style="margin: 0;padding: 0;">
<li style="text-align: center;list-style: none;padding-bottom: 10px;">
<a href="<?php
echo base_url('index.php/student/course/presentation/'.$row->ID.'/virtual-classroom');
?>" style="padding: 5px;color:white;background: #ED4933;font-size: 14px;" class="border_radius">V. Classroom</a>
<hr />
</li>



<li style="text-align: center;list-style: none;padding-bottom: 10px;">
<a href="<?php
echo base_url('index.php/student/course/presentation/'.$row->ID.'/consultations');
?>" style="padding: 5px;color:white;background:#52BE80;font-size: 14px;" class="border_radius">
Consultants</a>
</li>
</ul>






</div>

</div>








                        
                    
                    
                    
                    
</blockquote>
</div>
</div>
</div>
</div>





























    <!--./ Media Section End -->