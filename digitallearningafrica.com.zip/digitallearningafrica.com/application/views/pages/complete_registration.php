<?php
if($user->num_rows()==1){
foreach($user->result() as $row);
}else{
redirect(base_url('index.php/register'));
}
?>
<div id="request-quote" style="background: #F7F7F7;color: black;">
<div class="container">
<div class="row">
                
                

<div class="col-lg-2">
</div>


<div class="col-lg-6">

<div style="background: white;padding: 20px;border:solid thin silver;margin-top: 50px;" class="border_radius">






<div>
<div style="padding:20px;">
<table style="width: 100%;">
<tr>
<td style="width: 30%;">

<div style="padding: 20px;height:150px;background: silver;border:solid thin gray;"></div>
    
</td>
<td style="padding: 30px;" valign="top">
<?php

echo('<p style="font-size:17px;"><strong>'.strtoupper($row->fname).' '.strtoupper($row->lname).'</strong></p>'); 
echo('<p style="font-size:17px;"><strong>'.ucfirst($row->gender).'</strong></p>');
echo('<p style="font-size:17px;"><strong>'.($row->tel).'</strong></p>'); 
echo('<p style="font-size:17px;"><strong>'.($row->email).'</strong></p>');    

?>





</td>
</tr>
</table>

</div>
<hr />





</div>




<?php
$this->load->view('forms/profile');
?>

</div>








<div class="col-lg-2">

</div>





</div>


</div>
</div>
</div>