<div class="serviceBlock">
<div class="container">

<?php
//	$this->load->view('templates/category_menu');
?>

<div style="text-align: center;"><h3><span style="font-size: 25px;" class="line">Courses</span></h3>
</div>

<p style="padding: 10px;"></p>
















<div class="row">
		
  <?php
	if($courses->num_rows()>0){
	foreach($courses->result() as $row){

echo('<div class="col-md-4">
						<div class="clearfix">
							<i class="fa fa-html5"></i> 
							<div class="desc">
								
					<p>
                    
                    <p><span class="gradient" style="font-size:16px;">
                    	<a href="'.base_url('index.php/course/'.$row->ID).'">'.ucfirst(character_limiter($row->name,30)).'</a>
                    
                    </span><p/>
                    
                    '.ucfirst(character_limiter($row->description,110)).'</p>
							</div>
						</div>
					</div>');	   
       
       
       
	}   
       
   unset($row);    
	}else{
 echo('<div>No content</div>');
	}
?>      
        
        
        
        
        











<p style="padding: 30px;"></p>
</div>
</div>
</div>