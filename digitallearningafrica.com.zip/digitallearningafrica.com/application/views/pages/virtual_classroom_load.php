<?php
if($course_first->num_rows()==1){
foreach($course_first->result() as $result);    



if($vc_load->num_rows()==1){
foreach($vc_load->result() as $virtul_class);    
}

}else{
redirect(base_url());
}	



?>
 
 
 
 
 
 
 
  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>Upcoming virtual classroom session</h3>
                        <p><?php
	echo ucfirst($description);
?></p>
                        <br />
                        <br />
                    </div>
                </div>
                
                
                
                
            
                
<div class="col-lg-3 col-md-3" style="">

<div>


 <?php
 
if($other->num_rows()>0){ 
echo('<h3 style="font-family: fantasy;">Other lessons</h3>'); 
 
foreach($other->result() as $content){
echo('<a href="'.base_url('index.php/student/virtual/classroom/'.$content->ID).'">
<small style="font-size:18px;">'.ucfirst($content->title).'</small></a>
<p style="font-size:15px;line-height:20px;">'.ucfirst(ellipsize($content->description,50)).'

<span style="background:#FF6A00;color:white;padding:2px;font-size:13px;" class="border_radius">'.nice_date($content->day,'d - M - Y').'</span>
</p><hr/>');	   
}

}else{

echo('<h3 style="font-family: fantasy;text-align:center;">Calendar</h3>');
echo($calendar);


    
}
                        
 ?>












</div>          
</div>
        
                
                
                
                
                
                
                
                
                
 <div class="col-lg-8 col-md-8">

 <blockquote style="min-height: 300px;">
<h3 style="margin-top: -20px;"><?php
echo ucfirst($virtul_class->title);
?></h3>                       


<?php

$date=nice_date($virtul_class->day,'ymd');
$time=nice_date($virtul_class->time,'hi');


if($date==date('ymd')){
if($time>=date('hi')){

echo('hooiuu');

    
    
}else{

echo('<p style="color:gray;font-size:15px;">'.ucfirst($virtul_class->description).'</p>');

echo('<div>
<hr/>
<p>This lesson will be taking place at</p>
<small style="font-size:20px;">'.nice_date($virtul_class->time,'H:i a').' (Today)</small></div>');
     
}
}else{

echo('<p>'.ucfirst($virtul_class->description).'</p>
<small>'.nice_date($virtul_class->day,'D, d - M -Y').', '.nice_date($virtul_class->time,'H:i a').'</small>');
    
}


echo('<hr/>');



	




	   
	
                        
                        
                        
?>
                    
                    
</blockquote>

                </div>
            </div>

        </div>

    </div>
    <!--./ Media Section End -->