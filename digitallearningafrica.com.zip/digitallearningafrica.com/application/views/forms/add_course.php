

<?php
echo form_open_multipart();
?>


<div style="padding: 30px;margin-bottom: 20px;margin-top: -50px;border: solid 1px #D5DBDB;">




<p>
<h4>Add course<a href="<?php
echo base_url();
?>" style="float: right;font-size:15px;">Close</a></h4>

</p>




<div style="color: red;">
<?php
echo validation_errors();
?>

</div>

<div>

<?php

echo $this->session->flashdata('course_success');
	
    
?>


</div>







<p>
Course title:
<input type="text" name="title" class="form-control"/>
</p>
<p>Course description:
<textarea name="desc" class="form-control" style="height: 150px;">
</textarea></p>
<p>
<input type="file" name="file" class="form-control"/>
</p>
<p>
Duration in days:
<input type="number" name="duration" class="form-control"/>
</p>

<p>
<input type="submit" value="Create new course" class="btn-success"/>
</p>

</div>
</form>
<hr />