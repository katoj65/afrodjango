
<div id="request-quote" style="background: #F7F7F7;color: black;">
<div class="container">
<div class="row">
                
                
<div class="col-lg-4"></div>







<div class="col-lg-4">

<?php
echo form_open(base_url('index.php/register'));
echo('<div style="color:red;text-align:center;">');
echo validation_errors();
echo $this->session->flashdata('message');
echo('</div>');
?>

<div style="text-align: center;padding: 30px;margin-bottom: 20px;" class="shadow_bottom">
<p>First name: <input type="text" name="fname" class="form-control" placeholder="Fill in first name" value="<?php
	echo set_value('fname');
?>"/></p>
<p>Last name: <input type="text" name="lname" class="form-control" placeholder="Fill in last name" value="<?php
	echo set_value('lname');
?>"/></p>
<p>Gender: <select name="gender" class="form-control">
<option value="">Select gender</option>
<option value="male">Male</option>
<option value="female">Female</option>
</select>
</p>
<p>Date of birth <strong>(dd/mm/Y)</strong>
 <input type="text" name="dob" class="form-control" placeholder="Fill in date of birth" value="<?php
	echo set_value('dob');
?>"/></p>


<p>User role: <select name="role" class="form-control">
<option value="">Select role</option>
<option value="student">Student</option>
<option value="trainer">Trainer</option>
<option value="mentor">Mentor</option>

</select>
</p>
<p>
Country:
<select name="country" class="form-control">
<option value="">Select your country</option>
<?php
if($country->num_rows()>0){
foreach($country->result() as $Mcountry){
echo('<option value="'.$Mcountry->ID.'">'.ucfirst($Mcountry->country).'</option>');    
}    
}else{
echo('<option value="">Select academic level</option>');
}	
?>
</select>
</p>
<p>E-mail address: 
<input type="text" name="email" class="form-control" placeholder="Fill in your email address" value="<?php
	echo set_value('email');
?>"/></p>
<p>Telephone: <input type="text" name="tel" class="form-control" placeholder="Fill in your telephone number" value="<?php
	echo set_value('tel');
?>"/></p>
<p>Password: 
<input type="password" name="password" class="form-control" /></p>
<p><input type="submit" value="Register"class="btn btn-brand"/></p>
</div>
</form>
</div>

<div class="col-lg-3"></div>
</div>
</div>
</div>
