
<div style="padding:20px;">
<div>
<h4>Add content to lesson  <a href="<?php
echo base_url('index.php/lesson/'.$this->uri->segment(2).'');	
?>" style="float: right;padding: 5px;">Close</a></h4>
</div>
<div>
<?php
echo form_open_multipart();
?>

<div style="color: red;padding-top: 10px;">
<?php
echo validation_errors();	
?>
</div>
<p>
<?php
echo $this->session->flashdata('content_added');	
?>
</p>
<p>
<input  class="form-control" name="title" placeholder="Title"/>
</p>
<p>
<textarea class="form-control" style="height: 150px;" placeholder="Write content for the lesson" name="content"></textarea>
</p>
<p>
<input type="file" name="file" class="form-control" />
</p>
<p><input type="submit" value="Save content"class="btn-success"/></p>
</form>
</div>

</div>