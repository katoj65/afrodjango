<?php
echo form_open();
?>


<div  style="padding: 15px;padding-top: 0;">

<div style="color: red;">
<?php
echo validation_errors();
?>

</div>

<?php
echo $this->session->flashdata('faq_success');	
?>

<p>
<h4>Ask question on this lesson
<a href="<?php echo base_url('index.php/lesson/'.$this->uri->segment(2)); ?>" style="float: right;font-size: 15px;">Close</a>
</h4>
</p>


<p>
<textarea name="faq" class="form-control" style="height: 100px;" placeholder="Fill in your question">
</textarea></p>

<p>
<input type="submit" value="Ask question" class="btn-success" style="font-size:17px;"/>



<a href="" style="margin-left: 20px;">View all questions</a>

</p>

</div>

</form>
<hr />




















