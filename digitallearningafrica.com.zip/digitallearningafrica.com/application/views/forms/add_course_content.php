

<div  style="margin-top: -20px;margin-bottom: 20px;padding:20px;border: solid 2px #D5DBDB;">
<?php
echo form_open_multipart();
?>


<h4>Add lesson to the course</h4>

<div style="color: red;">
<?php
echo validation_errors();	
?>
</div>


<?php
echo $this->session->flashdata('lesson_success');	
?>


<p>
Lesson title:
<input type="text" name="title" class="form-control"/>
</p>

<p>
Lesson description:
<textarea name="desc" style="height: 150px;" class="form-control"></textarea>
</p>
<p>

<input type="file" name="file" style="border: solid thin silver;padding:10px;" />
</p>


<p><input type="submit" value="Add lesson"class="btn-success"/></p>

</div>












</form>
<hr />