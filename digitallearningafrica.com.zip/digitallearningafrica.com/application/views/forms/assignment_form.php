<div style="padding: 20px;margin-top: -20px;background: #FDFCBC;" class="menus">

<?php
echo form_open();	
?>
<p>
<span class="menus">Add assignment</span>
<span style="float:right;"><a href="<?php
echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/assignment');
?>">Close</a></span>
 
</p>

<div style="color: red;"><?php
echo validation_errors();
?></div>





<p>
Title
<input type="text" name="title" class="form-control" />
</p>

<p>
Description
<textarea style="height: 150px;" name="description" class="form-control">
</textarea>
</p>
<p>
<input type="submit" value="Save" class="btn-success" />
</p>






















</form>
</div>
