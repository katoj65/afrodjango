
<div style="padding:20px;background: #FDFCBC;margin-top: 10px;" class="menus">
<div>
<span class="menus">
Add assignment to lesson
</span>

 <a href="<?php
echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3));	
?>" style="float: right;padding: 5px;">Close</a></div>
<div>
<?php
echo form_open_multipart(base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/add/assignment'));
?>

<div style="color: red;padding-top: 10px;">
<?php
echo validation_errors();	
?>
</div>
<p>
<?php
echo $this->session->flashdata('assignment_added');	
?>
</p>
<p>
<input  class="form-control" name="title" placeholder="Tutorial title"/>
</p>
<p>
<textarea class="form-control" style="height: 150px;" placeholder="Tutorial content" name="content"></textarea>
</p>
<p>
<input type="file" name="file" class="form-control" />
</p>
<p><input type="submit" value="Save tutorial"class="btn-success"/></p>
</form>
</div>

</div>