<div class="shadow_bottom">




<?php
echo form_open();
echo('<div style="text-align:center;color:red;text-align:left;">');
echo validation_errors();
echo('</div>');
?>



<p>
<h4 style="margin-bottom: 10px;"><strong>Create your academic profile</strong></h4>

</p>



<p>
Level of education:
<select name="education" class="form-control">
<option value="">Select your academic level of education</option>
<?php
if($level->num_rows()>0){
foreach($level->result() as $level_row){
    
echo('<option value="'.$level_row->ID.'">'.ucfirst($level_row->level).'</option>');
    
}
unset($level_row);
}else{
echo('<option value="">No content</option>');
}
?>

</select>
</p>



<p>
Course of study:
<select name="interest" class="form-control">

<option value="">Select your course of study</option>

<?php
if($course->num_rows()>0){
foreach($course->result() as $course_row){
echo('<option value="'.$course_row->ID.'">'.ucfirst($course_row->name).'</option>');    
}    
unset($course_row);    
}else{
echo('<option value="">No content</option>');
}



?>



</select>
</p>




<p>
About:
<textarea name="about" class="form-control" style="height: 150px;" placeholder="Tell us about yourself"></textarea>
</p>


<p><input type="submit" value="Save my information"class="btn-success"/></p>

</form>
</div>