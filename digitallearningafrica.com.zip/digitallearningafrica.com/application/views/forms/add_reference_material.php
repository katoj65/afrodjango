
<div style="padding:20px;margin-top:0;" >
<div>
<h4>
Add reference material to lesson

<a href="<?php
echo base_url('index.php/lesson/'.$this->uri->segment(2));	
?>" style="float: right;padding: 5px;">Close</a>

</h4>
</div>
<div>
<?php
echo form_open_multipart(base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/add/reference'));
?>

<div style="color: red;padding-top: 10px;">
<?php
echo validation_errors();	
?>
</div>
<p>
<?php
//echo $this->session->flashdata('content_added');	
?>
</p>
<p>
<input  class="form-control" name="title" placeholder="Reference title"/>
</p>

<p>
<input type="text" name="url" class="form-control" placeholder="URL reference" />
</p>
<p><input type="submit" value="Save reference material"class="btn-success"/></p>
</form>
<hr />
</div>

</div>