<div id="request-quote" style="background: #F7F7F7;">
<div class="container">
<div class="row">
                
                
<div class="col-lg-4"></div>                
                
                
                
                
                
                
                
                
                
                
                
<div class="col-lg-4" style="color: black;">
<?php
echo form_open(base_url('index.php/login'));
?>


<div style="color: red;text-align: center;">
<?php
echo validation_errors();
echo $this->session->flashdata('login_error');	
?>

</div>




<div style="text-align: center;padding: 30px;" class="shadow_bottom">
<p>Username: <input type="text" name="username" class="form-control" placeholder="Fill in the username"/></p>
<p>Password: <input type="password" name="password" class="form-control" /></p>
<p><input type="submit" value="Login"class="btn btn-brand"/></p>
</div>
</form>


</div>
                
               


<div class="col-lg-4">

njdnjdn

</div>






            
</div>
</div>
</div>






