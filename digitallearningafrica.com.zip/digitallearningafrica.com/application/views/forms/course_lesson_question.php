<div>
<div style="text-align: center;"><h5><span class="shadow_bottom" style="font-size: 18px;">Communication to course learners</span></h5></div>

<div style="height: 500px;margin-top:30px;" class="shadow_bottom">


</div>
</div>
<hr />

