<style type="text/css">
<!--
body{
overflow: hidden;
}
-->
</style>





<div class="pageWrapper" style="margin-top:8%;z-index: 5;background: white;" id="illustration_switch_board">
<div style="margin: 50px;">
<h3 style="color:#ED4933;">
Tutorials
<a href="<?php
echo base_url('index.php/student/course/presentation/'.$row->ID);
?>" onclick="open_illustrations()" style="float: right;color:#ED4933;font-size:14px;">Close</a>
</h3>

<p><?php
echo ucfirst($row->name);
?></p>







</div>
</div>



