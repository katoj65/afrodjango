<?php
echo('<style type="text/css">
<!--
body{overflow:hidden;}
-->
</style>');	

?>







<div class="pageWrapper" style="background: rgba(0, 0, 0, 0.8);">
<div class="dialog" style="width: 30%;margin-left: 35%;margin-right: 35%;border: none;margin-top: 10%;">
<h4 style="padding: 10px;">Upload file


<span style="float: right;"><a href="<?php
echo base_url('index.php/trainer/course/content/'.$this->uri->segment(4).'/add');
?>" style="font-size: 15px;">Close</a></span>
</h4>
<hr />





<div style="padding: 30px;">

<?php
echo(form_open());
?>
<div style="color: red;">
<?php
echo validation_errors();
?>
</div>

<p><input type="text" name="title" placeholder="fill in the title for the file" style="width: 100%;"/></p>
<p><input type="file" name="file" /></p>
<p><input type="submit" name="save" value="Save upload" /></p>


</form>

</div>

</div>
</div>

