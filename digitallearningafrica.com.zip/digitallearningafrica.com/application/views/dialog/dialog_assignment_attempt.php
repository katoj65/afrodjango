

<?php
echo('<style type="text/css">
<!--
body{overflow:hidden;}	
-->
</style>');	
?>







<div class="pageWrapper" style="background: rgba(0, 0, 0, 0.8);">
<div class="dialog" style="width: 30%;margin-left: 35%;margin-right: 35%;border: none;height:220px;">
<div class="title" style="background: white;border: none;">
<strong>Are you sure you want to attempt this assignment?</strong> 
<a href="<?php echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/assignment');?>" class="btn btn-brand" style="margin-left: 10px;float: right;">Cancel</a>
</div>
<hr />
<h4 style="padding: 10px;text-align: center;font-size: 15px;" id="assignment_title">
</h4>

<p style="padding: 10px;text-align: center;">
<a href="<?php
echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4).'/attempt/'.$this->uri->segment(6).'/true');
?>" class="btn-success" style="font-size: 15px;padding: 10px;">YES</a></p>

















</div>
</div>