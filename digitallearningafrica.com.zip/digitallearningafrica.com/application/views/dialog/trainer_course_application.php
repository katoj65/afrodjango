<?php
echo('<style type="text/css">
<!--
body{overflow:hidden;}
-->
</style>');	

?>







<div class="pageWrapper" style="background: rgba(0, 0, 0, 0.8);">
<div class="dialog" style="width: 30%;margin-left: 35%;margin-right: 35%;border: none;">
<h4 style="padding: 10px;">Trainer application</h4>
<hr />



<div style="padding-left: 30px;padding-right: 30px;font-size: 17px;">
<span style="padding: 10px;background:#F7F7F7;padding-left:20px;padding-right:20px;border-bottom:solid thin silver;" class="round">

<?php
if($topics->num_rows()>1){
echo($topics->num_rows().' Courses');
}else{
echo($topics->num_rows().' Course');    
}
?>

</span>

</div>








<div style="padding: 30px;">
<?php
echo form_open();
echo('<div style="color:red;">');
echo validation_errors();
echo $this->session->flashdata('application');
echo('</div>');    
?>
Select course you want to offer training:
<select style="border: solid thin silver;width:100%;color:black;font-size:15px;padding: 10px;" 
name="course">
<?php


if($topics->num_rows()>0){
echo('<option value="">Select course</option>');
foreach($topics->result() as $row){
echo('<option value="'.$row->ID.'">'.ucfirst($row->name).'</option>');    
}
unset($row);

}else{
echo('<option value="">No content</option>');
}


	
?>
</select>


<p style="margin-top: 20px;">
<input type="submit" value="Apply for course" class="submit" style="padding: 10px;" />

<a href="<?php
echo base_url('');
?>" class="cancel" style="padding: 13px;">Cencel</a>

</p>
</form>
</div>

</div>
</div>