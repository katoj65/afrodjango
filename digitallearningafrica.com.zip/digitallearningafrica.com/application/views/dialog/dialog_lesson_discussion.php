<?php
echo('<style type="text/css">
<!--
body{overflow:hidden;}	
-->
</style>');	
?>


<?php
	
if($lesson->num_rows()==1){
foreach($lesson->result() as $row);
}    
    
    
?>









<div class="pageWrapper" style="background: rgba(0, 0, 0, 0.8);display: block;">
<div class="dialog" style="width: 50%;margin-left: 25.25%;margin-right: 25.25%;margin-top: -5px;border: none;margin-bottom: 2%;height: 102%;background: #E9EBEE;">





<div class="title" style="background: white;border-bottom:solid thin silver;margin-bottom: 0;">
<strong class="borders" style="color: gray;font-size: 15px;padding:5px;">Discussion</strong> 

<a href="<?php echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'');?>" class="btn btn-brand" style="margin-left: 10px;float: right;">Cancel</a>
</div>




<div>


<div style="padding: 15px;border-bottom:solid thin silver;background:aliceblue;" class="shadow_bottom">
<h4 style="padding:0px;color: black;margin:0;font-weight: bold;"><?php
echo ucfirst($row->title);	
?></h4>
<div style="font-size: 15px;color:black;padding: 10px;height: 95px;overflow: hidden;"><?php
echo ucfirst(ellipsize($row->description,500));
?></div>
</div>



<div id="scrollable_discussion_panel" class="scrollable_discussion_panel" style="height:530px;overflow:auto;border-bottom:solid thin silver">
<div class="div_discuss1">
<div class="col-lg-8">
<div style="padding:10px;margin-top:20px;">

<?php


if($discussion->num_rows()>0){

    
foreach($discussion->result() as $discuss){
$x=$discuss->ID;
$y=$x%2;    
if($y==0){
$flaot='float:right;';
}else{
$flaot='float:left;';
}
  
$str=ucfirst($discuss->content);  
echo('<div style="padding:20px;">
<span style="background:white;padding:5px;width:80%;border-right:solid thin silver;border-left:solid thin silver;color:gray;padding-left:15px;padding-right:15px;'.$flaot.'" class="round">
<img src="'.base_url('images/f20ce4f14541b744f6e17c0a7177d90c.jpg').'" style="padding:5px;background:white;width:40px;height:40px;margin-top:-20px;border-top:solid thin silver;'.$flaot.'" class="round" title="hello world"/>
'.wordwrap($str,100).'

<span style="color:#D9534F;float:right;font-size:12px;" class="round">'.nice_date($discuss->date,'h:s | d - m - Y ').'</span>
</span>
</div>'); 
}    
unset($discuss);    



}else{
echo('<div class="menus" style="background-color:white;text-align:center;">Start discussion now!</div>');
}

	
?>




</div>
</div>
<div class="col-lg-4">
<div style="padding: 10px;padding-top: 20px;border:solid thin silver;border-top:none;position: fixed;width:15.5%;z-index: 10000;background: #E9EBEE;" class="shadow1">

<?php
if(isset($row->file)){
echo('<div style="margin-bottom:10px;margin-top:-10px;height:170px;background-image:url('.base_url($row->file).');background-size:cover;background-repeat:no-repeat;max-width:300px;">');
echo('</div>');
}
?>



<span class="btn-danger" style="font-size: 15px;">Discussion topics </span>

<?php
if($other_lessons->num_rows()>0){
echo('<ul>');
foreach($other_lessons->result() as $others){
    
echo('<li style="padding:5px;">
<a href="'.base_url('index.php/lesson/'.$others->ID.'/'.$others->courseID.'/discussion').'">
'.ucfirst($others->title).'</a></li>');    
} 
unset($others);    

echo('</ul>');
}else{
echo('<div>No content</div>');
}	
    
?>







<?php
if($other_lessons->num_rows()<=3){
echo('<div style="border:solid thin silver;">');
echo $calendar;	
echo('</div>');
}
?>






</div>
</div>

</div>
</div>




<div style="padding: 20px;" class="col-lg-8">
<?php
echo form_open();	
?>
<div style="color: red;margin-top: -20px;position: absolute;">
<?php
echo validation_errors();
?>
</div>
<div style="border:solid thin silver;background: white;">
<textarea name="discuss" style="padding:10px;height:50px;border:none;width:82%;color:gray;"placeholder="Participate in the discussion">
</textarea>
<input type="submit" value="Send" style="margin: 10px;font-size: 16px; font-weight: bold; color: gray;" />
</form>
</div>




</div>



<div class="col-lg-3">

</div>



</div>
</div>