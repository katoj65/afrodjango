<div style="background: black;min-height: 300px;margin-bottom: 20px;" class="border_radius">








</div>
<div style="margin-bottom: 70px;">


<ul style="padding:0;color;blue;margin:0;">
<li style="float:left;margin-left:25px;color:#D5DBDB;margin-right:10px;"><a href="#">100 Classes</a></li>
<li style="float:left;margin-left:25px;color:#D5DBDB;margin-right:10px;"><a href="#">100 Subscribers</a></li>
<li style="float:left;margin-left:25px;color:#D5DBDB;margin-right:10px;"><a href="#">Schedule classroom</a></li>
<li style="float:left;margin-left:25px;color:#D5DBDB;margin-right:10px;">
<a href="#" class="btn btn-danger" style="padding:1px;padding-left:10px;padding-right:10px;">Record Now</a></li>

<li style="float:left;margin-left:25px;color:#D5DBDB;margin-right:10px;">
<a href="<?php
echo base_url('index.php/lesson/'.$this->uri->segment(2));
?>">Cancel</a></li>

</ul>


</div>
<hr />
