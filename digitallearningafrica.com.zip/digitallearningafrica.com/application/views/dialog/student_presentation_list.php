<style type="text/css">
<!--
body{
overflow: hidden;
}
-->
</style>





<div class="pageWrapper" style="margin-top:8%;z-index: 5;background: white;" id="illustration_switch_board">
<div style="margin: 50px;">
<h3 style="color:#ED4933;">
List of presentations
<a href="<?php
echo base_url('index.php/student/course/presentation/'.$row->ID);
?>" onclick="open_illustrations()" style="float: right;color:#ED4933;font-size:14px;">Close</a>
</h3>

<p><?php
echo ucfirst($row->name);
?>

<hr />

</p>


<div style="margin-top: 20px;width:34%;margin-left: 33%;margin-right: 33%;text-align: left;height: 500px;overflow: auto;min-width:400px;">

<?php
	
if($lessons->num_rows()>0){
echo('<ul>');
$array1=array();
$array1[0]=false;
$id=array();
$id[0]=false;



foreach($lessons->result() as $topic){
$array1[]=$topic->title;    
$id[]=$topic->ID;
}    

for($x=1;$x<=$lessons->num_rows();$x++){
echo('<li style="list-style:none;margin-bottom:5px;padding:5px;background:#F7F7F7;border-bottom:solid thin silver;padding-left:10px;padding-right:10px;" class="round">');
echo('<a href="'.base_url('index.php/student/course/presentation/'.$id[$x]).'" style="font-size:15px;"><span style="padding-right:10px;">'.$x.')</span> 
<span>'.ucfirst(ellipsize($array1[$x],53)).'</span></a>');
echo('</li>');    
}


echo('</ul>');

}else{
echo('No content');
}    
    
    
    
    
?>




</div>








</div>
</div>



