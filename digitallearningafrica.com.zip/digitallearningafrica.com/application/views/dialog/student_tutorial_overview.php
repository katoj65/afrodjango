<style type="text/css">
<!--
body{
overflow: hidden;
}
-->
</style>





<div class="pageWrapper" style="margin-top:8%;z-index: 5;background: white;" id="illustration_switch_board">
<div style="margin: 50px;">
<h3 style="color:#ED4933;">
Tutorial overview
<a href="<?php
echo base_url('index.php/student');
?>" onclick="open_illustrations()" style="float: right;color:#ED4933;font-size:14px;">Close</a>
</h3>

<p>
<?php
echo ucfirst($result->name);
?>
<hr />

</p>










<div style="margin-top: 20px;width:80%;margin-left: 10%;margin-right: 10%;text-align: left;height: 500px;
overflow:hidden;min-width:400px;">

<div class="row">
<div class="col-lg-9 col-md-9">
<div style="height: 500px;overflow: auto;">






<div>



<div class="panel-body">
<ul class="plan">
<li class="price" style="background: #565AB1;padding: 5px;border: solid thin #34296F;">
<strong style="font-size: 18px;"><?php
echo $lessons->num_rows();
?> Topics</strong>
</li>
<?php
if($lessons->num_rows()>0){
foreach($lessons->result() as $infomation){
echo('<li style="text-align:left;padding-left:20%;">
<a href="'.base_url('index.php/student/course/presentation/'.$infomation->ID).'"><i class="fa fa-bars"></i>'.ucfirst($infomation->title).'</li></a>');    
}
unset($infomation);
}else{
echo('<li><i class="fa fa-bars"></i><strong>No content </li>');
}
?>
</ul>
</div>




</div>






<?php
	
    
    
    
    
    
?>




</div>
</div>

<div class="col-lg-3 col-md-3">





<div class="panel-group pad-top-botm" id="accordion">
<div class="">
<div class="panel-heading">
<h4 class="panel-title panel-title-adjust">
<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" class="collapsed">
<i class="fa fa-plus"></i>Study Calendar</a>
</h4>
</div>
<div id="collapseOne" class="panel-collapse collapse" style="height: 0px;">
<div class="panel-body"> 
<?php
echo $calendar;
?>
</div>

</div>

</div>






</div>





</div>
</div>

















</div>






















</div>
</div>



