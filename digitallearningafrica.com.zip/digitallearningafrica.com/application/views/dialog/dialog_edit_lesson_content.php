<?php
echo('<style type="text/css">
<!--
body{overflow:hidden;}	
-->
</style>');	
?>


<div class="pageWrapper">
<div class="dialog" style="margin-top: 7%;">
<div class="title"><strong class="menus" style="color: gray;font-size: 15px;">Edit topic content</strong></div>
<div style="padding: 20px;padding-top:0;" class="img-responsive">
<?php
echo form_open_multipart(base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3)));	
?>
<p>
Edit title:
<input type="text" class="form-control" placeholder="Edit title" name="title" style="color: #FF4800;font-weight: bolder;" value="<?php echo ucfirst($content[0]); ?>"/></p>

<p>Edit content:
<textarea class="form-control" name="content" placeholder="Edit content" style="min-height: 200px;"><?php echo ucfirst($content[1]); ?></textarea></p>
<p>
<table style="height: 130px;width: 100%;">
<tr>

<?php
if($content[2]!=""){
echo('<td style="width: 50%;background-image: url('.base_url($content[2]).');background-size: cover;" class="border_radius">
</td>');    
}	
?>

<td style="padding-left: 20px;">
    Upload new file:
    <input type="file" name="file"  class="form-control" />
    </td>
</tr>
</table>
<?php
if($content[2]!=""){
echo('<hr />');
}	
?>

</p>


<p>

<input type="submit" value="Save" class="btn btn-brand"/> 
<a href="<?php echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'');?>" class="btn btn-brand" style="margin-left: 10px;">Cancel</a>


</p>


</form>
</div>
</div>
</div>