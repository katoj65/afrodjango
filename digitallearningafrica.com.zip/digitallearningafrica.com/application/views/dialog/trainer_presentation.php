<?php
echo('<style type="text/css">
<!--
body{overflow:hidden;}
-->
</style>');	

?>







<div class="pageWrapper" style="background: rgba(0, 0, 0, 0.8);">
<div class="dialog" style="width: 50%;margin-left: 25%;margin-right: 25%;border: none;margin-top:0;height:100%;">
<h4 style="padding: 10px;">Presentation form


<span style="float: right;"><a href="<?php
echo base_url('index.php/trainer/course/content/'.$this->uri->segment(4).'/add');
?>" style="font-size: 15px;">Close</a></span>
</h4>
<hr />
<div style="padding: 10px;">

Content.


</div>

</div>
</div>