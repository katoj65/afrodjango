<?php
echo('<style type="text/css">
<!--
body{overflow:hidden;}	
-->
</style>');	
?>


<div class="pageWrapper" style="background: rgba(0, 0, 0, 0.8);">
<div class="dialog" style="width: 45%;margin-left: 25.25%;margin-right: 25.25%;margin-top: -5px;border: none;margin-bottom: 2%;height: 102%;">
<div class="title" style="background: white;border: none;"><strong class="gradient" style="color: gray;font-size: 15px;">Topic illustrattion</strong> 

<a href="<?php echo base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'');?>" class="btn btn-brand" style="margin-left: 10px;float: right;">Cancel</a>

</div>
<div style="padding-top:0;" class="img-responsive">
<h4 style="padding: 10px;color:#FF4800;"><?php
echo ucfirst($content[0]);	
?></h4>

<div style="background: black;max-height: 530px; overflow-y: auto;overflow-x: hidden;">

<img src="<?php
echo base_url($content[1]);	
?>" style="width:100%;" class="img-responsive"/>

</div>



</div>
<div style="margin-top: 5px;padding:20px;">
<a href="#" class="menus">Ask question</a>



</div>
</div>
</div>