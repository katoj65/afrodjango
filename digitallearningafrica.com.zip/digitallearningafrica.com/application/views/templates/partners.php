   
    <!-- clientSection -->
	<div class="container">
		<h3 style="text-align: center;color:#FF4800;"><span class="shadow_bottom">Credited by</span></h3>
		<div class="clientSection">
			<div class="row">					
					<div class="col-md-2">
						<a href="#"><img alt="" src="assets/custom/img/14.png"></a>
					</div>
					<div class="col-md-2">
						<a href="#"><img alt="" src="assets/custom/img/35.png"></a>
					</div>
					<div class="col-md-2">
						<a href="#"><img alt="" src="assets/custom/img/1.png"></a>
					</div>
					<div class="col-md-2">
						<a href="#"><img alt="" src="assets/custom/img/2.png"></a>
					</div>
					<div class="col-md-2">
						<a href="#"><img alt="" src="assets/custom/img/3.png"></a>
					</div>
					<div class="col-md-2">
						<a href="#"><img alt="" src="assets/custom/img/4.png"></a>
					</div>
				</div>
		</div>
	 </div>
     </div>