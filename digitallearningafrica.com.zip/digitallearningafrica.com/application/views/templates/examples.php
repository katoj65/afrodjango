<?php
if($course_first->num_rows()==1){
foreach($course_first->result() as $result);    
}else{
redirect(base_url());
}	
?>

<div class="container">
<div class="row pad-top-botm">
<div class="col-lg-7 col-md-7">
<h4>

<span style="padding: 10px;background: #565AB1;color:white;border:solid thin #2B3C69;font-weight:normal;" class="border_radius">
Hands on guide
</span>
</h4>



<div style="margin-top: 20px;padding: 10px;">




<?php
if($couse_tutorials->num_rows()>0){
foreach($couse_tutorials->result() as $tutorial){
echo('<h3>
<span>
'.ucfirst($tutorial->title).'
</span></h3>');    
    
/**
 * File formation. 
 */
$file=base_url($tutorial->file);



echo('<p style="margin:10px;">');
echo('<img src="'.$file.'" style="width:100px;border:solid 10px #F7F7F7;"/>');
echo('</p>');


echo('<p style="padding:20px;background:white;font-size:15px;border:solid thin silver;" class="border_radius">
'.ucfirst($tutorial->description).'</p>');

    
    
}    
unset($tutorial);    
}else{
echo('<div>No content</div>');
}


?>










</div>



























</div>
























<div class="col-lg-5 col-md-5">


<?php
$this->load->view('pages/sidebar_right');
?>




</div>
</div>
</div>
   
    