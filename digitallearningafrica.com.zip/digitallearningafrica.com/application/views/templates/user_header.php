<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
     <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Digital Learning Africa</title>
    <!--  Bootstrap Style -->
    <link href="<?php
	echo base_url('assets/css/bootstrap.css');
?>" rel="stylesheet" />
     <!--  Font-Awesome Style -->
    <link href="<?php
	echo base_url('assets/css/font-awesome.min.css');
?>" rel="stylesheet" />
     <!--  Font-Awesome Animation Style -->
    <link href="<?php
	echo base_url('assets/css/font-awesome-animation.css');
?>" rel="stylesheet" />
     <!--  Pretty Photo Style -->
    <link href="<?php
    echo base_url('assets/css/prettyPhoto.css');
?>" rel="stylesheet" />
        <!--  Google Font Style -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
     <!--  Custom Style -->
    <link href="<?php
	echo base_url('assets/css/style.css');
?>" rel="stylesheet" />


    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
<style type="text/css">
<!--
	
.round,.round img{
border-top-right-radius: 40px;
-moz-border-radius-topright: 40px;
-webkit-border-top-right-radius:40px;
/*border radius left*/  
border-top-left-radius: 40px;
-moz-border-radius-topleft: 40px;
-webkit-border-top-left-radius: 40px;      

/*border radius right*/ 
border-bottom-right-radius: 40px;
-moz-border-radius-bottomright: 40px;
-webkit-border-bottom-right-radius: 40px;
/*border radius left*/  
border-bottom-left-radius: 40px;
-moz-border-radius-bottomleft: 40px;
-webkit-border-bottom-left-radius: 40px;    

}        




.shadow{
-moz-box-shadow: 2px 2px 5px #F0F0F0;
-webkit-box-shadow: 2px 2px 5px #F0F0F0;
box-shadow: 2px 2px 5px #F0F0F0;
}

/*Page Wrapper*/
.pageWrapper{
min-height:500px;
overflow: hidden;
min-width: 700px;
width:100%;
height:100%;
position:fixed;
border:none;
left: 0;
top:0;
background: rgba(0, 0, 0, 0.8);
z-index: 10000;
text-align: center;
}
.pageWrapper .dialog{
text-align: left;
border: none;
position:absolute;
padding-bottom:10px;
margin-left:35%;
margin-right:35%;
width:30%;
background-color:white; 
margin-top:150px;
border:solid 1px #C1CDCD;
color:black;
-moz-box-shadow: 0px 0px 25px black;
-webkit-box-shadow: 0px 0px 25px black;
box-shadow: 0px 0px 25px black;    

border-top-right-radius: 3px;
-moz-border-radius-topright: 3px;
-webkit-border-top-right-radius: 3px;
/*border radius left*/  
border-top-left-radius: 3px;
-moz-border-radius-topleft: 3px;
-webkit-border-top-left-radius: 3px;      

/*border radius right*/ 
border-bottom-right-radius: 3px;
-moz-border-radius-bottomright: 3px;
-webkit-border-bottom-right-radius: 3px;
/*border radius left*/  
border-bottom-left-radius: 3px;
-moz-border-radius-bottomleft: 3px;
-webkit-border-bottom-left-radius: 3px; 
overflow: hidden;
min-height: 200px;
min-width: 400px;




}

.submit{
background: #2B3C69;
padding:10px;
color:white;  
border:none; 
font-size:15px; 
}

.cancel{
background: #ED4933;
padding:10px;
color:white;  
border:none;
font-size:15px;     
}

.button{
    
}



.border_radius,.submit,.cancel,.button,select,input{
border-top-right-radius: 5px;
-moz-border-radius-topright: 5px;
-webkit-border-top-right-radius: 5px;
/*border radius left*/  
border-top-left-radius: 5px;
-moz-border-radius-topleft: 5px;
-webkit-border-top-left-radius: 5px;      

/*border radius right*/ 
border-bottom-right-radius: 5px;
-moz-border-radius-bottomright: 5px;
-webkit-border-bottom-right-radius: 5px;
/*border radius left*/  
border-bottom-left-radius: 5px;
-moz-border-radius-bottomleft: 5px;
-webkit-border-bottom-left-radius: 5px;      
}



select{
margin: 10px;    
}
input{
padding: 10px;
}



    
    
-->
</style>

<script type="text/javascript">
<!--
topic=0;
function topic_menu(){
if(topic==0){
$('#topic_menu').fadeOut();
topic=1;    
}else{
$('#topic_menu').fadeIn();
topic=0;    
}    
}	
-->
</script>






</head>
<body>
<?php
if($user->num_rows()==1){
foreach($user->result() as $user_row);
}else{
redirect(base_url());
}	
?>

















   <div class="navbar navbar-default navbar-fixed-top menu-back">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <a class="navbar-brand" href="<?php
	echo base_url();
?>" style="margin-top: 20px;">
                <span style="color: white;font-weight:bold;">DIGITAL LEARNING</span><span style="color: #FF6A00;font-weight:bold;"> AFRICA</span>
                </a>
            </div>
            <div class="navbar-collapse collapse" >
                <ul class="nav navbar-nav navbar-right">
                   
                    <li class="dropdown">
                        <a href="<?php
	echo base_url();
?>">HOME<i class="fa fa-folder-open-o"></i>
                            <span>Study content</span>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-left">
                            <li>
                                <a href="index1.html">
                                    <i class="fa fa-paperclip"></i>Mentors
              <span>replace this text</span>
                                </a>

                            </li>
                            <li>
                                <a href="index2.html">
                                    <i class="fa fa-comments-o"></i>Schools/Colleges
              <span>replace this text</span>
                                </a>

                            </li>
                          

                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="<?php
	echo base_url('index.php/courses');
?>">COURSES<i class="fa fa-folder-open-o"></i>
                            <span>Find a course</span>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-left">
                         <?php
	if($category->num_rows()>0){
 foreach($category->result() as $row){
 echo('<li>
<a href="'.base_url('index.php/'.strtolower($user_row->role).'/course/content/'.$row->ID).'">
 '.ucfirst($row->name).'
<span>'.ucfirst(ellipsize($row->description,30)).'</span>
</a>
</li>');
 }
 unset($row);      
	}else{
 echo('<li>
                                <a href="our-services.html">
                                    <i class="fa fa-edit"></i>No content
              
                                </a>

                            </li>');
	}
?>   
                           
                          

                        </ul>
                    </li>

                    <li class="dropdown">
                        <a href="<?php
echo base_url('index.php/student/book/store');
?>">BOOK STORE<i class="fa fa-image"></i>
                            <span>Find a book</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-left">

                            <li>
                                <a href="4column-portfolio.html">
                                    <i class="fa fa-paper-plane-o"></i>Book categories
              <span>replace this text</span>
                                </a>

                            </li>
                            <li>
                                <a href="3column-portfolio.html">
                                    <i class="fa fa-folder-open-o"></i>Rent a book
              <span>replace this text</span>
                                </a>

                            </li>
                            <li>
                                <a href="2column-portfolio.html">
                                    <i class="fa fa-bullhorn"></i>Buy a book
              <span>replace this text</span>
                                </a>

                            </li>
                        </ul>
                    </li>

                   
                    <li class="dropdown">
                        <a href="<?php
	echo base_url('index.php/user');?>"><?php
	echo '<span style="font-size:17px;">'.ucfirst($user_row->fname).' '.ucfirst($user_row->lname).'</span>';
?><span><strong>Role:</strong> <?php
echo ucfirst($user_row->role);
?></span>
                        </a>
                        
                    
<ul class="dropdown-menu dropdown-menu-left">


<li><a href="4column-portfolio.html">Messages
<span>100 new</span></a>
</li> 





            
                   
                   
                   
</ul>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    </li>
                     
                     
                     
                     
                     
                     
                     <li class="dropdown">
                        <a href="<?php
	echo base_url('index.php/logout');
?>">LOGOUT <i class="fa fa-globe"></i>
                            <span>Exit the system</span>
                        </a>

                    </li>
                </ul>
            </div>

        </div>
    </div>