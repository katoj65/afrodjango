   <div id="just-middle-row" style="background:#565AB1;">
        <div class="container">
                <div class="row pad-top-botm">
                <div class="col-lg-12 col-md-12">
                    <h1><?php
	//echo $note;
?></h1>




<p> 
<div style="text-align: center;margin:30px;margin-top: 50px;">

<span style="padding: 20px;border:solid 3px silver;" class="round">
<a href="" style="font-size: 25px;"><span>Bootcamps</span></a>


<a href="" style="font-size: 25px;"><span>Virtual classroom</span></a>
</span>



</div> </p>






                    </div>
                </div>
            </div>
        </div>