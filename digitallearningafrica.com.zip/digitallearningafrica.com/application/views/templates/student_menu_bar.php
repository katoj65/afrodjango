<style type="text/css">
<!--
#student_menu ul li{
float: left;
margin-right: 20px;
list-style: none;
}

#student_menu ul li a{
font-size: 14px;
padding: 5px;
}








	
-->
</style>





<div id="student_menu">
<ul>
<li><a href="<?php
echo base_url();
?>">Tutorials (<?php
if($topics->num_rows()>0){
echo $topics->num_rows();
}
?>)</a></li>
<li><a href="<?php
echo base_url('index.php/student/tutorials');
?>"> Hands on guide</a></li>
<li><a href="<?php
	echo(base_url('index.php/student/examples'));
?>"> Examples</a></li>
<li><a href="<?php
	echo(base_url('index.php/student/reference'));
?>"> Reference material</a></li>
<li><a href="<?php
	echo(base_url('index.php/student/assignments'));
?>"> Assessments</a></li>
<li><a href="<?php
	echo(base_url('index.php/student/calendar'));
?>"> Shedules</a></li>
<li><a href="<?php
	echo(base_url('index.php/student/events'));
?>">Events</a></li>
</ul>
</div>











