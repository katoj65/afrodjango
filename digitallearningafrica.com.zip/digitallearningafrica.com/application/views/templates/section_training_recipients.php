<div style="padding-top: 20px;">
<table style="width: 100%;margin: 30px;margin-bottom: 0;">
<tr>
	<td style="width: 250px;padding:15px;font-size: 20px;text-align:center;
    background:#34296F;color: white;" class="border_radius">
    <strong>Computer literacy and Python programming training programme</strong></td>
	<td style="width: 200px;">
    <hr style="border: solid 6px #34296F;" />
    </td>
	<td style="width: 20px;padding:10px;font-size: 30px;">
    <a href="#" style="color: black;font-family: fantasy;">PWDs</a></td>
	<td>
    <hr style="border: solid 6px #34296F;"/>
    </td >
	<td style="width: 20px;padding:10px;font-size: 30px;font-family: fantasy;">
    <a href="#" style="color: black;">Refugees</a></td>
	<td>
    <hr style="border: solid 6px #34296F;"/>
    </td>
    <td style="width: 20px;padding:10px;font-size: 30px;font-family: fantasy;">
    <a href="#" style="color: black;">Others</a></td>
</tr>
</table>
</div>