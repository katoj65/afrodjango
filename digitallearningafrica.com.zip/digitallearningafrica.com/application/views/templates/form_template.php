    <div id="request-quote">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="text-center">
                        <h3>REQUEST A QUOTE NOW</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing  condimentum. </p>
                        <br />
                        <br />
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <form>
                        <div class="col-lg-12 col-md-12 ">
                            <div class="form-group">
                                <input type="text" class="form-control" required="required" placeholder="Name" />
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12">
                            <div class="form-group">
                                <input type="text" class="form-control" required="required" placeholder="Email address" />
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12">
                            <div class="form-group">
                                <input type="text" class="form-control" required="required" placeholder="Notes" />
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12">
                            <button type="submit" class="btn btn-primary">SUBMIT REQUEST</button>

                        </div>
                    </form>

                </div>
                <div class="col-lg-6 col-md-6">
                    <blockquote>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. Consectetur adipiscing elit onec molestie non sem vel condimentum </p>
                        <small>Consectetur adipiscing elit</small>
                    </blockquote>

                </div>
            </div>

        </div>

    </div>