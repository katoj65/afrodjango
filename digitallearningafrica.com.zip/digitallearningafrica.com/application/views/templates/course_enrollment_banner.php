<!-- highlightSection -->
    <div class="highlightSection" style="height:400px;background-image:url('<?php
	echo base_url('background/computer_ training.jpg');
?>');color:white;text-shadow: 1px 1px 1px black;">
		<div class="container">
			<div class="row">
			<div class="col-md-8">
			 <h2>
             <div style="display: inline-table;min-width:200px;">
            
            
            <?php
	echo $heading;
?>
             </div>
             </h2>
			 <h4 style="height: 120px;overflow:hidden;">
             <?php
echo $description;	
?>
             
             </h4>
			</div>
			<div class="col-md-4 align-right"> 
			<h4><?php
	echo $attributes;
?></h4>
			

<?php
if($course->num_rows()==1){
foreach($course->result() as $course_content);       
}


if($course_content->author==$user->ID){
 echo('<span class="btn btn btn-brand">COURSE CONSULTANT</span>');      
}else{

if($enrollment->num_rows()==1){
     
echo('<a class="btn btn btn-brand" href="'.base_url('index.php/course/'.$this->uri->segment(2).'/cancel').'">Cancel enrollment</a>');   
    
}elseif($enrollment->num_rows()==0){
     
echo('<a class="btn btn btn-brand" href="'.base_url('index.php/course/'.$this->uri->segment(2).'/enroll').'">Enroll Now</a>');   
     
}	
}


?>




				</p>
			</div>
			</div>
		</div>
	</div>