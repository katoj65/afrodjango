<div id="main-slider">

        <div id="carousel-example" class="carousel slide" data-ride="carousel">

            <div class="carousel-inner" style="height: 400px;">
                <div class="item active">

                    <img src="assets/img/1.jpg" alt="" />
                    <div class="carousel-caption ">
                        <h4 class="back-light">Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                        </h4>
                    </div>
                </div>
                <div class="item">
                    <img src="assets/img/2.jpg" alt="" />
                    <div class="carousel-caption ">
                        <h4 class="back-light">Faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                        </h4>
                    </div>
                </div>
                <div class="item">
                    <img src="assets/img/3.jpg" alt="" />
                    <div class="carousel-caption ">
                        <h4 class="back-light">Cenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                        </h4>
                    </div>
                </div>
            </div>
            
        </div>

    </div>
   
