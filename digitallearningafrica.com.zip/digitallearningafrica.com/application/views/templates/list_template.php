<section id="service-info">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-12 col-md-12">
                    <h3 class="clr-main"><strong>OUR SERVICE LIST </strong></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
                    <br />
                    <br />
                </div>
            </div>
            
            
            
            
            
            
            
            
            
            
 <div class="row pad-top-botm">
                <div class="col-lg-4 col-md-4">
                    <div class="media">
                        <div class="pull-left">
                            <i class=" fa fa-folder-open-o fa-4x rotate-icon "></i>

                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Easy To code</h3>
                            <p>
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc. 
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="media">
                        <div class="pull-left">
                            <i class="fa fa-power-off fa-4x rotate-icon "></i>
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Best To Use</h3>
                            <p>
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc. 
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="media">
                        <div class="pull-left">
                            <i class="fa fa-paper-plane-o fa-4x rotate-icon "></i>
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Customize Friendly</h3>
                            <p>
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc. 
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                            </p>

                        </div>
                    </div>
                </div>
            </div>
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
</div>
</section>