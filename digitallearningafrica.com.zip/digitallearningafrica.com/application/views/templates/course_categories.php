  <!--./ stats div end -->
      <div id="media-sec" style="background: #F7F7F7;color: black;">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3><?php
echo ucfirst($description);
?></h3>
                        <p><?php
echo $count_course.' Software development courses available ';
?> </p>

<p style="padding: 0;margin: 0;padding-top: 30px;">
<span><a href="<?php
echo base_url('index.php/register');
?>" style="padding: 10px;background: #ED4933;color:white;font-size:20px;padding-left:25px;padding-right:25px;" class="round">
Register now</a></span>

</p>


                        <br />
                        <br />
                    </div>
                </div>
                
               
                
                
                
                

 
 
 
 
 <?php
if($category->num_rows()>0){
foreach($category->result() as $cat){
       
echo('<div class="col-lg-4 col-md-4">
 <blockquote style="border:none;">
<div style="padding:20px;"><p><strong><div style="text-align:center;font-size:20px;">'.ucfirst($cat->name).'</div></strong><br/>
<div style="font-size:15px;padding:10px;background:white;border:solid 1px silver;" class="shadow1">'.ucfirst(ellipsize($cat->description,180)).'</div></p>
<small style="text-align:center;">View course content</small>
<div style="height:200px;margin-top:30px;">
<img src="'.base_url($cat->file).'" style="width:100%;height:130px;padding:15px;background-color:white;border:solid 1px silver;" class="shadow1"/>
</div>
</div>
</div>');
}    
}	
        
?>
 
 


 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
                
                
 
                
                
                
                
                
                
                
    
                
                
                
                
                
                
            </div>

        </div>

    </div>
    <!--./ Media Section End -->