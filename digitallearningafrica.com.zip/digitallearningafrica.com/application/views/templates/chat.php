<?php
$css=FALSE;

if(!isset($this->session->ID)){
$css='display:none;';
}elseif(isset($this->session->ID)){

if($page=='create_profile'){

$css='display:none';

}else{


$css='display:none;';


}
}	


?>


<?php
$chat=array();
if($this->uri->segment(1)=='lesson'){
if($this->uri->segment(4)=='communication'){

$chat['title']=ucfirst('Talk to learners');    
$chat['description']='<strong>'.ucfirst('nejenj').'</strong>';
$chat['icon']='<img src="'.base_url('icons/online-forms.png').'" class="img-circle" style="width:35px;height:35px;"/>';


}else{

$chat['title']='Conversation';
$chat['icon']="";
$chat['description']="njnjdndj";
    
    
    
}
    
}else{

$chat['title']='Conversation';
$chat['icon']="njnj";
$chat['description']="hello world";

}	









?>

<div style="width:22%;position:fixed;z-index: 100;margin-left: 78%;height:100%;margin-top: 15%;background: #E9EBEE;<?php echo($css);?>" class="chat">
<div style="height: 500px;">

<div style="padding: 10px;padding-top:20px;">
<span class="menus" style="background: white;">
<?php
echo($chat['title']);	
?>
</span>
<a href="#" style="float: right;font-size:13px;" class="menus" onclick="chat_hide();">Close</a>
</div>








<div style="padding: 10px;height:50px;overflow:hidden;width:100%;padding-top: 0;">
<div class="col-lg-3" style="width: 50px;padding: 0;margin: 0;">
<?php
echo($chat['icon']);	
?>
</div>
<div class="col-lg-8" style="padding: 0;margin: 0;">
<div class="btn-success" style="padding: 5px;border:solid thin gray;width:100%;">
<?php
echo $chat['description'];	
?>
</div>
</div>
</div>












<div style="padding: 10px;height:301px;overflow-y:auto;width: 100%;">


Person chating with

<div style="height: 100000px;">


<?php
echo $user->fname;	
?>

</div>








</div>

<div style="color: red;padding-left: 15px;height: 20px;">
</div>


<div style="border-top:solid thin silver;">


<textarea style="height: 80px;width:100%;background: white;border:none;padding:5px;color:gray;outline: none;font-size:13px;" placeholder="Write conversation" name="chat"></textarea>

<div style="padding:13px;padding-left: 10px;padding-right: 10px;text-align: center;">


<div class="row">


<div class="col-lg-4">
<a href="" style="color: gray;font-size:13px;" class="menus">Discussions</a> 
</div>



<div class="col-lg-4">
<a href="" style="color: gray;font-size:13px;" class="menus">Consultations</a> 
</div>


<div class="col-lg-4">
 <input type="button" value="Send" style="border: solid thin gray; background: #FF4800;font-weight: bolder;color: white;margin-left: 7px;" class="border_radius"/>
</div>

 
</div>



</div>


</div>
</div>
</div> 