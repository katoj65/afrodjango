   
    <!--./ Main Slider End -->
    <div id="welocme-note">

        <div class="welcome-div" >
        <span style="font-size: 20px;"><?php
	echo ucfirst($attributes);
?></span>



<div style="margin-top: 20px;">

<?php
$menu=array('Computer Literacy','PWDs','Refugees','Others');	
$count=count($menu)-1;
?>


<ul class="menus">

<?php
for($x=0;$x<=$count;$x++){
echo('<li style="border:solid 4px #34296F;color:#34296F;width:180px;padding:10px;min-width:200px;font-size:16px;margin:5px;" class="round">');
echo '<a href="" style="color:#34296F;font-family:fantasy;"><strong>'.$menu[$x].'</strong></a>';
echo('</li>');
}
?>
</ul>








</div>













</div>
</div>
    <!--./ Welcome Section End -->