<section id="vedio-sec">
        <div class="container">
            <div class="row pad-top-botm">
                <div class="col-lg-6 col-md-6">
                    <h2>What Is Special About Us ? </h2>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
     Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                    </p>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
     Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         
                    </p>
                    <button class="btn btn-primary" type="button">
                        Read Full Details <span class="badge">+</span>
                    </button>
                    <br />
                    <br />
                </div>

                <div class="col-lg-6 col-md-6">
                    <iframe class="vedio-style" src="http://www.youtube.com/embed/VpZmIiIXuZ0" ></iframe>



                </div>
            </div>
        </div>
    </section>
    