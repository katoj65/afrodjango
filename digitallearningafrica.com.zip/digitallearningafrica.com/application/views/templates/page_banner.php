    <div class="middle-section">
        <div class="container">
            <div class="row ">
                <div class="col-lg-12 col-md-12 ">
                    <h2><?php
	echo strtoupper($heading);
?></h2>
                    <div id="testimonials" class="carousel slide" data-ride="carousel">

                        <ol class="carousel-indicators">
                            <li data-target="#testimonials" data-slide-to="0" class=""></li>
                            <li data-target="#testimonials" data-slide-to="1" class=""></li>
                            <li data-target="#testimonials" data-slide-to="2" class="active"></li>
                        </ol>

                        <div class="carousel-inner">
                           
                           
                           
                           
                         
                            <div class="item active">
                                <div class="container center">
                                    <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 slide-custom">
                                        <h4><i class="fa fa-quote-left"></i><?php
	echo ucfirst($description);
?><i class="fa fa-quote-right"></i></h4>
                                        <div class="user-img pull-right">
                                            <img src="assets/img/user.gif" alt="" class="img-u image-responsive" />
                                        </div>
                                        <h5 class="pull-right"><strong class="c-black">Sed ultricies</strong></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>