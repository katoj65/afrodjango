<!-- highlightSection -->
    <div class="highlightSection" style="height:400px;background-image:url('<?php
	echo base_url('background/computer_ training.jpg');
?>');color:white;text-shadow: 0px 0px 2px black;">
		<div class="container">
			<div class="row">
			<div class="col-md-8">
			 <h2>
             <div style="display: inline-table;min-width:200px;">
            <?php
	echo $heading;
?>
             </div>
             </h2>
		 <h4>
             <?php
echo $description;	
?>
             
             </h4>
			</div>
			<div class="col-md-4 align-right"> 
			<h4><?php
	echo $attributes;
?></h4>
			<a class="btn btn btn-brand" href="#">Enroll Now</a>
				</p>
			</div>
			</div>
		</div>
	</div>