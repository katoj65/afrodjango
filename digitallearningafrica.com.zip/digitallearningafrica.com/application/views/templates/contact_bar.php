<div class="div-social-top">

        <i class="fa fa-globe "></i>E-mail:  <?php
	echo $email->content;
?>   | <i class="fa fa-mobile "></i>Call: : <?php
echo $tel->content;
?>  |  <i class="fa fa-map-marker "></i> <?php
echo $timezone;
?> &nbsp;
              <a href="#">
                  <i class="fa fa-facebook-square "></i>
              </a>

        <a href="#">
            <i class="fa fa-linkedin-square "></i>
        </a>
        <a href="#">
            <i class="fa fa-pinterest-square "></i>
        </a>


    </div>
    