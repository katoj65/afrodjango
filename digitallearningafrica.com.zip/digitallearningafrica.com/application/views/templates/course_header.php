<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    

<style type="text/css">
<!--
.h1{
padding:30px;border-bottom: solid 2px #E9E9E9;padding-bottom: 30px;color:gray;margin-bottom: 20px;    
}
.pageWrapper .dialog div::-webkit-scrollbar-button:start:decrement,
.pageWrapper .dialog div::-webkit-scrollbar-button:end:increment  {

} 

.line_big{
background:#F7F7F7;border-top:solid thin #E9EBEE;margin-top:20px;margin-bottom:20px;    
}

.borders{
padding:10px;
border:solid 1px #C7C5C5; 
color: #FF4800;    
background:-webkit-gradient(linear,left top,left bottom,from(white),to(rgba(0,0,0,0.05)));
background:-moz-linear-gradient(top,white,rgba(0,0,0,0.05));
-pie-background:linear-gradient(top,white,rgba(0,0,0,0.05));


}

.gradient{
padding:10px;  
background:-webkit-gradient(linear,left top,left bottom,from(white),to(rgba(0,0,0,0.05)));
background:-moz-linear-gradient(top,white,rgba(0,0,0,0.05));
-pie-background:linear-gradient(top,white,rgba(0,0,0,0.05));  
border-top-right-radius: 10px;
-moz-border-radius-topright: 10px;
-webkit-border-top-right-radius: 10px;
/*border radius left*/  
border-top-left-radius: 10px;
-moz-border-radius-topleft: 10px;
-webkit-border-top-left-radius: 10px;      

/*border radius right*/ 
border-bottom-right-radius: 10px;
-moz-border-radius-bottomright: 10px;
-webkit-border-bottom-right-radius: 10px;
/*border radius left*/  
border-bottom-left-radius: 10px;
-moz-border-radius-bottomleft: 10px;
-webkit-border-bottom-left-radius: 10px; 
}



.chat{
position:fixed;
border:none;
left: 0;
top:0;
z-index: 10000000;
border-top-right-radius: 0px;
-moz-border-radius-topright: 0px;
-webkit-border-top-right-radius: 0px;
/*border radius left*/  
border-top-left-radius: 10px;
-moz-border-radius-topleft: 10px;
-webkit-border-top-left-radius: 10px;      

/*border radius right*/ 
border-bottom-right-radius: 3px;
-moz-border-radius-bottomright: 3px;
-webkit-border-bottom-right-radius: 3px;
/*border radius left*/  
border-bottom-left-radius: 3px;
-moz-border-radius-bottomleft: 3px;
-webkit-border-bottom-left-radius: 3px;         
border:solid thin silver;

}


.big_icon{
width:40px;height:40px;
}


.pageWrapper .dialog .title{
padding: 15px;
background: #F6F7F8;    
border-top: solid thin #EDEDED;
border-bottom: solid thin rgba(0,0,0,0.03);
font-size: 13px;
color:black;
}    
  

/*Page Wrapper*/
.pageWrapper{
min-height:500px;
overflow: hidden;
min-width: 700px;
width:100%;
height:100%;
position:fixed;
border:none;
left: 0;
top:0;
background: rgba(0, 0, 0, 0.7);
z-index: 100000;
text-align: center;
}



.pageWrapper .dialog{
text-align: left;
border: none;
position:absolute;
padding-bottom:10px;
margin-left:35%;
margin-right:35%;
width:30%;
background-color:white; 
margin-top:200px;
border:solid 1px #C1CDCD;
color:black;
-moz-box-shadow: 0px 0px 25px black;
-webkit-box-shadow: 0px 0px 25px black;
box-shadow: 0px 0px 25px black;    

border-top-right-radius: 3px;
-moz-border-radius-topright: 3px;
-webkit-border-top-right-radius: 3px;
/*border radius left*/  
border-top-left-radius: 3px;
-moz-border-radius-topleft: 3px;
-webkit-border-top-left-radius: 3px;      

/*border radius right*/ 
border-bottom-right-radius: 3px;
-moz-border-radius-bottomright: 3px;
-webkit-border-bottom-right-radius: 3px;
/*border radius left*/  
border-bottom-left-radius: 3px;
-moz-border-radius-bottomleft: 3px;
-webkit-border-bottom-left-radius: 3px; 
overflow: hidden;
min-height: 200px;
min-width: 400px;




}

.btn-success,.borders{
border-top-right-radius: 10px;
-moz-border-radius-topright: 10px;
-webkit-border-top-right-radius: 10px;
/*border radius left*/  
border-top-left-radius: 10px;
-moz-border-radius-topleft: 10px;
-webkit-border-top-left-radius: 10px;      

/*border radius right*/ 
border-bottom-right-radius: 10px;
-moz-border-radius-bottomright: 10px;
-webkit-border-bottom-right-radius: 10px;
/*border radius left*/  
border-bottom-left-radius: 10px;
-moz-border-radius-bottomleft: 10px;
-webkit-border-bottom-left-radius: 10px;
padding:3px;
padding-left:10px;
padding-right:10px;    
}

.rds,.btn-danger{
border-top-right-radius: 5px;
-moz-border-radius-topright: 5px;
-webkit-border-top-right-radius: 5px;
/*border radius left*/  
border-top-left-radius: 5px;
-moz-border-radius-topleft: 5px;
-webkit-border-top-left-radius: 5px;      

/*border radius right*/ 
border-bottom-right-radius: 5px;
-moz-border-radius-bottomright: 5px;
-webkit-border-bottom-right-radius: 5px;
/*border radius left*/  
border-bottom-left-radius: 5px;
-moz-border-radius-bottomleft: 5px;
-webkit-border-bottom-left-radius: 5px;
padding:3px;
padding-left:10px;
padding-right:10px;    
}




.line{padding:5px;border-bottom:solid thin silver;padding-bottom:10px;}
.menus{
padding:5px;
background-color: #E9EBEE;
margin: 3px; 
border-top-right-radius: 10px;
-moz-border-radius-topright: 10px;
-webkit-border-top-right-radius: 10px;
/*border radius left*/  
border-top-left-radius: 10px;
-moz-border-radius-topleft: 10px;
-webkit-border-top-left-radius: 10px;      

/*border radius right*/ 
border-bottom-right-radius: 10px;
-moz-border-radius-bottomright: 10px;
-webkit-border-bottom-right-radius: 10px;
/*border radius left*/  
border-bottom-left-radius: 10px;
-moz-border-radius-bottomleft: 10px;
-webkit-border-bottom-left-radius: 10px;
border-top:solid thin silver;   
padding-left:10px;
padding-right:10px; 
}


.shadow{
-moz-box-shadow: 0px 0px 2px silver;
-webkit-box-shadow: 0px 0px 5px silver;
box-shadow: 0px 0px 2px silver;     
}

.shadow,.image{
-moz-box-shadow: 0px 0px 4px gray;
-webkit-box-shadow: 0px 0px 4px gray;
box-shadow: 0px 2px 4px gray;     
}

.image{
border:solid 10px silver;   
}


.shadow_bottom1,#colored_banner{
-moz-box-shadow: 0px 1px 2px #D9D9D9;
-webkit-box-shadow: 0px 1px 2px #D9D9D9;
box-shadow: 0px 1px 2px #D9D9D9;  
  
}


.shadow_bottom{
-moz-box-shadow: 0px 4px 4px #D9D9D9;
-webkit-box-shadow: 0px 4px 4px #D9D9D9;
box-shadow: 0px 4px 4px #D9D9D9;  
padding:10px;
  
}



.shadow1{
-moz-box-shadow: 0px 0px 4px #D9D9D9;
-webkit-box-shadow: 0px 0px 4px #D9D9D9;
box-shadow: 0px 0px 4px #D9D9D9;  
padding:10px;
  
}








.pallet{
-moz-box-shadow: 0px 4px 4px #D9D9D9;
-webkit-box-shadow: 0px 4px 4px #D9D9D9;
box-shadow: 0px 4px 4px #D9D9D9;  
padding:10px;
  
}



.round,.pallet{
    
border-top-right-radius: 20px;
-moz-border-radius-topright: 20px;
-webkit-border-top-right-radius: 20px;
/*border radius left*/  
border-top-left-radius: 20px;
-moz-border-radius-topleft: 20px;
-webkit-border-top-left-radius: 20px;      

/*border radius right*/ 
border-bottom-right-radius: 20px;
-moz-border-radius-bottomright: 20px;
-webkit-border-bottom-right-radius: 20px;
/*border radius left*/  
border-bottom-left-radius: 20px;
-moz-border-radius-bottomleft: 20px;
-webkit-border-bottom-left-radius: 20px;     
    
    
}



.topHeaderSection{
-moz-box-shadow: 0px 0px 4px #D9D9D9;
-webkit-box-shadow: 0px 0px 4px #D9D9D9;
box-shadow: 0px 0px 4px #D9D9D9;      
}















.error{padding: 10px;background: linen;margin: 10px;}	
.success{padding: 10px; background:#BAF7E8;margin: 10px;}
.border_radius,.title,#discussion_chat{
border-top-right-radius: 3px;
-moz-border-radius-topright: 3px;
-webkit-border-top-right-radius: 3px;
/*border radius left*/  
border-top-left-radius: 3px;
-moz-border-radius-topleft: 3px;
-webkit-border-top-left-radius: 3px;      

/*border radius right*/ 
border-bottom-right-radius: 3px;
-moz-border-radius-bottomright: 3px;
-webkit-border-bottom-right-radius: 3px;
/*border radius left*/  
border-bottom-left-radius: 3px;
-moz-border-radius-bottomleft: 3px;
-webkit-border-bottom-left-radius: 3px;      
}

.title{
background:#5CB85C;padding:3px;color:white; padding-left:10px;padding-right:10px;
border:solid 1px white;
}

.btn-success{font-size: 17px;}

.cal tr th, .cal tr td{
padding:3%;    
}

.down{
height:15px;width:10px;
margin-left:50%;
margin-right:50%;
background: #E9EBEE;
border:solid thin silver;    
border-top: none;
border-bottom: none;
}


-->
</style>   
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <title>Digital Learning Africa</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php
	echo base_url();
?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="themes/assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

	<!-- CSS Implementing Plugins -->
    <link rel="stylesheet" href="<?php
	echo base_url();
?>assets/custom/css/flexslider.css" type="text/css" media="screen">    	
    <link rel="stylesheet" href="<?php
	echo base_url();
?>assets/custom/css/parallax-slider.css" type="text/css">
    <link rel="stylesheet" href="<?php
	echo base_url();
?>assets/font-awesome-4.0.3/css/font-awesome.min.css" type="text/css">

    <!-- Custom styles for this template -->
	
    <link href="<?php
	echo base_url();
?>assets/custom/css/business-plate.css" rel="stylesheet">
    <link rel="shortcut icon" href="<?php
	echo base_url();
?>assets/custom/ico/favicon.ico">
  
<script src="<?php echo base_url('js/education.js');?>"></script>  
<script src="<?php echo base_url('js/jquery-3.3.1.min.js');?>"></script> 
  
  
  </head>
<!-- NAVBAR
================================================== -->
<body>

    
 <?php
if($this->session->ID!=""){
$this->load->view('templates/chat',$user);	
}
?>
    
    
    
    
    <div class="top" style="background:aliceblue;padding: 10px;">
    <div class="container">
        <div class="row-fluid">
            <ul class="phone-mail">
                <li><i class="fa fa-phone"></i><span>074 11 9211 00</span></li>
                <li><i class="fa fa-envelope"></i><span>admin.dla@gmail.com</span></li>
                <li>| <?php
if(isset($this->session->ID)){
echo '<img src="'.base_url($my_course->file).'" style="width:20px;height:20px;border:solid thin silver;" class="img-circle"/> <em style="color:#FF4800;">'.ucfirst($my_course->name).'</em>';
}	
?></li>
            </ul>
            
            
            
            
            <ul class="loginbar">
<?php
if(isset($this->session->ID)){


echo('<li><a href="'.base_url('index.php/user/'.$user->fname.'_'.$user->lname).'" class="login-btn" style="font-size:15px;"><strong>Welcome '.ucfirst($user->lname).'! </strong></a></li>
                <li class="devider">&nbsp;</li>
                <li><a href="'.base_url('index.php/logout').'" class="login-btn">Logout</a></li>
            '); 



}else{
    
echo('<li><a href="'.base_url('index.php/register').'" class="login-btn">Register</a></li>
                <li class="devider">&nbsp;</li>
                <li><a href="'.base_url('index.php/login').'" class="login-btn">Login</a></li>
            ');    
    
    
}

	
?>                
                
                
                
                
               
            
            
            
            
            
            </ul>
        </div>
    </div>
	</div>
	
    
    
    
    
    
    
    
    
    
    <!-- topHeaderSection -->	
    <div class="topHeaderSection">		
    <div class="header">			
		<div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php
	echo base_url();
?>" style="padding: 30px;" >Digital Learning Africa</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="<?php
	echo base_url();
?>">Home</a></li>
            
    
<li><a href="<?php
	echo base_url('index.php/courses');
?>">Courses</a>
              
            </li>
            
            
 <?php
if(isset($this->session->ID)){
if($page=='course_lesson' or $page=='lesson_assignment'){

echo('<li>');
echo('<a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3)).'"class="btn btn-brand" style="color:white;">Enrolled</a>');
echo('</li>');




}else{


if($enrollment->num_rows()>0){
echo('<li>');
echo('<a href="'.base_url('index.php/enrolled').'"class="btn btn-brand" style="color:white;">('.$enrollment->num_rows().') Enrolled</a>');
echo('</li>');    
}	


}
}
?>             
            
            
            
            <li><a href="<?php
	echo base_url('index.php/library');
?>">Library</a></li>
           
    
                
            <li><a href="<?php
	echo base_url('index.php/mentors');
?>">Mentors</a></li>
    
    
            
          </ul>
        </div><!--/.nav-collapse -->
      </div>
	</div>
	</div>
