<section id="service-info">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-12 col-md-12">
                    <h3 class="clr-main"><strong>OUR SERVICE LIST </strong></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
                    <br />
                    <br />
                </div>
            </div>
            <div class="row pad-top-botm">
                <div class="col-lg-4 col-md-4">
                    <div class="media">
                        <div class="pull-left">
                            <i class=" fa fa-folder-open-o fa-4x rotate-icon "></i>

                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Easy To code</h3>
                            <p>
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc. 
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="media">
                        <div class="pull-left">
                            <i class="fa fa-power-off fa-4x rotate-icon "></i>
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Best To Use</h3>
                            <p>
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc. 
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                            </p>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="media">
                        <div class="pull-left">
                            <i class="fa fa-paper-plane-o fa-4x rotate-icon "></i>
                        </div>
                        <div class="media-body">
                            <h3 class="media-heading">Customize Friendly</h3>
                            <p>
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc. 
                                Aenean faucibus luctus enim. Duis quis sem risu suspend lacinia elementum nunc.
                            </p>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row pad-top-botm ">
                <div class="col-lg-6 col-md-6">
                    <div class="alert alert-info transparent-bk upfront-trans">
                        <i class="fa fa-edit fa-2x "></i>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      
                    </div>

                    <hr />
                    <iframe src="http://player.vimeo.com/video/18312392" class="vedio-style"></iframe>
                </div>

                <div class="col-lg-6 col-md-6">
                    <div class="col-lg-6 col-md-6">

                        <div class="alert alert-success transparent-bk upfront-trans">
                            <i class="fa fa-folder-open-o fa-2x"></i>Lorem ipsum dolor sit amet.
                              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                             Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                             Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        </div>
                                              

                    </div>
                    <div class="col-lg-6 col-md-6">

                        <iframe src="http://www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fenvato&amp;width=235&amp;height=258&amp;colorscheme=light&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=false&amp;appId=438889712801266" style="border: none; overflow: hidden; width: 235px; height: 258px;"></iframe>

                    </div>
                    <div class="col-lg-12 col-md-12">
                        <div class="alert alert-info transparent-bk upfront-trans">
                            <i class="fa fa-info fa-2x "></i><b>JUST A  SMALL INFORMATION :  </b>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                              
                               Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.

                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>