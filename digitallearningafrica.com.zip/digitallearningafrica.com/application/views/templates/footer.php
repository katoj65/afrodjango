














</div>
<div class="just-stats">
        <div class="container">
            <div class="row ">
                <div class="col-lg-3 col-md-3 ">
                    <div class="stats-div">
                        <i class="fa fa-rocket fa-5x"></i>
                        <h3>3000+</h3>
                        <h4>Courses</h4>
                    </div>
                </div>




 <div class="col-lg-3 col-md-3 ">

                    <div class="stats-div">
                        <i class="fa fa-building fa-5x"></i>
                        <h3>250 +</h3>
                        <h4>Training Sessions</h4>
                    </div>
                </div>





                <div class="col-lg-3 col-md-3 ">
                    <div class="stats-div">
                        <i class="fa fa-globe fa-5x"></i>
                        <h3>149+</h3>
                        <h4>Trainees</h4>
                    </div>

                </div>
               
                <div class="col-lg-3 col-md-3 ">
                    <div class="stats-div">
                        <i class="fa fa-comments-o fa-5x"></i>
                        <h3>1305+</h3>
                        <h4>Mentors /  trainers</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    
    <!--./ stats div end -->
      <div id="media-sec">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12" >
                    <div class="text-center">
                        <h3>WHAT MEDIA SAY'S ABOUT US</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
                        <br />
                        <br />
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <blockquote>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
                        <small>Consectetur adipiscing elit</small>
                    </blockquote>

                </div>
                <div class="col-lg-6 col-md-6">
                    <blockquote>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit onec molestie non sem vel condimentum. </p>
                        <small>Consectetur adipiscing elit</small>
                    </blockquote>

                </div>
            </div>

        </div>

    </div>
    <!--./ Media Section End -->
   <div id="footer-sec">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4" id="about-ftr">
                    <i class="fa fa-building fa-2x"></i>
                    <span>About us</span>
                  <small>Learn more about what we are doing in Africa</small>
                    <p>
                    <?php
	
                    echo ucfirst($about->content);
                    
                    ?>
                    </p>
                </div>
                <div class="col-lg-4 col-md-4">
                    <i class="fa fa-paper-plane-o fa-2x"></i>
                    <span>Partners</span>
                    <small>Promoting python programming language in partnership with:</small>
                    <div id="blog-footer-div">
                     <?php
                     if($partners->num_rows()>0){
                     echo('<ul>');
                     foreach($partners->result() as $partner_row){
                     echo('<li>'.ucwords($partner_row->name).'</li>');   
                     }   
                        
                        
                     echo('</ul>');
             
                     }else{
                     echo('No partners found');
                     }
                        
                        
                        
                        
                        
                        ?>   
                       
                       
                       
                    </div>
                </div>

                <div class="col-lg-4 col-md-4">
                    <i class="fa fa-sliders fa-2x"></i>
                    <span>Find us</span>
                    <small>Our locations in Africa</small>
                    234/90, Newyork Street , USA
                    <br />
                    Call: 456-0980-0000
                     <br />
                    mail: info@domain.com
                    <br />
                    <br />
                    
                    
                    
                    
                    <form role="form">
                    <div class="input-group">
                            <input type="text" class="form-control" autocomplete="off" placeholder="Enter your email" required />
                            <span class="input-group-btn">
                                <button class="btn btn-primary" type="button">Subdcribe!</button>
                            </span>
                        </div>
                    </form>
                
                
                
                
                
                
                
                
                </div>
            </div>
        </div>
         </div>
    <!--./ footer-sec  End -->
    <div id="footser-end">
        <div class="container">

            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <?php
	echo date('Y');
?> All Rights Reserved | by: <a href="http://binarytheme.com" target="_blank" style="color:#fff" ><?php
echo ucfirst($dev->content);
?></a>
                    
                </div>
            </div>

        </div>
    </div>
    <!--./ footer-end End -->
    <!--  Jquery Core Script -->
    <script src="<?php
	echo base_url('assets/js/jquery-1.10.2.js');
?>"></script>
    <!--  Core Bootstrap Script -->
    <script src="<?php
	echo base_url('assets/js/bootstrap.js');
?>"></script>
        <!--  Custom Scripts -->
    <script src="<?php
	echo base_url('assets/js/custom.js');
?>"></script>
   
</body>
</html>
