  
                    <?php
	echo form_open();
?>
                    <div class="input-group">
                            <input type="text" class="form-control" autocomplete="off" 
                            placeholder="Enter subject...." required />
                            <span class="input-group-btn">
                                <button class="btn btn-primary" type="submit">Search</button>
                            </span>
                        </div>
                    </form>
                