<style type="text/css">
<!--
#student_menu ul li{
float: left;
margin-right: 20px;
list-style: none;
}

#student_menu ul li a{
font-size: 14px;
padding: 5px;
}








	
-->
</style>


<?php
if($user->num_rows()==1){
foreach($user->result() as $user_row);
}
?>



<div id="student_menu">
<ul>
<li><a href="<?php
echo base_url();
?>"> Courses
</a></li>


<li><a href="<?php
echo base_url('index.php/'.$user_row->role.'/topics');
?>"> Topics offered
<?php
if($approvals->num_rows()>0){
echo(' ('.$approvals->num_rows().')');
}
?>

</a></li>




<li><a href="<?php
	echo(base_url('index.php/'.$user_row->role.'/virtual/classroom'));
?>">Virtual classroom</a></li>
<li><a href="<?php
	echo(base_url('index.php/'.$user_row->role.'/reference'));
?>"> Reference material</a></li>
<li><a href="<?php
	echo(base_url('index.php/'.$user_row->role.'/assignments'));
?>"> Assessments</a></li>
<li><a href="<?php
	echo(base_url('index.php/'.$user_row->role.'/schedule'));
?>"> Schedules</a></li>
<li><a href="<?php
	echo(base_url('index.php/'.$user_row->role.'/events'));
?>">Events</a></li>



<li><a href="<?php
	echo(base_url('index.php/'.$user_row->role.'/discussions'));
?>">Discussions</a></li>

</ul>
</div>











