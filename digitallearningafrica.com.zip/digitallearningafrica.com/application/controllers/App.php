<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class App extends CI_Controller {

function __construct(){
parent::__construct();
$this->load->helper('url'); 
$this->load->helper('form','Control');
$this->load->library('form_validation');  
$this->load->library(array('session')); 
$this->load->helper(array('text','date'));
}







function file_upload($upload_field){
if(isset($upload_field)){
$config['upload_path']='images/';
$config['file_name']=md5($_SESSION['ID'].date('ymdsih'));
$config['allowed_types']="gif|jpg|png|mpeg|mp3|mov|flv|mp4";
$config['max_size']=1000;
$this->load->library('upload',$config);
if($this->upload->do_upload($upload_field)){
$image=$this->upload->data();
$file=$config['upload_path'].$image['file_name'];    
}else{
$file='';
}
return $file;    
}
}










public function my_calendar(){   
$this->load->model('Events_model');
$this->load->model('Virtual_class_room_model');
$this->load->model('Login_model');
$user=$this->Login_model->user_info();

if($this->session->ID!=""){
if($user->num_rows()==1){
foreach($user->result() as $row);
}
}

/**
 * Event status build up.
 */
$ongoing=$this->Events_model->get_ongoing_events();
$upcoming=$this->Events_model->get_upcoming_events();
$future=$this->Events_model->get_future_events();

if($ongoing->num_rows()>0){
$status=$ongoing->num_rows();    
}else{
if($upcoming->num_rows()>0){
$status=$future->num_rows();    
}else{
if($future->num_rows()>0){
$status=$future->num_rows();    
}
}
}

echo('<style type="text/css">
<!--
.calendar tr td{
padding:10px;
}
.calendar tr th{
padding:10px;
background:#565AB1;
color:white;
}
-->
</style>');


if($this->session->ID!=""){
$status=$future->num_rows();
$links='<div style="padding:10px;text-align:left;padding-left:30%;">
<span style="padding:5px;background:#565AB1;color:white;" class="border_radius">
<a href="'.base_url('index.php/'.$row->role.'/events').'" style="color:white;">'.$status.' events</a>
</span></div>';
}else{
$links='Events';
}


$prefs['template'] = '
{table_open}<table border="5"  style="width:80%;border:solid thin #E4E4E4;margin:0;padding:10px;margin-left:10%;margin-right:10%;" cellspacing="5" cellpading="5" class="calendar">
{/table_open}
{heading_row_start}<tr>{/heading_row_start}
{heading_previous_cell}<th><a href="{previous_url}">&lt;&lt;</a></th>{/heading_previous_cell}
{heading_title_cell}<th colspan="{colspan}">{heading}</th>{/heading_title_cell}
{heading_next_cell}<th><a href="{next_url}">&gt;&gt;</a></th>{/heading_next_cell}
{heading_row_end}</tr>{/heading_row_end}
{week_row_start}<tr>{/week_row_start}
{week_day_cell}<td>{week_day}</td>{/week_day_cell}
{week_row_end}</tr>{/week_row_end}

{cal_row_start}<tr>{/cal_row_start}
{cal_cell_start}<td>{/cal_cell_start}
{cal_cell_start_today}<td>{/cal_cell_start_today}
{cal_cell_start_other}<td class="other-month">{/cal_cell_start_other}
{cal_cell_content}<a href="{content}">{day}</a>{/cal_cell_content}
{cal_cell_content_today}<div class="highlight"><a href="{content}">{day}</a></div>{/cal_cell_content_today}
{cal_cell_no_content}{day}{/cal_cell_no_content}
{cal_cell_no_content_today}<div class="highlight">{day}</div>{/cal_cell_no_content_today}
{cal_cell_blank}&nbsp;{/cal_cell_blank}
{cal_cell_other}{day}{/cal_cel_other}
{cal_cell_end}</td>{/cal_cell_end}
{cal_cell_end_today}</td>{/cal_cell_end_today}
{cal_cell_end_other}</td>{/cal_cell_end_other}
{cal_row_end}</tr>{/cal_row_end}
{table_close}</table>{/table_close}
';
$this->load->library('calendar', $prefs);
return '<div style="text-align:center;">'.(highlight_phrase($this->calendar->generate(),date('d')).$links).'</div>';
}












/**
 * index page
 */
public function index(){
$data['page']='index';
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->get_courses();     
       
    
if(isset($this->session->ID)){
$this->load->model('Login_model');


/**
 * logged in user details
 */
$user=$this->Login_model->user_info();
if($user->num_rows()==1){
foreach($user->result() as $row);
$data['user']=$row;    
$role=$row->role;
if(isset($role)){
/**
 *Login user by role. 
*/    

if($role=='student'){
redirect(base_url('index.php/student'));
}elseif($role=='admin'){
redirect(base_url('index.php/admin'));    
}elseif($role=='trainer'){
redirect(base_url('index.php/trainer'));    
}else{
redirect(base_url());
}
}
}    
}else{
 

$data['heading']='Welcome to Digital Learning Environment Africa';
$data['description']='Start your new career in Web, Software Development or Internet Of Things';
$data['attributes']='Become a full-stack developer';
$data['note']='Here is the notification title';
$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['count_course']=$this->Course_model->all_courses()->num_rows(); 
/**
 * sections for footer.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 



/**
 * Section for index.
 */
$data['mentors']=$this->Section_model->section('mentors'); 
$data['sessions']=$this->Section_model->section('sessions');
$data['how']=$this->Section_model->section('how'); 
$data['trainners']=$this->Section_model->section('trainners');
$data['address']=$this->Section_model->section('address');   
$data['mentors']=$this->Section_model->section('mentors');
$data['literacy']=$this->Section_model->section('literacy'); 
  
  
$this->load->view('templates/header',$data); 
$this->load->view('templates/contact_bar',$data);     
$this->load->view('templates/banner',$data);    
$this->load->view('templates/welcome_bar',$data);
$this->load->view('templates/course_categories',$data);
$this->load->view('templates/notification_bar',$data);
//$this->load->view('pages/course_list',$data);    
$this->load->view('templates/footer',$data); 
 
   
}    
}






/**
 * students account
 */
public function student_account(){
$data['page']='student';
if($this->session->ID!=""){
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$this->load->model('Events_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category(); 

$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['latest_event']=$this->Events_model->get_all_upcoming_events();


$data['user']=$this->Login_model->logged_in_user($this->session->ID); 
$user=$data['user'];

if($user->num_rows()==1){
    
foreach($user->result() as $row);
$course_details=$this->Course_model->user_course_details($row->interests);
$data['selected_course']=$row->interests;
if($course_details->num_rows()==1){
foreach($course_details->result() as $course);
$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='some content for the description';
$data['attributes']=$course->description;
$data['note']='Here is the notification title';
$data['course_list']=$this->Course_model->course_categories($row->interests);
$data['enroll']=$this->Course_model->course_enrollment_check($row->interests);
$data['count_course']=$this->Course_model->count_courses($row->interests);
/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 
$enroll=$data['enroll'];
if($enroll==1){
$data['enrollment_info']=$this->Course_model->course_enrollment_info($row->interests);    
/**
* Extract user reading material.
*/
$data['course_first']=$this->Course_model->get_first_lesson($row->interests);
$course_first=$data['course_first'];
if($course_first->num_rows()==1){
foreach($course_first->result() as $first);
$data['course']=$first;
$data['topics']=$this->Course_model->get_course_list($row->interests);
$this->load->model('Virtual_class_room_model');
$data['vc']=$this->Virtual_class_room_model->class_room_notification($row->interests);

/**
*get lessons for the course. 
*/
$this->load->model('Lesson_model');    
$data['lessons']=$this->Lesson_model->get_lessons($first->ID);    
}
}


}
}    
    

$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data);

if($enroll==1){
/**
* check for the log.  
*/    
$reading_log=$this->Course_model->course_reading_log();
if($reading_log->num_rows()==1){
foreach($reading_log->result() as $log);
$data['course_first']=$this->Course_model->get_lessonByID($log->courseID);
$data['topics']=$this->Course_model->get_course_list($row->interests);
$data['lessons']=$this->Lesson_model->get_lessons($log->courseID);

/**
* segment build up.
*/

if($this->uri->segment(2)!=""){
$this->home_page_menus($data);
}else{
$this->load->view('pages/student_study_course_log',$data); 
}
}else{

/**
* segment build up.
*/

if($this->uri->segment(2)!=""){
$this->home_page_menus($data);
}else{
$this->load->view('pages/student_study_course',$data);     
}
}
}elseif($enroll==0){
$data['topics']=$this->Course_model->get_course_list($row->interests);
$this->load->view('pages/student_account',$data);   

}



/**
 * search
 */
$this->form_validation->set_rules('searching','search','required');
if($this->form_validation->run()==FALSE){
}else{
    
}



$this->load->view('templates/footer',$data);    
}else{
redirect(base_url('index.php'));
}     
}


















/**
 * search functionality view.
 */
public function search_functionality_view(){
$data['page']='search';
if($this->session->ID!=""){
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category(); 

$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['user']=$this->Login_model->logged_in_user($this->session->ID); 
$user=$data['user'];

if($user->num_rows()==1){
    
foreach($user->result() as $row);
$course_details=$this->Course_model->user_course_details($row->interests);

if($course_details->num_rows()==1){
foreach($course_details->result() as $course);
$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='some content for the description';
$data['attributes']=$course->description;
$data['note']='Here is the notification title';
$data['course_list']=$this->Course_model->course_categories($row->interests);
$data['enroll']=$this->Course_model->course_enrollment_check($row->interests);
$data['count_course']=$this->Course_model->count_courses($row->interests);
/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 
$enroll=$data['enroll'];
if($enroll==1){
$data['enrollment_info']=$this->Course_model->course_enrollment_info($row->interests);    
/**
* Extract user reading material.
*/
$data['course_first']=$this->Course_model->get_first_lesson($row->interests);
$course_first=$data['course_first'];
if($course_first->num_rows()==1){
foreach($course_first->result() as $first);
$data['course']=$first;
$data['topics']=$this->Course_model->get_course_list($row->interests);

/**
*get lessons for the course. 
*/
$this->load->model('Lesson_model');    
$data['lessons']=$this->Lesson_model->get_lessons($first->ID);    
}
}
}
}    
    

$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data);





if($enroll==1){
/**
* check for the log.  
*/    
$reading_log=$this->Course_model->course_reading_log();

if($reading_log->num_rows()==1){
foreach($reading_log->result() as $log);

$data['course_first']=$this->Course_model->get_lessonByID($log->courseID);
$data['topics']=$this->Course_model->get_course_list($row->interests);
$data['lessons']=$this->Lesson_model->get_lessons($log->courseID);

/**
* segment build up.
*/
if($this->uri->segment(2)!=""){
$this->home_page_menus($data);
}else{
$this->load->view('pages/student_study_course_log',$data); 
}


}
}






$this->load->view('templates/footer',$data);    
}else{
redirect(base_url('index.php'));
}     
}






























/**
 * homepage menu.
 */
private function home_page_menus($data){
if($this->uri->segment(2)!=""){
/**
 * faq segment.
 */
if($this->uri->segment(2)=='faq'){
    
$this->load->model('FAQ_model');
$data['faq']=$this->FAQ_model->get_course_questions($data['course_load']->ID);
$this->form_validation->set_rules('question','question','required');
if($this->form_validation->run()==FALSE){}else{
$content=array('contentID'=>$data['course_load']->ID,'question'=>$this->input->post('question'),'tag'=>'course','status'=>'new','author'=>$this->session->ID);
$this->FAQ_model->insert_faq($content);
$this->session->set_flashdata('message','Your question has been submitted');
redirect(base_url('index.php/student/faq'));
}

$this->load->view('pages/external_content/faq_page',$data);



/**
 * Assignments segment.
 */

}elseif($this->uri->segment(2)=='assignments'){

$data['description']='Browse a number of course assignments available.';
$this->load->model('Assignment_model');
$data['assignments']=$this->Assignment_model->get_course_assignments($data['course_load']->ID);
$this->load->view('pages/external_content/exercises',$data);    



/**
 * Reference segment.
 */

}elseif($this->uri->segment(2)=='reference'){

$this->load->view('pages/external_content/reference_material',$data);    


/**
 * Discussion segment.
 */

}elseif($this->uri->segment(2)=='discussion'){

$data['description']='Join the discussions, ask questions, write comments and find answers';
$this->load->model('Discussion_model');
$data['discussion']=$this->Discussion_model->get_lesson_discussion($data['selected_course']);
$this->form_validation->set_rules('discuss','discussion','required');
/**
 * discussion form
 */

if($this->form_validation->run()==FALSE){}else{
$insert=array('contentID'=>$data['selected_course'],'userID'=>$this->session->ID,'content'=>$this->input->post('discuss'),'tag'=>'course');
$this->Discussion_model->insert_discussion($insert); 
$this->session->set_flashdata('submitted','<div class="success">Your message has been posted</span>');      
redirect(base_url('index.php/student/discussion'));
}



$this->load->view('pages/external_content/discussions',$data);    
    

/**
 * Illustration segment.
 */






}elseif($this->uri->segment(2)=='illustration'){

$data['description']='';
$this->load->model('Lesson_model');
$data['lesson_content']=$this->Lesson_model->get_lesson_contentByID($this->uri->segment(3));
$this->load->view('pages/external_content/topic_illustration',$data);     



/**
 * Tutorial segment.
 */

}elseif($this->uri->segment(2)=='tutorials'){
$this->load->model('Tutorial_model');

$data['couse_tutorials']=$this->Tutorial_model->get_course_tutorials($data['course']->ID);

$this->load->view('pages/external_content/tutorials',$data);
    

/**
 * Consultant segment.
 */
 
}elseif($this->uri->segment(2)=='consultants'){
    
if($this->uri->segment(3)!=""){
    
$data['course_infomation']=$this->Course_model->get_course_categoryByID($this->uri->segment(3));

$this->load->view('pages/course_consultants_page',$data); 
}else{
$this->load->view('pages/external_content/consultants',$data);    
}


}elseif($this->uri->segment(2)=='calendar'){

/**
 * study calendar
*/    

$data['description']='Browse through your activities on the academic calendar.';  
  
$this->load->view('pages/external_content/study_calendar',$data);     
    
}elseif($this->uri->segment(2)=='examples'){

/**
 * examples
 */
$data['description']='Learn as you follow a number of hands on practical guides on different topics.'; 
$this->load->view('pages/external_content/examples',$data);




}elseif($this->uri->segment(2)=='events'){
/**
 * student_events
 */    
$this->load->model('Events_model');
$data['description']='Join the boot camp and learn from your instructors and trainers.';
$data['get_events']=$this->Events_model->get_all_upcoming_events();


$this->load->view('pages/external_content/student_events',$data);

}elseif($this->uri->segment(2)=='groups'){

/**
*student groups 
*/    
    
$this->load->view('pages/external_content/student_groups',$data);


}elseif($this->uri->segment(2)=='overview'){


$this->load->view('pages/student_study_course_log',$data);


}elseif($this->uri->segment(2)=='bootcamp'){

$this->load->view('pages/student_bootcamp',$data);

}

    
}else{
return redirect(base_url('index.php/student'));
}
}























public function all_courses(){
$data['page']="index";
if(isset($this->session->ID)){
$this->load->model('Login_model');
$user=$this->Login_model->user_info();
if($user->num_rows()==1){
foreach($user->result() as $row);
$data['user']=$row;
 
}
}

$this->load->model('Course_model');
$data['courses']=$this->Course_model->all_courses();
$data['enrollment']=$this->Course_model->enrolled_courses();

$this->load->view('templates/header',$data);

if(isset($this->session->ID)){
$data['heading']='<h3><span class="title">'.$data['courses']->num_rows().' Courses available</span></h3>';
$data['description']='Choose from the list course below. Become a developer, mentor, tutor etc.';
$data['attributes']='View your courses';
$this->load->view('templates/page_banner',$data);
}else{
$this->load->view('pages/banner',$data);
$this->load->view('pages/banner_lower',$data);
}

$this->load->view('pages/view_all_courses',$data);
$this->load->view('templates/footer',$data);    
}
















public function register(){
$data['page']='register';
$this->load->model('Login_model');
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['timezone']=date('D, d - M - Y');
//$data['nation']='Uganda';
$data['country']=$this->Login_model->country();



$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 



$data['heading']='Create new account';
$data['description']='Login in to your account to access a variety of courses and subjects, interact with mentors, teachers and instructors.';
$data['attributes']='We encourage personalized learning and academic content shring among learners.';
 
$this->form_validation->set_rules('fname','first name','required');
$this->form_validation->set_rules('lname','last name','required');
$this->form_validation->set_rules('gender','gender','required');
$this->form_validation->set_rules('dob','date of birth','required');
$this->form_validation->set_rules('role','role','required');
$this->form_validation->set_rules('country','country','required');
$this->form_validation->set_rules('tel','telephone','required');
$this->form_validation->set_rules('password','password','required');
$this->form_validation->set_rules('email','email address','required');
if($this->form_validation->run()==FALSE){}else{

$pass=$this->input->post('password');

if(strlen($pass)>=6){

$array=array('fname'=>$this->input->post('fname'),
'lname'=>$this->input->post('lname'),
'gender'=>$this->input->post('gender'),
'dob'=>nice_date($this->input->post('dob'),'Y-m-d'),
'role'=>$this->input->post('role'),
'country'=>$this->input->post('country'),
'email'=>$this->input->post('email'),
'tel'=>$this->input->post('tel'),
'password'=>md5($this->input->post('password')));

$this->load->model('Login_model');
$check=$this->Login_model->check($this->input->post('email'));

/**
 *email checking. 
 */

if($check==1){
$this->session->set_flashdata('message','<div class="error">E-mail address already exisits</div>');
}else{

/**
 * inserting content in to the database.
 */
$this->Login_model->register($array); 
$_SESSION['email']=$this->input->post('email');
redirect(base_url('index.php/complete/registration'));
}
}else{
$this->session->set_flashdata('pass_error','<div class="error">Password is too short</div>');
}
}





$this->load->view('templates/header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data);
//$this->load->view('templates/welcome_bar',$data);
$this->load->view('forms/register',$data);   
$this->load->view('templates/footer',$data);    
}















private function add_course($data){ 
if(isset($data)){

$this->form_validation->set_rules('title','course title','required');
$this->form_validation->set_rules('desc','course description','required');
$this->form_validation->set_rules('duration','course duration','required');
if($this->form_validation->run()==FALSE){
}else{

$this->load->model('Course_model');
$file=$this->file_upload('file');
$content=array('course_categoryID'=>$data['my_course']->ID,'name'=>$this->input->post('title'),'description'=>$this->input->post('desc'),'image'=>$file,'duration_days'=>$this->input->post('duration'),'author'=>$this->session->ID);
$this->Course_model->insert_course($content);
$_SESSION['course_content']=array($data['my_course']->ID,$this->input->post('title'),$this->input->post('desc'),$this->input->post('duration'));
$this->session->set_flashdata('lesson_added','<div class="success">Course has been added</div>');
redirect(base_url('index.php/course/add/lesson'));   
}




} 
}















public function login(){
if(isset($this->session->ID)){
return redirect(base_url());
}

$this->load->model('Login_model');
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';


$data['page']='login';
$data['heading']='LOGIN';
$data['description']='Login in to your account to access a variety of courses and subjects, interact with mentors, teachers and instructors.';
$data['attributes']='We encourage personalized learning and academic content shring among learners.';
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 

$this->form_validation->set_rules('username','username','required');
$this->form_validation->set_rules('password','password','required');
if($this->form_validation->run()==FALSE){
}else{
$login=$this->Login_model->login($this->input->post('username'),md5($this->input->post('password')));
if($login->num_rows()==0){
$this->session->set_flashdata('login_error','Invalid username or password');    
}elseif($login->num_rows()==1){
foreach($login->result() as $row);
$_SESSION['ID']=$row->ID;
redirect(base_url());
}    
}

$this->load->view('templates/header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data);
//$this->load->view('templates/welcome_bar',$data);
 
$this->load->view('forms/login',$data);   
$this->load->view('templates/footer',$data);     
}







/**
 * complete registration.
 */

public function complete_registration(){
if($this->session->email!=""){
$this->load->model('Login_model');
$data['page']='complete_registration';
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category(); 

$data['heading']='Complete registration';
$data['description']='some content for the description';
$data['attributes']='Create your user profile';
$data['note']='Here is the notification title';
$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();

$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 


$user=$data['user'];
if($user->num_rows()==1){
foreach($user->result() as $row);
$profile=$this->Login_model->get_user_profile($row->ID);
if($profile->num_rows()==0){

/**
 * submit the user profile
 */
$this->form_validation->set_rules('education','academic lavel','required');
$this->form_validation->set_rules('interest','course of interest','required');
$this->form_validation->set_rules('about','about','required');
if($this->form_validation->run()==FALSE){}else{
$insert=array('registrationID'=>$row->ID,'bio'=>$this->input->post('about'),'education'=>$this->input->post('education'),'interests'=>$this->input->post('interest'));
$this->Login_model->insert_about($insert);
$_SESSION['ID']=$row->ID;
redirect(base_url());
}

}else{
$this->session->set_flashdata('message','<div class="error">User profile already exisits (<a href="'.base_url('index.php/complete/registration/edit').'">Edit profile</a>)</div>');
redirect(base_url('index.php'));
}







}



$this->load->view('templates/complete_register_header',$data);     
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data);
$this->load->view('pages/complete_registration',$data);
$this->load->view('templates/footer',$data); 

}else{
redirect(base_url());
}
}

















/**
 * logout functionality.
 */
public function logout(){
session_destroy();
redirect(base_url());
}






/**
 * add lesson to course.
 */
private function add_lesson($array){
if(isset($array)){
$this->load->model('Course_model');
$this->load->model('Lesson_model');
$course=$this->Course_model->get_recent_added_lesson($array);
if($course->num_rows()==1){
foreach($course->result() as $row);
$courseID=$row->ID;    
$this->form_validation->set_rules('title','title','required');
$this->form_validation->set_rules('desc','description','required');
if($this->form_validation->run()==FALSE){
}else{

$upload=$this->file_upload('file');
$data=array('courseID'=>$courseID,'title'=>$this->input->post('title'),'description'=>$this->input->post('desc'),'file'=>$upload,'author'=>$this->session->ID);
$this->Lesson_model->insert_lesson($data);
$this->session->set_flashdata('lesson_success','<div class="success">Lesson has been added</div>');    
redirect(base_url('index.php/courses/add/lesson'));

}
}
}
}






public function new_course_lessons(){
user_session_check();
$data['page']='course_new';
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['course_info']=$this->Section_model->section('courses');    
    
    
if(isset($this->session->ID)){
$this->load->model('Login_model');

/**
 * logged in user details
 */

$user=$this->Login_model->user_info();
if($user->num_rows()==1){
foreach($user->result() as $row);
$data['user']=$row;

/**
 * logged in user profile information.
 */

$data['user_profile']=$this->Login_model->get_course_category($this->session->ID);
$profile=$data['user_profile'];
if($profile->num_rows()==1){
foreach($profile->result() as $user_profile);
$data['my_course']=$user_profile;
$this->load->model('Course_model');
$data['user_courses']=$this->Course_model->course_categories($user_profile->interests);
$data['enrollment']=$this->Course_model->enrolled_courses();
$data['count_courses']=$this->Course_model->count_courses($user_profile->interests);
$data['new']=$this->Course_model->get_new_course();
$data['no_lessons']=$this->Course_model->course_no_lesson($user_profile->interests);

/**
 * new couse details
 */
  
 
if($data['new']->num_rows()==1){
foreach($data['new']->result() as $new_course);
$data['new_course']=$new_course;    
$this->add_course_content($data);
$this->load->model('Lesson_model');
$data['lessons']=$this->Lesson_model->get_course_lesson($new_course->ID);
}




}
} 


$data['heading']='Add lesson';
$data['description']='some content for the description';
$data['attributes']='Add new lesson to '.ucfirst($user_profile->name).' course';
$data['note']="Course contact information";

$this->load->view('templates/user_header',$data); 
$this->load->view('templates/contact_bar',$data);     
$this->load->view('pages/page_heading',$data); 
$this->load->view('pages/add_lesson',$data);
$this->load->view('templates/footer',$data); 
}
}








public function add_course_content($data){
if($data['page']=='course_new'){    
$lesson=$data['new_course'];
$lesson=$lesson->ID;
}else{
$lesson=$this->uri->segment(2);
}

$this->form_validation->set_rules('title','lesson title','required');
$this->form_validation->set_rules('desc','lesson description','required');
if($this->form_validation->run()==FALSE){}
else{
$file=$this->file_upload('file');

$content=array('courseID'=>$lesson,'title'=>$this->input->post('title'),'description'=>$this->input->post('desc'),'file'=>$file,'author'=>$this->session->ID);
$this->load->model('Lesson_model');
$this->Lesson_model->insert_lesson($content);
$_SESSION['new_lesson']=$content;
$this->session->set_flashdata('lesson_success','<div class="success">Lesson has been added to the course</div>');
redirect(base_url('index.php/add/lesson/content'));
}    
}












































public function new_lesson_content(){
user_session_check();
$data['page']='content_new';
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$this->load->model('Lesson_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['course_info']=$this->Section_model->section('courses');    
    
    
if(isset($this->session->ID)){
$this->load->model('Login_model');

/**
 * logged in user details
 */

$user=$this->Login_model->user_info();
if($user->num_rows()==1){
foreach($user->result() as $row);
$data['user']=$row;

/**
 * logged in user profile information.
 */

$data['user_profile']=$this->Login_model->get_course_category($this->session->ID);
$profile=$data['user_profile'];
if($profile->num_rows()==1){
foreach($profile->result() as $user_profile);
$data['my_course']=$user_profile;
$this->load->model('Course_model');
$data['user_courses']=$this->Course_model->course_categories($user_profile->interests);
$data['enrollment']=$this->Course_model->enrolled_courses();
$data['count_courses']=$this->Course_model->count_courses($user_profile->interests);
$data['new']=$this->Lesson_model->get_new_lesson_content();


/**
 * new couse details
 */
  
 
if($data['new']->num_rows()==1){
foreach($data['new']->result() as $new_lesson);
$data['new_lesson']=$new_lesson;    
$this->load->model('Lesson_model');
//$data['lessons']=$this->Lesson_model->get_course_lesson($new_course->ID);
$this->add_lesson_content_form($data);

}




}
} 


$data['heading']='Add lesson content';
$data['description']='some content for the description';
$data['attributes']='Add new content to the lesson';
$data['note']="Course contact information";

$this->load->view('templates/user_header',$data); 
$this->load->view('templates/contact_bar',$data);     
$this->load->view('pages/page_heading',$data); 
$this->load->view('pages/add_lesson_content',$data);
$this->load->view('templates/footer',$data); 
     
}
} 
 
 






























function course_load(){
$data['page']='course_load';
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$this->load->model('Lesson_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['course_info']=$this->Section_model->section('courses');
$data['course']=$this->Course_model->load_course($this->uri->segment(2));
$data['lessons']=$this->Lesson_model->get_course_lesson($this->uri->segment(2));


if(isset($this->session->ID)){
$this->load->model('Login_model');
/**
 * logged in user details
 */
$user=$this->Login_model->user_info();
if($user->num_rows()==1){
foreach($user->result() as $row);
$data['user']=$row;

/**
 * logged in user profile information.
 */
$data['user_profile']=$this->Login_model->get_course_category($this->session->ID);
$profile=$data['user_profile'];
if($profile->num_rows()==1){
foreach($profile->result() as $user_profile);
$data['my_course']=$user_profile;
$this->load->model('Course_model');
$data['user_courses']=$this->Course_model->course_categories($user_profile->interests);
$data['enrollment']=$this->Course_model->enrolled_courses();
$data['count_courses']=$this->Course_model->count_courses($user_profile->interests);
$data['enrollement']=$this->Course_model->check_enrollment();

if($row->role=='course' or $row->role=='teacher'){
$this->add_course_content($data);
}


}





} 







$data['heading']='<span style="font-size:20px;">'.$data['my_course']->name.' course</span>';
$data['description']='some content for the description';
$data['attributes']='You are required to cover all the '.$data['lessons']->num_rows().' lessons for the course.';
$data['note']="Course contact information";


$this->load->view('templates/user_header',$data); 
$this->load->view('templates/contact_bar',$data);     
$this->load->view('pages/page_heading',$data); 
$this->load->view('pages/course_page',$data);
//$this->load->view('templates/notification_bar',$data);
//$this->load->view('pages/system_functions',$data);

$this->load->view('templates/footer',$data); 
     
     
     
     
     
     
     
     
                                   
}else{

$data['heading']='Welcome to Digital Learning Environment Africa';
$data['description']='some content for the description';
$data['attributes']='some content for  the attributes';
$data['note']='Here is the notification title';
$data['course']=$this->Course_model->get_courses();


$this->load->view('templates/header',$data); 
$this->load->view('templates/contact_bar',$data);     
$this->load->view('templates/banner',$data);    
$this->load->view('templates/welcome_bar',$data);
$this->load->view('templates/course_categories',$data);
$this->load->view('templates/notification_bar',$data);
$this->load->view('pages/course_list',$data);    
$this->load->view('templates/footer',$data);    
}


}


















public function course_enrollment(){
user_session_check();
$data['page']='course_enrollment';
if(isset($this->session->ID)){
$this->load->model('Login_model');
$this->load->model('Course_model');
$this->load->model('Lesson_model');
$user=$this->Login_model->user_info();
if($user->num_rows()==1){
foreach($user->result() as $row);
$data['user']=$row;
 ;

$data['user_profile']=$this->Login_model->get_course_category($this->session->ID);
$profile=$data['user_profile'];
if($profile->num_rows()==1){
foreach($profile->result() as $user_profile);
$data['my_course']=$user_profile;
}

$data['first_lesson']=$this->Lesson_model-> first_lesson($this->uri->segment(2));



}   


$data['course']=$this->Course_model->load_course($this->uri->segment(2));
$data['lessons']=$this->Lesson_model->get_course_lesson($this->uri->segment(2));
$data['other']=$this->Course_model->other_course();

$course=$data['course'];
if($course->num_rows()==1){
foreach($course->result() as $content);    
$enrollment=$data['enrollment']=$this->Course_model->course_enrollment();
if($enrollment->num_rows()==1){
foreach($enrollment->result() as $enroll);
$enroll_date='<div style="color:#FF4800;font-size:17px;"><strong>Enrolled on '.nice_date($enroll->date,'d M Y').'</strong></div>';

}else{
$enroll_date=FaLSE;
}
}


$data['enrolled_course']=$this->Course_model->enrolled_courses();
$data['calendar']=$this->my_calendar();
$data['heading']='<h3><span>You are enrolled for the course</span></h3>';
$data['description']='You can now access all reading material for this course including books, tutorials, video etc.';
$data['attributes']='Course duration is '.$content->duration_days.' days'.'<p>'.$enroll_date.'</p>';


$this->load->view('templates/course_header',$data);
//$this->load->view('templates/course_enrollment_banner',$data);  
$this->load->view('pages/course_enrollment');      
$this->load->view('templates/footer',$data);    
} 
}





public function enroll_course(){
user_session_check();
$this->load->model('Course_model');
$this->Course_model->enroll();
}




public function cancel_course_enroll(){
user_session_check();
$this->load->model('Course_model');
$this->Course_model->cancel_enroll();   
}




/**
 * add lesson assignment functionality.
 */
private function add_assignment($id){
if(isset($id)){
$this->form_validation->set_rules('title','title','required');
$this->form_validation->set_rules('description','description','required');
if($this->form_validation->run()==FALSE){
}else{
$this->load->model('Assignment_model'); 
$data=array('contentID'=>$id,'title'=>$this->input->post('title'),'description'=>$this->input->post('description'),'tag'=>'lesson','author'=>$this->session->ID);  
$this->Assignment_model->insert_lesson_assignment($data);
redirect(base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4).'/'.$this->uri->segment(5)));  
}    
}
}





private function attempt_assignment($id){
if(isset($id)){
$this->load->model('Assignment_model');
$data=array('lessonID'=>$this->uri->segment(2),'assignmentID'=>$this->uri->segment(6),'studentID'=>$this->session->ID,'marks'=>'','tag'=>'lesson');
$this->Assignment_model->insert_selected_assignment($data);
$this->session->flashdata('assignment_selected','<div class="success">You have selected assignment</div>');
redirect(base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/assignment'));
}
}








public function lesson_assignment(){
user_session_check();
$data['page']='lesson_assignment';
if(isset($this->session->ID)){
$this->load->model('Login_model');
$this->load->model('Course_model');
$this->load->model('Lesson_model');
$this->load->model('Discussion_model');
$this->load->model('Assignment_model');
$user=$this->Login_model->user_info();
if($user->num_rows()==1){
foreach($user->result() as $row);
$data['user']=$row;

$data['user_profile']=$this->Login_model->get_course_category($this->session->ID);
$profile=$data['user_profile'];
if($profile->num_rows()==1){
foreach($profile->result() as $user_profile);
$data['my_course']=$user_profile;
$data['attempted']=$this->Assignment_model->attempted_assignment('lesson');

}


/**
 * add lesson assignment. 
 */
if($row->role='admin'){
if($this->uri->segment(4)=='assignment'){
if($this->uri->segment(5)=='add'){
$this->add_assignment($this->uri->segment(2));    
}elseif($this->uri->segment(5)=='attempt'){
if($this->uri->segment(7)=='true'){    
$this->attempt_assignment($this->uri->segment(6));
}
}    




    
}    
}
}     

$data['assignments']=$this->Assignment_model->get_lesson_assignments($this->uri->segment(2));
$data['course']=$this->Course_model->load_course($this->uri->segment(3));
$this->Lesson_model->lesson_reading_log();
if($data['course']->num_rows()==1){
foreach($data['course']->result() as $content);    
$enrollment=$data['enrollment']=$this->Course_model->course_enrollment_info($this->uri->segment(3));
if($enrollment->num_rows()==1){
foreach($enrollment->result() as $enroll);
$enroll_date='<div><strong>Enrolled on: <em>'.nice_date($enroll->date,'d M Y').' ('.($enroll->status).')</em></strong></div>';

}else{
$enroll_date=FaLSE;
}
}



if($data['course']->num_rows()==1){
$data['heading']=ucfirst($content->name);
$data['description']=ucfirst(character_limiter($content->description,200)).$enroll_date;
$data['attributes']='<strong>Course duration is '.$content->duration_days.' days</strong>';
}elseif($data['course']->num_rows()==0){

redirect(base_url());
   
}



$data['calendar']=$this->my_calendar();    
$data['lesson']=$this->Lesson_model->load_course_lesson($this->uri->segment(2));
$data['other_lessons']=$this->Lesson_model->other_lessons($this->uri->segment(3));
$data['next_course_check']=$this->Lesson_model->check_next_course_lesson($this->uri->segment(2),$this->uri->segment(3));
$data['course_count']=$this->Lesson_model->count_course_lessons($this->uri->segment(3));
$data['enrolled_course']=$this->Course_model->enrolled_courses();
$data['lesson_content']=$this->Lesson_model->get_lesson_content($this->uri->segment(2));
$data['discussion']=$this->Discussion_model->get_lesson_discussion($this->uri->segment(2));




$this->load->view('templates/course_header',$data);
//$this->load->view('templates/course_enrollment_banner',$data);  
$this->load->view('pages/assignment');      
$this->load->view('templates/footer',$data);
}else{
redirect(base_url());
}
}





























public function course_lesson(){
user_session_check();

$data['page']='load_course';
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$this->load->model('Lesson_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['course_info']=$this->Section_model->section('courses');
//$data['course']=$this->Course_model->load_course($this->uri->segment(2));
$data['lesson']=$this->Lesson_model->load_course_lesson($this->uri->segment(2));
$data['lessons']=$this->Lesson_model->get_course_lesson($this->uri->segment(2));
$data['lesson_content']=$this->Lesson_model->get_lesson_content($this->uri->segment(2));


if(isset($this->session->ID)){
$this->load->model('Login_model');
$user=$this->Login_model->user_info();
if($user->num_rows()==1){
foreach($user->result() as $row);
$data['user']=$row;

/**
 * logged in user profile information.
 */
$data['user_profile']=$this->Login_model->get_course_category($this->session->ID);
$profile=$data['user_profile'];
if($profile->num_rows()==1){
foreach($profile->result() as $user_profile);
$data['my_course']=$user_profile;
$this->load->model('Course_model');
$data['user_courses']=$this->Course_model->course_categories($user_profile->interests);
$data['enrollment']=$this->Course_model->enrolled_courses();
$data['count_courses']=$this->Course_model->count_courses($user_profile->interests);
$data['enrollement']=$this->Course_model->check_enrollment();
$data['reference']=$this->Lesson_model->get_refrence($this->uri->segment(2));


}







if($row->role=='teacher' or $row->role=='course'){
if($data['lesson']->num_rows()==1){
if($this->uri->segment(3)=='add'){    
if($this->uri->segment(4)=='content'){
$this->add_lesson_content_form($data);


} 
}elseif($this->uri->segment(3)=='ask'){
$data['tag']=$this->uri->segment(1);
$this->faq_form($data);    
}
}    
}



/**
 * Extract lesson content.
 */

if($data['lesson']->num_rows()==1){
foreach($data['lesson']->result() as $lesson);    
$data['related_lessons']=$this->Lesson_model->get_lessonsByTagID($lesson->courseID);

$this->Lesson_model->lesson_reading_log($lesson);


}




$link='
<ul style="display:inline-table;" class="menus">
<li><a href="'.base_url('index.php/courses/all').'" style="color:#FF604A;">'.$data['count_courses'].' Courses</a> </li>
<li><a href="'.base_url('index.php/lessons/all/'.$lesson->courseID).'" style="color:#FF604A;">'.$data['related_lessons']->num_rows().' Lessons</a></li>
<li><a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/consultants').'" style="color:#FF604A;"> Consultants</a></li>
<li><a href="'.base_url('index.php/lesson/'.$this->uri->segment(2).'/reference').'" style="color:#FF604A;">'.$data['reference']->num_rows().' Reference material</a></li>
</ul>
';




$data['heading']='<span style="font-size:20px;">'.$data['my_course']->name.' lesson</span>';
$data['description']='some content for the description';
$data['attributes']='Learning content for '.ucfirst($data['my_course']->name).' development '.$link;

$data['note']="Course contact information";

$this->load->view('templates/user_header',$data); 
$this->load->view('templates/contact_bar',$data);     
$this->load->view('pages/page_heading',$data); 
$this->load->view('pages/lesson_page',$data);
$this->load->view('templates/footer',$data); 
     
     
}

}
}


















































function lesson_discussion_form($tag){
if(isset($tag)){
$this->form_validation->set_rules('discuss','discussion','required');    
$this->load->model('Discussion_model');    
if($this->form_validation->run()==FALSE){
}else{
$data=array('contentID'=>$this->uri->segment(2),'userID'=>$this->session->ID,'content'=>$this->input->post('discuss'),'tag'=>'lesson');
$this->Discussion_model->insert_discussion($data);
redirect(base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/discussion'));
}    
}
}








function  faq_form($data){
if(isset($data)){
$this->load->model('Lesson_model');
$this->form_validation->set_rules('faq','question','required');
if($this->form_validation->run()==FALSE){
}else{
$data=array('contentID'=>$this->uri->segment(2),'question'=>$this->input->post('faq'),'tag'=>$data['tag'],'author'=>$this->session->ID);    
$this->Lesson_model->FAQ_lesson($data);
$this->session->set_flashdata('faq_success','<div class="success">Your question has been submitted</div>');
redirect(base_url('index.php/lesson/'.$this->uri->segment(2)));    
}    
}    
}











function add_lesson_tutorial_form(){
$this->load->model('Tutorial_model');
$this->form_validation->set_rules('title','title','required');
$this->form_validation->set_rules('content','content','required');
if($this->form_validation->run()==FALSE){
}else{
$config['upload_path']='images/';
$config['file_name']=md5($this->session->ID.date('ymdsim'));
$config['allowed_types']="gif|jpg|png|mpeg|mp3|mov|flv|mp4";
$config['max_size']=1000;
$this->load->library('upload',$config);
$this->upload->do_upload('file');
$image=$this->upload->data();

$content=array('lessonID'=>$this->uri->segment(2),'title'=>$this->input->post('title'),'description'=>$this->input->post('content'),'file'=>$config['upload_path'].$image['file_name'],'author'=>$this->session->ID);
$this->Tutorial_model->insert_tutorial($content);
$this->session->set_flashdata('tutorial_added','<div class="success">Tutorial has been added</div>');
redirect(base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/add/tutorial'));
}
}






function add_lesson_content_form($data){
if($data['page']=='content_new'){
$lessonID=$data['new_lesson']->ID;
}else{
$lessonID=$this->uri->segment(2);
}    
       
$this->form_validation->set_rules('title','title','required');
$this->form_validation->set_rules('content','content','required');
if($this->form_validation->run()==FALSE){}else{
$file=$this->file_upload('file');
$content=array('lessonID'=>$lessonID,'title'=>$this->input->post('title'),'description'=>$this->input->post('content'),'file'=>$file,'author'=>$this->session->ID);
$this->Lesson_model->insert_lesson_content($content);
$this->session->set_flashdata('content_added','<div class="success">Content has been added</div>');
if($data['page']=='content_new'){
redirect(base_url('index.php/lesson/'.$lessonID.'/add/content'));    
}else{
redirect(base_url('index.php/lesson/'.$lessonID.'/add/content'));
}
}
}








function add_reference_form(){
$this->form_validation->set_rules('title','reference title','required');
$this->form_validation->set_rules('url','URL reference','required');
if($this->form_validation->run()==FALSE){
}else{
$ref=array('itemID'=>$this->uri->segment(2),'title'=>$this->input->post('title'),'url'=>$this->input->post('url'),'author'=>$this->session->ID);
$this->Lesson_model->insert_reference($ref);
$this->session->set_flashdata('added_reference','<div class="success">Reference material has been added</div>');
redirect(base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/add/reference'));
}    
}


















public function user_course_lesson_log(){
user_session_check();
$data['page']='course_lesson';
if(isset($this->session->ID)){
$this->load->model('Login_model');
$this->load->model('Course_model');
$this->load->model('Lesson_model');
$user=$this->Login_model->user_info();
if($user->num_rows()==1){
foreach($user->result() as $row);
$data['user']=$row;
}     
$log=$this->Course_model-> course_reading_log();
if($log->num_rows()==1){
foreach($log->result() as $logs);
redirect(base_url('index.php/lesson/'.$logs->course_lessonID.'/'.$logs->courseID));    
}else{

}
}
}




function delete_lesson_content(){
$this->load->model('Lesson_model');
$this->Lesson_model->delete_lesson_content($this->uri->segment(5));
$this->session->set_flashdata('delete_lesson_content','<div class="success">Lesson content has been deleted</div>');
redirect(base_url('index.php/lesson/'.$this->uri->segment(2).'/'.$this->uri->segment(3)));    
}






function chat(){
if($this->session->ID!=""){
$this->form_validation->set_rules('chat','chat','required');
if($this->form_validation->run()==FALSE){}else{
}    

}    
}








/**
 * student enrollement.
 */
public function student_enrollment(){
if($this->session->ID!=""){
$id=$this->uri->segment(3);
if(isset($id)){

$this->load->model('Course_model');
$enroll=$this->Course_model->course_enrollment($id);

if($enroll->num_rows()==0){

$insert=array('itemID'=>$id,'userID'=>$this->session->ID,'tag'=>'course');
$this->Course_model->insert_enrollment($insert);    
redirect(base_url('index.php/student'));


}else{

}    
    

}else{

//redirect(base_url('index.php/student'));

}
}else{

//redirect(base_url('index.php/student'));

}
}



/**
 * create a reading log for the user.
 */
public function create_course_reading_log(){
$this->load->model('Course_model');
$id=$this->uri->segment(4);
if($id!=""){
$insert=array('courseID'=>$id,'userID'=>$this->session->ID);
$this->Course_model->insert_reading_log($insert);
redirect(base_url('index.php/student'));
}else{
redirect(base_url());
}
}






/**
 * Notification functilanlity.
 */
private function notification_functionality($data){
if(isset($data)){
/**
 * Note hierachy.
 */
$this->load->model('Virtual_class_room_model');




    
}else{
return false;    
}    
}







/**
 * List of all courses when the user wants them.
 */
public function list_all_courses(){
$data['page']='course_list';

if($this->session->ID!=""){
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category(); 

$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['user']=$this->Login_model->logged_in_user($this->session->ID); 
$user=$data['user'];

if($user->num_rows()==1){
    
foreach($user->result() as $row);
$course_details=$this->Course_model->user_course_details($row->interests);

if($course_details->num_rows()==1){
foreach($course_details->result() as $course);
$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='some content for the description';
$data['attributes']=$course->description;
$data['note']='Here is the notification title';
$data['course_list']=$this->Course_model->course_categories($row->interests);
$data['enroll']=$this->Course_model->course_enrollment_check($row->interests);
$data['count_course']=$this->Course_model->count_courses($row->interests);
/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 
$enroll=$data['enroll'];
if($enroll==1){
$data['enrollment_info']=$this->Course_model->course_enrollment_info($row->interests);    
/**
* Extract user reading material.
*/
$data['course_first']=$this->Course_model->get_first_lesson($row->interests);
$course_first=$data['course_first'];
if($course_first->num_rows()==1){
foreach($course_first->result() as $first);
$data['course']=$first;
$data['topics']=$this->Course_model->get_course_list($row->interests);
$data['course_categories']=$this->Course_model->study_category();
$data['courses']=$this->Course_model->get_course_n_category();
}
}
}
}    
    
$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data);

if($enroll==1){
/**
* check for the log.  
*/    
$reading_log=$this->Course_model->course_reading_log();

}else{
redirect(base_url());
}


$this->load->view('pages/course_list',$data);
$this->load->view('templates/footer',$data);    
}else{
redirect(base_url('index.php'));
}     
}




/**
 * Book store
 */

public function student_book_store(){
$data['page']='course_list';
if($this->session->ID!=""){
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category(); 

$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['user']=$this->Login_model->logged_in_user($this->session->ID); 
$user=$data['user'];

if($user->num_rows()==1){
    
foreach($user->result() as $row);
$course_details=$this->Course_model->user_course_details($row->interests);

if($course_details->num_rows()==1){
foreach($course_details->result() as $course);
$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='some content for the description';
$data['attributes']=$course->description;
$data['note']='Here is the notification title';
$data['course_list']=$this->Course_model->course_categories($row->interests);
$data['enroll']=$this->Course_model->course_enrollment_check($row->interests);
$data['count_course']=$this->Course_model->count_courses($row->interests);
/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 
$enroll=$data['enroll'];
if($enroll==1){
$data['enrollment_info']=$this->Course_model->course_enrollment_info($row->interests);    
/**
* Extract user reading material.
*/
$data['course_first']=$this->Course_model->get_first_lesson($row->interests);
$course_first=$data['course_first'];
if($course_first->num_rows()==1){
foreach($course_first->result() as $first);
$data['course']=$first;
$data['topics']=$this->Course_model->get_course_list($row->interests);
$data['course_categories']=$this->Course_model->study_category();
$data['courses']=$this->Course_model->get_course_n_category();
}
}
}
}    
    
$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
//$this->load->view('pages/page_heading',$data);

if($enroll==1){
/**
* check for the log.  
*/    




}else{
redirect(base_url());
}


$this->load->view('pages/student_book_store',$data);
$this->load->view('templates/footer',$data);    
}else{
redirect(base_url('index.php'));
}     
}









/**
 * course content at student view
 */

public function student_course_content(){
$data['page']='course_list';
if($this->session->ID!=""){
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category(); 

$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['user']=$this->Login_model->logged_in_user($this->session->ID); 
$user=$data['user'];

if($user->num_rows()==1){
    
foreach($user->result() as $row);
$course_details=$this->Course_model->user_course_details($row->interests);

if($course_details->num_rows()==1){
foreach($course_details->result() as $course);
$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='some content for the description';
$data['attributes']=$course->description;
$data['note']='Here is the notification title';
$data['course_list']=$this->Course_model->course_categories($row->interests);
$data['enroll']=$this->Course_model->course_enrollment_check($row->interests);
$data['count_course']=$this->Course_model->count_courses($row->interests);
/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 
$enroll=$data['enroll'];
if($enroll==1){
$data['enrollment_info']=$this->Course_model->course_enrollment_info($row->interests);    
/**
* Extract user reading material.
*/
$data['course_first']=$this->Course_model->get_first_lesson($row->interests);
$course_first=$data['course_first'];
if($course_first->num_rows()==1){
foreach($course_first->result() as $first);
$data['course']=$first;
$data['topics']=$this->Course_model->get_course_list($row->interests);
$data['course_categories']=$this->Course_model->study_category();
$data['courses']=$this->Course_model->get_course_n_category();
}
}
}
}    
    
$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data);

if($enroll==1){
/**
* check for the log.  
*/    
if($this->uri->segment(4)!=""){
$data['category']=$this->Course_model->get_course_categoryByID($this->uri->segment(4));
$data['lessons']=$this->Course_model->get_course_list($this->uri->segment(4));
$data['check_enrolled_course']=$this->Course_model->course_enrollment_info($this->uri->segment(4));

}


}else{

}

$this->load->view('pages/student_course_load_page',$data);
$this->load->view('templates/footer',$data);    
}else{
redirect(base_url('index.php'));
}     
}



/**
 *student presentation  
 */

public function student_course_presentation(){
$data['page']='course_list';
if($this->session->ID!=""){
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category(); 

$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['user']=$this->Login_model->logged_in_user($this->session->ID); 
$user=$data['user'];

if($user->num_rows()==1){
    
foreach($user->result() as $row);
$course_details=$this->Course_model->user_course_details($row->interests);

if($course_details->num_rows()==1){
foreach($course_details->result() as $course);
$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='some content for the description';
$data['attributes']=$course->description;
$data['note']='Here is the notification title';
$data['course_list']=$this->Course_model->course_categories($row->interests);
$data['enroll']=$this->Course_model->course_enrollment_check($row->interests);
$data['count_course']=$this->Course_model->count_courses($row->interests);
/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 
$enroll=$data['enroll'];
if($enroll==1){
$data['enrollment_info']=$this->Course_model->course_enrollment_info($row->interests);    
/**
* Extract user reading material.
*/
$data['course_first']=$this->Course_model->get_first_lesson($row->interests);
$course_first=$data['course_first'];
if($course_first->num_rows()==1){
foreach($course_first->result() as $first);
$data['course']=$first;
$data['topics']=$this->Course_model->get_course_list($row->interests);
$data['course_categories']=$this->Course_model->study_category();
$data['courses']=$this->Course_model->get_course_n_category();
$this->load->model('Lesson_model');
$data['lessons']=$this->Lesson_model->get_lessons($first->ID);
}
}
}
}    
    
$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data);

/**
 * load the presentation.
 */

if($enroll==1){
$this->load->model('Lesson_model');
$data['lesson_presentation']=$this->Lesson_model->get_student_presentation($this->uri->segment(4));

}else{
redirect(base_url());
}




$this->load->view('pages/student_course_presentation',$data);

$this->load->view('templates/footer',$data);    
}else{
redirect(base_url('index.php'));
}    
}


























/**
 * course content at student view
 */

public function student_virtual_classroom(){
$data['page']='virtual_classroom';
if($this->session->ID!=""){
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category(); 

$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['user']=$this->Login_model->logged_in_user($this->session->ID); 
$user=$data['user'];

if($user->num_rows()==1){
    
foreach($user->result() as $row);
$course_details=$this->Course_model->user_course_details($row->interests);

if($course_details->num_rows()==1){
foreach($course_details->result() as $course);
$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='Participate in real time classroom sessions conducted by our instructors and mentors.';
$data['attributes']=$course->description;
$data['note']='Here is the notification title';
$data['course_list']=$this->Course_model->course_categories($row->interests);
$data['enroll']=$this->Course_model->course_enrollment_check($row->interests);
$data['count_course']=$this->Course_model->count_courses($row->interests);
/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 
$enroll=$data['enroll'];
if($enroll==1){
$data['enrollment_info']=$this->Course_model->course_enrollment_info($row->interests);    
/**
* Extract user reading material.
*/
$data['course_first']=$this->Course_model->get_first_lesson($row->interests);
$course_first=$data['course_first'];
if($course_first->num_rows()==1){
foreach($course_first->result() as $first);
$data['course']=$first;
$data['topics']=$this->Course_model->get_course_list($row->interests);
$data['course_categories']=$this->Course_model->study_category();
$data['courses']=$this->Course_model->get_course_n_category();
}
}
}
}    
    
$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data);

if($enroll==1){
$this->load->model('Virtual_class_room_model');
$data['vc']=$this->Virtual_class_room_model->get_lesson($row->interests);
if($data['vc']->num_rows()==1){
foreach($data['vc']->result() as $vc);
$data['other']=$this->Virtual_class_room_model->get_other_lesson($row->interests,$vc->ID);
}
}else{
redirect(base_url());
}

if($this->uri->segment(4)!=""){
$data['vc_load']=$this->Virtual_class_room_model->get_sessionByID($this->uri->segment(4));    
$this->load->view('pages/virtual_classroom_load',$data);
}else{
$this->load->view('pages/virtual_classroom',$data);
}



$this->load->view('templates/footer',$data);    
}else{
redirect(base_url('index.php'));
}     
}


























   
    
/**
 *tutorials page. 
*/    
    
public function tutorials_page(){
$data['page']='course_list';
if($this->session->ID!=""){
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category(); 

$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['user']=$this->Login_model->logged_in_user($this->session->ID); 
$user=$data['user'];

if($user->num_rows()==1){
    
foreach($user->result() as $row);
$course_details=$this->Course_model->user_course_details($row->interests);

if($course_details->num_rows()==1){
foreach($course_details->result() as $course);
$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='some content for the description';
$data['attributes']=$course->description;
$data['note']='Here is the notification title';
$data['course_list']=$this->Course_model->course_categories($row->interests);
$data['enroll']=$this->Course_model->course_enrollment_check($row->interests);
$data['count_course']=$this->Course_model->count_courses($row->interests);
/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 
$enroll=$data['enroll'];
if($enroll==1){
$data['enrollment_info']=$this->Course_model->course_enrollment_info($row->interests);    
/**
* Extract user reading material.
*/
$data['course_first']=$this->Course_model->get_first_lesson($row->interests);
$course_first=$data['course_first'];
if($course_first->num_rows()==1){
foreach($course_first->result() as $first);
$data['course']=$first;
$data['topics']=$this->Course_model->get_course_list($row->interests);

$data['course_categories']=$this->Course_model->study_category();
$data['courses']=$this->Course_model->get_course_n_category();

    
}
}


}
}    
    

$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data);
if($enroll==1){
/**
* check for the log.  
*/
$this->load->model('Tutorial_model');    
$data['tutorial']=$this->Tutorial_model->load_tutorial_content($this->uri->segment(3));


}else{
redirect(base_url());
}

$this->load->view('pages/tutorial_page',$data);
$this->load->view('templates/footer',$data);    
}else{
redirect(base_url('index.php'));
}     
}    





/**
 * trainer account
 */

public function trainer_account(){
$data['page']='trainer_account';
if($this->session->ID!=""){    
    
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');

$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category();
$data['approvals']=$this->Course_model-> get_approved_applications();     

/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 

    
$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['user']=$this->Login_model->logged_in_user($this->session->ID); 

$user=$data['user'];    
    
if($user->num_rows()==1){
    
foreach($user->result() as $row);
if($row->role!="trainer"){
redirect(base_url());
}


$course_details=$this->Course_model->user_course_details($row->interests);
$data['selected_course']=$row->interests;
if($course_details->num_rows()==1){
foreach($course_details->result() as $course);


$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='Select course where you whant to offer training for '.strtolower($course->name).'.';
$data['attributes']=$course->description;
$data['note']='Here is the notification title';    
/**
  * load courses
  */ 
$data['topics']=$this->Course_model->get_course_list($row->interests); 
 
$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data); 
 
 
 
 
/**
 * Application for course trainer
 */
if($this->uri->segment(3)=='application'){
$this->form_validation->set_rules('course','course','required');
if($this->form_validation->run()==FALSE){}else{
    
$insert=array('courseID'=>$this->input->post('course'),'userID'=>$this->session->ID,'role'=>'trainer');

$check=$this->Course_model->get_course_aplication_status($this->input->post('course'));
if($check->num_rows()==0){
$this->Course_model->set_course_application($insert);
$this->session->set_flashdata('saved_application','You have applied for this couse');
redirect(base_url());
}else{
$this->session->flashdata('application','You have already applied for this couse');
}

}    


$this->load->view('dialog/trainer_course_application',$data);
}



 
 
$this->load->view('pages/trainer_home_page',$data);
$this->load->view('templates/footer',$data);     

}

}else{
redirect(base_url());
}    

}else{
redirect(base_url());
}    
}





/**
 * trainer course load
 */

public function trainer_course(){
$data['page']='trainer_account';
if($this->session->ID!=""){    
    
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category();  
$data['approvals']=$this->Course_model-> get_approved_applications();   

/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors');     
$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['user']=$this->Login_model->logged_in_user($this->session->ID); 
$user=$data['user'];    
    
if($user->num_rows()==1){
    
foreach($user->result() as $row);
if($row->role!="trainer"){
redirect(base_url());
}else{
$data['trainer']=$row;
}

$course_details=$this->Course_model->user_course_details($row->interests);
$data['selected_course']=$row->interests;
if($course_details->num_rows()==1){
foreach($course_details->result() as $course);


$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='Select course where you whant to offer training for '.strtolower($course->name);
$data['attributes']=$course->description;
$data['note']='Here is the notification title';    
/**
  * load courses
  */ 
$data['topics']=$this->Course_model->get_course_list($row->interests); 
 
$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data); 
 
 
 
if($this->uri->segment(3)){ 

$this->load->model('Lesson_model');    
$data['topic_load']=$this->Course_model->get_trainer_course_load($this->uri->segment(3),$course->ID);
$data['lessons']=$this->Lesson_model->get_lessons($this->uri->segment(3));
$data['application']=$this->Course_model->get_course_aplication_status($this->uri->segment(3));

$this->load->view('pages/trainer_course_load',$data);
  
}

$this->load->view('templates/footer',$data);     

}

}else{
redirect(base_url());
}    

}else{
redirect(base_url());
}    
}










/**
 * trainer course load
 */

public function trainer_course_content(){
$data['page']='trainer_account';
if($this->session->ID!=""){    
    
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category();  
$data['approvals']=$this->Course_model-> get_approved_applications();   

/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors');     
$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['user']=$this->Login_model->logged_in_user($this->session->ID); 
$user=$data['user'];    
    
if($user->num_rows()==1){
    
foreach($user->result() as $row);
if($row->role!="trainer"){
redirect(base_url());
}else{
$data['trainer']=$row;
}

$course_details=$this->Course_model->user_course_details($row->interests);
$data['selected_course']=$row->interests;
if($course_details->num_rows()==1){
foreach($course_details->result() as $course);

$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='Select course where you whant to offer training for '.strtolower($course->name);
$data['attributes']=$course->description;
$data['note']='Here is the notification title';    
/**
  * load courses
  */ 

$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data); 
 
 
$data['topics']=$this->Course_model->get_course_list($row->interests); 

if($this->uri->segment(3)!=""){
$this->load->model('Lesson_model');
$data['lesson_load']=$this->Lesson_model->get_couse_lessonByID($this->uri->segment(4));
$data['lesson_content']=$this->Lesson_model->get_all_lesson_content($this->uri->segment(4));
$lesson=$data['lesson_load'];
if($lesson->num_rows()==1){
foreach($lesson->result() as $lesson_content);
$data['application']=$this->Course_model->get_course_aplication_status($lesson_content->ID);

}



/**
 * dialog for the trainer menu.
 */
if($this->uri->segment(5)=='add' and $this->uri->segment(6)!=""){
if($this->uri->segment(6)=='presentation'){
$this->load->view('dialog/trainer_presentation',$data);

}elseif($this->uri->segment(6)=='file'){
/**
 * file content upload.
 */
$this->form_validation->set_rules('title','file title','required');
$this->form_validation->set_rules('file','file upload','required');
if($this->form_validation->run()==FALSE){}else{

}
$this->load->view('dialog/trainer_upload_file',$data);    

}


    
}



$this->load->view('pages/trainer_course_topics',$data);

}else{
redirect(base_url());
} 



$this->load->view('templates/footer',$data);     
}
}else{
redirect(base_url());
}    
}else{
redirect(base_url());
}    
}































/**
 * trainer events
 */

public function trainer_events(){
$data['page']='trainer_account';
if($this->session->ID!=""){    
    
$this->load->model('Login_model');
$data['user']=$this->Login_model->get_user_information($this->session->email);
$this->load->model('Partners_model');
$this->load->model('Course_model');
$this->load->model('Section_model');
$data['category']=$this->Course_model->study_category();
$data['partners']=$this->Partners_model->list_partners();
$data['tel']=$this->Section_model->section('tel');
$data['email']=$this->Section_model->section('email');
$data['calendar']=$this->my_calendar();
$data['course_info']=$this->Section_model->section('courses');    
$data['course']=$this->Course_model->study_category();     
$data['approvals']=$this->Course_model-> get_approved_applications();
/**
 * sections.
 */
$data['about']=$this->Section_model->section('about');
$data['partners']=$this->Partners_model->list_partners();
$data['dev']=$this->Section_model->section('developer'); 
$data['mentors']=$this->Section_model->section('mentors'); 

    
$data['timezone']=date('D, d - M - Y');
$data['country']='Uganda';
$data['level']=$this->Login_model->academic_level();
$data['calendar']=$this->my_calendar();
$data['user']=$this->Login_model->logged_in_user($this->session->ID); 
$user=$data['user'];    
    
if($user->num_rows()==1){
    
foreach($user->result() as $row);
if($row->role!="trainer"){
redirect(base_url());
}

$course_details=$this->Course_model->user_course_details($row->interests);
$data['selected_course']=$row->interests;
if($course_details->num_rows()==1){
foreach($course_details->result() as $course);


$data['course_load']=$course;
$data['heading']=ucfirst($course->name);
$data['description']='view ongoing and upcoining events for '.strtolower($course->name);
$data['attributes']=$course->description;
$data['note']='Here is the notification title';    
/**
  * load courses
  */ 
$data['topics']=$this->Course_model->get_course_list($row->interests); 

 
$this->load->view('templates/user_header',$data);
$this->load->view('templates/contact_bar',$data);
$this->load->view('pages/page_heading',$data); 


$this->load->view('pages/trainer_events_page',$data);

$this->load->view('templates/footer',$data);     

}

}else{
redirect(base_url());
}    

}else{
redirect(base_url());
}    
}


























































































































































































































































































































































































































































































































































}